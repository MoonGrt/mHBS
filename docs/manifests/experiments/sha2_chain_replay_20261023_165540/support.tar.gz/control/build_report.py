from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,shutil,tarfile

ROOT=Path.cwd()
WORK=Path(__file__).resolve().parent
OLD=ROOT/'build/sha2_remaining_optimization/20261023_162334'
LABEL='sha2_chain_replay_'+WORK.name
ARCHIVE=ROOT/'docs/manifests/experiments'/LABEL
NAME='SHA2_Chain_Replay_'+WORK.name

def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,value):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def copy(a,b):
    b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b)

def main():
    source=WORK/'candidate_g';identity=read(source/'SOURCE.json');baseline_identity=read(WORK/'baseline/SOURCE.json')
    assert all(sha(source/n)==v==sha(ROOT/n) for n,v in identity.items())
    assert baseline_identity==read(OLD/'candidate_d/SOURCE.json')
    validation=read(WORK/'validation_g/RESULTS.json');regression=read(WORK/'regression_g/SUMMARY.json')
    replay=read(WORK/'validation_g_replay/SUMMARY.json');independent=read(WORK/'independent_reference/result/SUMMARY.json')
    assert validation['complete'] and validation['passed'] and validation['completed']==13
    assert regression['complete'] and regression['passed'] and regression['required']==29
    profile=next(x for x in validation['results'] if x['profiled']);focus=[x for x in validation['results'] if not x['profiled']]
    assert independent['passed'] and independent['signature_sha256']==profile['signature_sha256']
    before_profile=read(OLD/'validation_d_profile/RESULTS.json')['results'][0]
    before_focus=read(OLD/'validation_d/RESULTS.json')['results']
    before_synth=read(OLD/'SYNTH_D_RESULTS.json');synth=read(WORK/'SYNTH_G_RESULTS.json')
    assert synth['complete'] and synth['passed']==3
    areas={x['configuration']:x for x in synth['results']};old_areas={x['configuration']:x for x in before_synth['results']}
    comparisons=[]
    for after in focus:
        old=next(x for x in before_focus if (x['configuration'],x['profile'])==(after['configuration'],after['profile']))
        assert (old['hashes'],old['compressions'],old['logical_compressions'],old['signature_sha256'])==(
            after['hashes'],after['compressions'],after['logical_compressions'],after['signature_sha256'])
        row=dict(configuration=after['configuration'],profile=after['profile'],before_cycles=old['cycles'],cycles=after['cycles'],
                 cycle_delta_percent=(after['cycles']/old['cycles']-1)*100,hashes=after['hashes'],compressions=after['compressions'])
        if after['configuration'] in areas:
            a=areas[after['configuration']]['area']['equivalent_slice'];b=old_areas[after['configuration']]['area']['equivalent_slice']
            row.update(assumed_frequency_mhz=150,before_atp=b*old['cycles']/150e6,atp=a*after['cycles']/150e6,
                       atp_delta_percent=(a*after['cycles']/(b*old['cycles'])-1)*100,frequency_verified=False)
        comparisons.append(row)
    stages={}
    for name in ['E','F','G']:
        s=read(WORK/('SYNTH_'+name+'_RESULTS.json'));assert s['complete']
        p=profile if name=='G' else read(WORK/('validation_'+name.lower()+'_profile')/'RESULTS.json')['results'][0]
        stages[name]=dict(source=read(WORK/('candidate_'+name.lower())/'SOURCE.json'),profile=p,synthesis=s)
    before=before_profile['cycle_breakdown'];after=profile['cycle_breakdown']
    summary=dict(complete=True,selected='G',created_at=datetime.now(ZoneInfo('Asia/Singapore')).isoformat(timespec='seconds'),
                 source_sha256=identity,baseline_source_sha256=baseline_identity,baseline_source_matches_previous_synthesis=True,
                 production_changes=[n for n,v in baseline_identity.items() if identity[n]!=v],
                 before_profile=before_profile,profile=profile,remaining_delta_percent=(after['remaining']/before['remaining']-1)*100,
                 total_delta_percent=(after['total']/before['total']-1)*100,
                 synthesis=synth,comparisons=comparisons,stages=stages,
                 validation=dict(focus=validation,regression=regression,replay=replay,independent_c=independent),
                 scope='Primary improvement is P1 non-hash clocks; opportunistic shared-template replay has limited multi-context hits.',
                 routing='not_requested_not_run',final_frequency_verified=False,
                 detailed_simulation_logs_archived=False,runtime_directory=str(WORK.relative_to(ROOT)))
    reports=ARCHIVE/'reports';put(reports/(NAME+'.json'),summary)
    rows=[f'# SHA2 链反馈与非Hash周期优化（{WORK.name}）','',
          '最终采用G，已写入工作区RTL。唯一生产改动为`rtl/hash/sha2-recipe.sv`；没有P/U专用开关、第二条Hash lane、第二套SHA256状态或逐槽完整帧缓存。新路径按运行时模板可用性启用，所有合法P/U都保留通用回退。','',
          '## 主要结果：P1U1、SHA2-128f Sign','',
          '沿用上一轮完全相同的33字节SLOTH KAT，完整17,088字节签名与signature缓存逐字节一致。Hash分类沿用真实SHA256轮更新及feed-forward，未更改采样口径。','',
          '| 版本 | 总周期 | Hash | Remaining | Hash占比 |','|---|---:|---:|---:|---:|']
    for name,x in [('上一轮D',before),('本轮G',after)]:rows.append(f"| {name} | {x['total']:,} | {x['hash']:,} | {x['remaining']:,} | {x['hash']/x['total']:.2%} |")
    rows+=['',f"Remaining再降{-summary['remaining_delta_percent']:.2f}%，总周期再降{-summary['total_delta_percent']:.2f}%。相对最初1,030,190个Remaining周期，累计降低{(1-after['remaining']/1030190)*100:.2f}%。Hash104,925次、实际压缩106,514块均不变，改进来自实际空拍消除。",'',
           '同一KAT的SHAKE P1U1为2,620,575总周期、2,536,104 Hash、84,471 Remaining。SHA2本轮非Hash占比为1.81%，SHAKE为3.22%；绝对周期受算法轮数与调用次数影响，不能把占比等同于两个算法总延迟。','',
           '| 状态 | D非Hash周期 | G非Hash周期 |','|---|---:|---:|']
    for i,name in enumerate(['SELECT','DESCRIBE','PREPARE','BUILD','DRAIN']):rows.append(f"| {name} | {before_profile['remaining_formatter_totals'].get(str(i),0):,} | {profile['remaining_formatter_totals'].get(str(i),0):,} |")
    rows+=['','## 从SHAKE链反馈迁移的执行方式','',
           '已有512位块寄存器保留最后一个固定链帧。压缩运行时登记下一步域、步号、终止条件和模板所属tag；返回时只替换摘要及变化的地址字段，复用原来的CV/tag。捕获银行不作为暂存，原有捕获与返回统计保持原顺序。','',
           'E先让返回沿直接写原块寄存器，跳过DESCRIBE/PREPARE，仍留下一个非Hash周期。F进一步让已经过feed-forward寄存的compression_cv直接进入下一块，下一次round0与上一块输出发布同拍，连续链无需格式器往返。它没有旁路未寄存的feed-forward加法。SLH摘要从第22字节、LMS从第23字节开始，不直接进入首个W0地址字。','',
           '反馈仅用于shape0、SLH/LMS的单块终结且链继续。模板owner必须匹配，格式器空闲，无待发块、候选和遗留beat，压缩通道必须ready。任何正常块写入都会替换/失效原模板；忙时回退到原格式器。XMSS多阶段key/mask/final继续使用原执行路径。','',
           'G将宽数据选择从晚到的replay_take改为已登记的block_ready：有普通块时发送普通块；没有普通块时，唯一有效输入来源是反馈。有效周期的数据和握手与F完全等价，reset/仲裁控制不再串入宽数据选择后的消息调度加法。标量最终发布条件、链步与终结元数据同步维护。','',
           '| 候选 | 同KAT总周期 | Remaining | 取舍 |','|---|---:|---:|---|']
    descriptions={'E':'返回沿写块，P1面积增加较多','F':'零空拍链反馈，但晚控制串入消息调度','G':'保持F周期，改用寄存块状态选择数据；采用'}
    for name,s in stages.items():
        p=s['profile']['cycle_breakdown'];rows.append(f"| {name} | {p['total']:,} | {p['remaining']:,} | {descriptions[name]} |")
    rows+=['','## common综合面积与诊断时序','',
           '与D相同：Vivado2025.2、xc7a200tffg1156-3、OOC、统计关闭、默认时序驱动、100MHz诊断约束、每个Vivado2线程。等效Slice=LUT/4+FF/8。以下为综合结果，不能证明150MHz布线闭合；本轮没有启动布局布线。','',
           '| 配置 | D等效Slice | G LUT | G FF | BRAM36/DSP | G等效Slice | 面积变化 | D/G诊断路径ns |','|---|---:|---:|---:|---:|---:|---:|---:|']
    for name in ['P1U1','P4U1','P12U1']:
        r=areas[name];old=old_areas[name];a=r['area'];rows.append(f"| {name} | {old['area']['equivalent_slice']:,.3f} | {a['lut']:,.0f} | {a['ff']:,.0f} | {a['bram36']:g}/{a['dsp']:g} | {a['equivalent_slice']:,.3f} | {r['area_delta_percent']:+.3f}% | {old['data_path_delay_ns']:.3f}/{r['data_path_delay_ns']:.3f} |")
    rows+=['','F中15～16级的“晚控制→宽输入选择→消息调度”首路径已经消除。G三点诊断首路径分别回到group_index→task_b、format_block→列表选择、public_prefix_pending→need_block。诊断路径的改善不换算为已验证频率。','',
           '## 完整Sign周期与辅助ATP','',
           '使用仓库默认1字节向量。ATP按对应common综合面积与U1假定150MHz计算，单位等效Slice·s，仅作同频辅助比较。P4U2本轮仅验证周期，没有测量其同源面积，ATP留空。']
    for algorithm in ['slh_128f','xmss_h10','lms_h10']:
        rows+=['',f'### {algorithm}','','| 配置 | D周期 | G周期 | 周期变化 | D辅助ATP | G辅助ATP | ATP变化 |','|---|---:|---:|---:|---:|---:|---:|']
        for cfg in ['P1U1','P4U1','P4U2','P12U1']:
            r=next(x for x in comparisons if (x['configuration'],x['profile'])==(cfg,algorithm));values=f"{r['before_atp']:,.4f} | {r['atp']:,.4f} | {r['atp_delta_percent']:+.2f}%" if 'atp' in r else '— | — | —'
            rows.append(f"| {cfg} | {r['before_cycles']:,} | {r['cycles']:,} | {r['cycle_delta_percent']:+.3f}% | {values} |")
    rows+=['','## 收益边界与验证','',
           '本轮主要改善P1：其模板通常可保留至返回。多槽运行时，模板被其他上下文覆盖，反馈命中少；其完整Sign周期几乎不变，而新增控制带来面积成本。P4/P12的假定同频ATP有回退，XMSS四点周期不变，不能宣称全部配置/算法ATP改善。G保留了P1的低空拍路径及更短的诊断关键路径；E/F和D均冻结归档，便于后续面积与多上下文反馈优化取舍。','',
           '同一冻结G通过同33字节KAT、四配置三算法12项完整Sign、29组补充回归，以及5种配置/宏视图2,160个独立hashlib参考请求。新增测试覆盖非零链起点、15步尾界、seed/no_seed、初始/中间/末次捕获、捕获停顿、同拍补发、复位重放、公共种子A→B→A、固定SLH unary/pair和树域地址。保留F额外P1U2/P3U2/P24U1兼容，8视图共3,456请求。','',
           '完整签名、缓存和Hash/实际压缩计数逐项核对，并重新使用../../source/slhdsa-c独立C路径生成公钥/签名和验证G导出的签名，结果一致。SHAKE生产文件和SHA256原语未修改。h20完整Keygen/Sign继续停止，没有外推大树周期。','',
           f"运行目录为`{WORK.relative_to(ROOT)}`。详细仿真日志保留在运行目录，归档只保留验证摘要、冻结RTL、源码身份、综合分层/时序报告与日志。原始比较图数据保持历史版本，不用新源码替换旧测量。",'',
           f"复现测量：`python3 scripts/run_sha2_remaining_validation.py --source {source.relative_to(ROOT)} --work <新目录>`；新增反馈测试入口和测试台位于运行目录`validation_support/`，同时归档在support.tar.gz。"]
    (reports/(NAME+'.md')).write_text('\n'.join(rows)+'\n')
    put(ARCHIVE/'SOURCE.json',identity);put(ARCHIVE/'BASELINE_SOURCE.json',baseline_identity)
    put(ARCHIVE/'validation_summary/FINAL.json',summary['validation'])
    for name in ['E','F','G']:
        copy(WORK/('SYNTH_'+name+'_RESULTS.json'),ARCHIVE/('SYNTH_'+name+'_RESULTS.json'))
        for cfg in ['P1U1','P4U1','P12U1']:
            for p in (WORK/('synth_'+name.lower())/cfg).iterdir():
                if p.is_file() and p.suffix in ('.rpt','.log','.txt','.xdc','.json'):copy(p,ARCHIVE/'synth'/name/cfg/p.name)
    for cfg in ['P1U1','P4U1','P12U1']:
        for p in (OLD/'synth_d'/cfg).iterdir():
            if p.is_file() and p.suffix in ('.rpt','.log','.txt','.xdc','.json'):copy(p,ARCHIVE/'synth/baseline'/cfg/p.name)
    for name in ['baseline','candidate_e','candidate_f','candidate_g']:
        with tarfile.open(ARCHIVE/('rtl.tar.gz' if name=='candidate_g' else name+'_rtl.tar.gz'),'w:gz') as t:
            for p in (WORK/name).rglob('*'):
                if p.is_file() and (p.suffix in ('.sv','.svh') or p.name=='sources.txt'):t.add(p,arcname=str(p.relative_to(WORK/name)),recursive=False)
    copy(WORK/'independent_reference/source/REFERENCE_SOURCE.json',ARCHIVE/'REFERENCE_SOURCE.json')
    copy(WORK/'independent_reference/source/reference_source.tar.gz',ARCHIVE/'reference_source.tar.gz')
    support=[Path(__file__),WORK/'run_regression_g.py',ROOT/'scripts/run_sha2_remaining_validation.py',ROOT/'scripts/diagnose_timing.tcl',
             WORK/'validation_support/check_replay.py',WORK/'validation_support/tb_sha2_replay.sv']
    with tarfile.open(ARCHIVE/'support.tar.gz','w:gz') as t:
        for p in support:t.add(p,arcname='control/'+p.name,recursive=False)
    for p in ['VALIDATION_MEASUREMENTS.json','REPLAY_TIMING_REVIEW.json']:
        if (WORK/p).exists():copy(WORK/p,ARCHIVE/'validation_summary'/p)
    put(ARCHIVE/'ARTIFACTS.json',dict(complete=True,selected='G',runtime_directory=str(WORK.relative_to(ROOT)),
        routing='not_run',files_sha256={str(p.relative_to(ARCHIVE)):sha(p) for p in ARCHIVE.rglob('*') if p.is_file() and p.name!='ARTIFACTS.json'}))
    index=ROOT/'docs/manifests/experiments/INDEX.md';s=index.read_text();line=f'| {LABEL} | [{NAME}]({LABEL}/reports/{NAME}.md) | [证据]({LABEL}/ARTIFACTS.json) |'
    if line not in s:
        i=s.find('\n',s.rfind('\n|')+1);index.write_text(s[:i]+'\n'+line+s[i:])
    print(json.dumps(dict(report=str(reports/(NAME+'.md')),remaining=after['remaining'],total=after['total']),ensure_ascii=False))

if __name__=='__main__':main()
