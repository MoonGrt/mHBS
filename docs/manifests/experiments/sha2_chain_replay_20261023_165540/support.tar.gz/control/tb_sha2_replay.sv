`timescale 1ns/1ps
`default_nettype none
// Private replay acceptance test. All expected values are full hashlib hashes.
module tb_sha2_replay #(parameter integer PIPELINE=1,UNROLL=1,
 localparam integer TAG_BITS=PIPELINE>1 ? $clog2(PIPELINE) : 1);
 localparam integer CASES=48,GROUPS=3;
 logic clk=0;always #5 clk=~clk;
 logic rst=1,valid=0,ready_response=0;
 wire ready,response_valid,error;
 logic [TAG_BITS-1:0] tag=0;
 wire [TAG_BITS-1:0] response_tag;
 logic [4:0] steps=0,capture_after=0;
 logic [3:0] start=0,shape=0;
 logic no_seed=0,pair=0;
 logic [1:0] family=0;
 logic [7:0] address_a=0,seed_domain=8'h83,step_domain=8'h83;
 logic [31:0] address_b=0;
 logic [19:0] leaf=65536;
 logic [255:0] initial_value=0,right_value=0,secret_seed,public_seed;
 logic [127:0] identifier;
 wire [5:0] node_bytes=family_argument==0 ? 16 : 32;
 wire [255:0] response_digest,response_capture,read_digest,read_capture;
 recipe #(.N(32),.DIGEST_BYTES(49),.INDEX_BITS(8),.PIPELINE(PIPELINE),.UNROLL(UNROLL),.SHARED_STATE(1'b1)) dut(
  .clk,.rst,.error,.batch_mode(1'b1),.batch_request_valid(valid),.batch_request_ready(ready),
  .batch_request_tag(tag),.batch_steps(steps),.batch_capture_after(capture_after),.batch_capture_enable(1'b1),
  .batch_leaf(leaf),.batch_a(address_a),.batch_b(address_b),.batch_family(family),.batch_no_seed(no_seed),
  .batch_start(start),.batch_initial_value(initial_value),.batch_fixed_shape(shape),.batch_pair(pair),.batch_right(right_value),
  .batch_seed_domain(seed_domain),.batch_step_domain(step_domain),.batch_response_valid(response_valid),.batch_response_ready(ready_response),
  .batch_response_tag(response_tag),.batch_response_digest(response_digest),.batch_response_capture(response_capture),
  .batch_read_tag(response_tag),.batch_read_digest(read_digest),.batch_read_capture(read_capture),
`ifndef SYNTHESIS
  .batch_hashes(),.batch_permutations(),.hash_count(),.permutation_count(),
`endif
  .node_bytes,.identifier,.request_valid(1'b0),.request_ready(),.request_recipe(64'd0),.request_step_recipe(64'd0),
  .request_chain(1'b0),.request_steps(5'd0),.request_capture_after(5'd0),.request_capture(1'b0),
  .secret_seed,.secret_prf(256'd0),.public_seed,.root(256'd0),.randomizer(256'd0),
  .message_buffer(696'd0),.message_length(7'd0),.request_layer(5'd3),.request_tree(64'h0123456789abcdef),
  .request_leaf(20'd0),.request_a(8'd0),.request_b(32'd0),.request_left(256'd0),.request_right(256'd0),
  .list_index0(),.list_index1(),.list_next_index0(),.list_data0(256'd0),.list_data1(256'd0),
  .response_valid(),.response_ready(1'b0),.response_value(),.response_capture()
 );
 longint unsigned observed_hashes=0,observed_blocks=0;
 always @(posedge clk)begin
  if(rst)begin observed_hashes=0;observed_blocks=0;end
  else begin
   if(dut.hash_complete_event)observed_hashes++;
   if(dut.compression_complete_event)observed_blocks++;
  end
 end
 logic [1131:0] vectors[0:GROUPS*CASES-1];
 integer slot_row[0:PIPELINE-1];
 integer family_argument,cycles=0,same_edge=0,unordered=0;
 integer sent,retired,next_row,slot,row;
 integer expected_hashes,expected_blocks;
 longint unsigned base_hashes,base_blocks;
 logic refill;
 string vector_file;
 task automatic tick;
  @(posedge clk);#1;cycles++;if(cycles>1000000)$fatal(1,"timeout");
 endtask
 task automatic reset_lane;
  valid=0;ready_response=0;rst=1;tick();tick();rst=0;tick();
 endtask
 task automatic select_row(input integer index,input integer slot_index);
  family=2'(family_argument);tag=TAG_BITS'(slot_index);
  initial_value=vectors[index][767:512];right_value=vectors[index][1023:768];
  steps=vectors[index][1028:1024];capture_after=vectors[index][1033:1029];
  start=vectors[index][1037:1034];no_seed=vectors[index][1038];shape=vectors[index][1042:1039];pair=vectors[index][1043];
  seed_domain=vectors[index][1051:1044];step_domain=vectors[index][1059:1052];
  address_a=vectors[index][1067:1060];address_b=vectors[index][1099:1068];
 endtask
 task automatic poison_request;
  if(valid)$fatal(1,"poisoned accepted request");
  family=~family;tag=~tag;initial_value=~initial_value;right_value=~right_value;
  steps=~steps;capture_after=~capture_after;start=~start;no_seed=~no_seed;shape=~shape;pair=~pair;
  address_a=~address_a;address_b=~address_b;seed_domain=~seed_domain;step_domain=~step_domain;
 endtask
 task automatic check_response(input integer index);
  if(response_digest!==vectors[index][511:256] || response_capture!==vectors[index][255:0] ||
     read_digest!==vectors[index][511:256] || read_capture!==vectors[index][255:0])
   $fatal(1,"family %0d row %0d tag %0d digest/capture mismatch got=%h expected=%h cap=%h expectedcap=%h",
    family_argument,index,response_tag,response_digest,vectors[index][511:256],response_capture,vectors[index][255:0]);
 endtask
 initial begin
  if(!$value$plusargs("VECTOR=%s",vector_file) || !$value$plusargs("FAMILY=%d",family_argument))$fatal(1,"arguments");
  $readmemh(vector_file,vectors);
  for(integer k=0;k<32;k++)begin secret_seed[k*8+:8]=8'(k+1);public_seed[k*8+:8]=8'(k+65);end
  for(integer k=0;k<16;k++)identifier[k*8+:8]=8'(k+225);
  reset_lane();
  // Cancel after a full hash has returned while its next chain hash is live.
  select_row(0,0);valid=1;
  do begin @(negedge clk);end while(!ready);
  tick();valid=0;poison_request();
  while(observed_hashes<1)tick();repeat(2)tick();reset_lane();
  for(integer group_index=0;group_index<GROUPS;group_index++)begin
   leaf=group_index==1 ? 1048575 : 65536;
   for(integer k=0;k<32;k++)public_seed[k*8+:8]=8'(k+65)^(group_index==1 ? 8'ha5 : 8'd0);
   expected_hashes=0;expected_blocks=0;
   for(integer k=0;k<CASES;k++)begin
    expected_hashes+=int'(vectors[group_index*CASES+k][1115:1100]);
    expected_blocks+=int'(vectors[group_index*CASES+k][1131:1116]);
   end
   if(family_argument==0)expected_blocks=expected_blocks-expected_hashes+1;
   base_hashes=observed_hashes;base_blocks=observed_blocks;
   sent=0;retired=0;
   for(integer k=0;k<PIPELINE;k++)begin
    select_row(group_index*CASES+sent,k);valid=1;
    do begin @(negedge clk);end while(!ready);
    slot_row[k]=group_index*CASES+sent;sent++;
    tick();valid=0;poison_request();tick();
   end
   while(retired<CASES)begin
    while(!response_valid)begin tick();if(error)$fatal(1,"recipe error");end
    slot=int'(response_tag);row=slot_row[slot];
    if(row!=group_index*CASES+retired)unordered++;
    check_response(row);
    repeat(7)begin tick();if(response_tag!=TAG_BITS'(slot))$fatal(1,"held tag changed");check_response(row);end
    ready_response=1;refill=sent<CASES;
    if(refill)begin next_row=group_index*CASES+sent;select_row(next_row,slot);valid=1;end
    @(negedge clk);
    if(refill && ready)begin same_edge++;slot_row[slot]=next_row;sent++;refill=0;end
    tick();ready_response=0;
    if(refill)begin
     do begin @(negedge clk);end while(!ready);
     slot_row[slot]=next_row;sent++;tick();
    end
    valid=0;poison_request();tick();retired++;
   end
   repeat(5)tick();
   if(response_valid || observed_hashes-base_hashes!=expected_hashes || observed_blocks-base_blocks!=expected_blocks)
    $fatal(1,"group %0d counts/response hashes=%0d/%0d blocks=%0d/%0d",group_index,
     observed_hashes-base_hashes,expected_hashes,observed_blocks-base_blocks,expected_blocks);
   $display("REPLAY_GROUP_PASS family=%0d group=%0d requests=%0d hashes=%0d blocks=%0d",family_argument,group_index,CASES,expected_hashes,expected_blocks);
  end
  if(!same_edge || (PIPELINE>1 && !unordered))$fatal(1,"coverage same_edge=%0d unordered=%0d",same_edge,unordered);
  $display("SHA2_REPLAY_PASS P%0dU%0d family=%0d requests=%0d same_edge=%0d unordered=%0d reset_replay=1",PIPELINE,UNROLL,family_argument,GROUPS*CASES,same_edge,unordered);
  $finish;
 end
endmodule
`default_nettype wire
