#!/usr/bin/env python3
"""Check SHA2 chain replay with an independent complete-message SHA256 oracle.

All compilation uses an explicitly supplied frozen source tree. This helper
never changes production RTL, starts synthesis/routing, or generates h20 jobs.
"""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--work', type=Path, required=True)
    parser.add_argument('--pipeline', type=int, default=1)
    parser.add_argument('--unroll', type=int, default=1)
    parser.add_argument('--synthesis', action='store_true')
    parser.add_argument('--plan', action='store_true')
    args = parser.parse_args()
    if args.pipeline <= 0 or args.unroll <= 0 or args.pipeline*args.unroll > 24 or 24 % (args.pipeline*args.unroll):
        parser.error('P*U must divide24')
    source, work = args.source.resolve(), args.work.resolve()
    work.mkdir(parents=True, exist_ok=True)
    helper = Path(__file__).resolve().parent
    count = 48
    sk, public_a, ident = bytes(range(1, 33)), bytes(range(65, 97)), bytes(range(225, 241))
    public_b = bytes(x ^ 0xa5 for x in public_a)
    be = lambda x, n=4: x.to_bytes(n, 'big')
    patterns = [(0, 15, False, 0), (1, 14, True, 15), (14, 1, True, 15),
                (0, 7, False, 3), (7, 8, True, 7), (15, 0, True, 15),
                (0, 15, True, 15), (0, 1, False, 1), (0, 1, True, 1),
                (0, 0, False, 0), (7, 8, True, 11), (14, 1, True, 14)]
    plans = []
    for family in range(3):
        rows, groups = [], []
        n = 16 if family == 0 else 32
        for group, public in enumerate((public_a, public_b, public_a)):
            group_hashes = group_blocks = 0
            cases = []
            for row in range(count):
                start, steps, no_seed, capture_after = patterns[row % len(patterns)]
                shape = pair = 0
                seed_domain = step_domain = 0x83
                a, b, leaf = row+1, 0, (65536 if group != 1 else 1048575)
                initial = bytes((19*row+3*k+7*group) & 255 for k in range(n))
                right = bytes((11*row+5*k+13) & 255 for k in range(32))
                if family == 0:
                    if row % 16 == 12:
                        shape, start, steps, no_seed, capture_after = 1, 0, 0, True, 1
                    elif row % 16 in (13, 14):
                        shape, pair, start, steps, no_seed, capture_after = 2, int(row % 16 == 14), 0, 0, True, 1
                    elif row % 16 == 15:
                        start, steps, no_seed, capture_after = 0, 3, True, 2
                        step_domain, b = 3, 0x12345678
                hashes = blocks = 0

                def h(data):
                    nonlocal hashes, blocks
                    hashes += 1
                    blocks += (len(data)+72)//64
                    return sha256(data).digest()[:n]

                def adr(step, domain):
                    address = b''.join(be(x) for x in (3, 0, 0x01234567, 0x89abcdef, domain, leaf, a, step))
                    return address[3:4]+address[8:16]+address[19:20]+address[20:32]

                def slh(payload, step, domain):
                    return public[:16]+bytes(48)+adr(step, domain)+payload

                def masked(step, compound, domain=0x83):
                    return bytes(12)+b''.join(be(x) for x in (domain, leaf, a, step, compound))

                if shape == 1:
                    value = h(slh(sk[:n], b, seed_domain))
                    captured = value
                elif shape == 2:
                    value = h(slh(initial+(right[:n] if pair else b''), b, step_domain))
                    captured = value
                else:
                    value = initial
                    if not no_seed:
                        if family == 0:
                            value = h(slh(sk[:n], b, seed_domain))
                        elif family == 1:
                            value = h(be(4, 32)+sk+public+masked(b, 0, seed_domain))
                        else:
                            value = h(ident+be(leaf)+be(a, 2)+b'\xff'+sk)
                    captured = value if capture_after == start else None
                    for step in range(start, start+steps):
                        if family == 0:
                            value = h(slh(value, b if step_domain == 3 else step, step_domain))
                        elif family == 1:
                            key, mask = (h(be(3, 32)+public+masked(step, c, step_domain)) for c in (0, 1))
                            value = h(bytes(32)+key+bytes(x ^ y for x, y in zip(value, mask)))
                        else:
                            value = h(ident+be(leaf)+be(a, 2)+bytes([step])+value)
                        if capture_after == step+1:
                            captured = value
                    if captured is None:
                        raise ValueError('Expected capture was not visited')
                packed = int.from_bytes(captured, 'little') | int.from_bytes(value, 'little') << 256
                packed |= int.from_bytes(initial, 'little') << 512 | int.from_bytes(right, 'little') << 768
                packed |= steps << 1024 | capture_after << 1029 | start << 1034 | no_seed << 1038
                packed |= shape << 1039 | pair << 1043 | seed_domain << 1044 | step_domain << 1052
                packed |= a << 1060 | b << 1068 | hashes << 1100 | blocks << 1116
                rows.append(f'{packed:0283x}\n')
                group_hashes += hashes
                group_blocks += blocks
                cases.append(dict(start=start, steps=steps, no_seed=bool(no_seed), capture_after=capture_after,
                                  fixed_shape=shape, pair=bool(pair), step_domain=step_domain))
            groups.append(dict(hashes=group_hashes, logical_blocks=group_blocks,
                               physical_blocks=group_blocks-group_hashes+1 if family == 0 else group_blocks,
                               cases=cases))
        vector = work/f'family{family}.mem'
        vector.write_text(''.join(rows))
        plans.append(dict(family=family, vector=str(vector), groups=groups))
    manifest = {'source': str(source), 'pipeline': args.pipeline, 'unroll': args.unroll,
                'synthesis': args.synthesis, 'groups_per_family': 3, 'requests_per_group': count,
                'families': plans, 'reset_after_first_hash': True, 'full_slot_waves': True,
                'held_capture_and_same_edge_refill': True,
                'source_sha256': {p: sha256((source/p).read_bytes()).hexdigest() for p in
                                  ('rtl/hash/sha2-recipe.sv', 'rtl/hash/sha256.sv')}}
    (work/'PLAN.json').write_text(json.dumps(manifest, indent=2)+'\n')
    if args.plan:
        print('REPLAY_PLAN_READY '+str(work/'PLAN.json'))
        return
    command = ['verilator', '--binary', '--timing', '-O3', '-j', '2', '-Wno-fatal', '-DMHBS_SHA2',
               '--top-module', 'tb_sha2_replay', f'-GPIPELINE={args.pipeline}', f'-GUNROLL={args.unroll}',
               '--Mdir', str(work/'obj'), str(source/'rtl/hash/sha256.sv'),
               str(source/'rtl/hash/sha2-recipe.sv'), str(helper/'tb_sha2_replay.sv')]
    if args.synthesis:
        command.append('-DSYNTHESIS')
    (work/'COMMAND.json').write_text(json.dumps(command, indent=2)+'\n')
    with (work/'compile.log').open('w') as log:
        subprocess.run(command, cwd=source, stdout=log, stderr=subprocess.STDOUT, check=True)
    results = []
    for plan in plans:
        run = [str(work/'obj/Vtb_sha2_replay'), '+VECTOR='+plan['vector'], '+FAMILY='+str(plan['family'])]
        result = subprocess.run(run, cwd=source, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (work/f'family{plan["family"]}.log').write_text(result.stdout)
        print(result.stdout, end='', flush=True)
        result.check_returncode()
        if 'SHA2_REPLAY_PASS' not in result.stdout:
            raise RuntimeError('Pass marker missing')
        results.append({'family': plan['family'], 'passed': True})
    for path, digest in manifest['source_sha256'].items():
        if sha256((source/path).read_bytes()).hexdigest() != digest:
            raise RuntimeError('Frozen source changed')
    (work/'RESULTS.json').write_text(json.dumps({**manifest, 'passed': True, 'results': results}, indent=2)+'\n')


if __name__ == '__main__':
    main()
