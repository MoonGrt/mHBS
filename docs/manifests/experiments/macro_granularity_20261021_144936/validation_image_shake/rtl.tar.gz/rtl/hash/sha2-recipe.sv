`ifdef MHBS_SHA2
`timescale 1ns/1ps
`default_nettype none

// One scalar SHA256 invocation per accepted request. The image explicitly
// issues HMAC inner/outer and each MGF1 invocation as separate HASH requests.
// All request fields remain stable until the response is consumed.
// verilog_format: off
module recipe #(
    parameter integer N=32, DIGEST_BYTES=49, INDEX_BITS=7, UNROLL=1,
    parameter integer MAX_MESSAGE_BYTES=87,
    parameter [15:0] RECIPE_MASK=16'hfffe,
    parameter bit PROFILE_ENABLE=0
) (
    input wire clk,rst, input wire [5:0] node_bytes,
    input wire request_valid, output wire request_ready,
    input wire [63:0] request_recipe,
    input wire [N*8-1:0] secret_seed,secret_prf,public_seed,root,randomizer,
    output wire [3:0] message_word_address, input wire [63:0] message_word_data,
    input wire [6:0] message_length, input wire [4:0] request_layer,
    input wire [63:0] request_tree, input wire [19:0] request_leaf,
    input wire [1:0] request_address_type, input wire [31:0] request_index,
    input wire [127:0] request_identifier, input wire [N*8-1:0] request_key,
    input wire [INDEX_BITS-1:0] request_a, input wire [31:0] request_b,
    input wire [N*8-1:0] request_left,request_right,
    output wire [INDEX_BITS-1:0] list_index0,list_index1,
    input wire [N*8-1:0] list_data0,list_data1,
    output wire [1:0] auxiliary_read_select, input wire [255:0] auxiliary_read_data,
    output wire response_valid, input wire response_ready,
    output wire [DIGEST_BYTES*8-1:0] response_value, output logic error,
    output wire [63:0] hash_count,permutation_count
);
// verilog_format: on
    localparam [3:0] SLH_SEED=1, SLH_VALUE=2, SLH_PRF=3, SLH_MESSAGE=4,
        XMSS_PRF=5, XMSS_F=6, XMSS_H=7, XMSS_MESSAGE=8,
        LMS_SECRET=9, LMS_CHAIN=10, LMS_MESSAGE=11, SLH_LIST=12,
        LMS_LEAF=13, LMS_PARENT=14, LMS_PUBLIC=15;
    localparam [255:0] INITIAL_CV=256'h6a09e667bb67ae853c6ef372a54ff53a510e527f9b05688c1f83d9ab5be0cd19;
    typedef enum logic [2:0] {IDLE, PRODUCE, SUBMIT, COMPRESS, RESPONSE} state_t;
    state_t state;
    wire [3:0] shape=request_recipe[59:56];
    wire [7:0] domain=request_recipe[55:48], arity=request_recipe[47:40];
    wire [5:0] output_bytes=request_recipe[37:32], recipe_blocks=request_recipe[29:24];
    logic [12:0] input_length,position;
    logic [5:0] blocks,block_index;
    logic first_block;
    logic [511:0] block_data;
    logic [63:0] alignment_carry;
    wire [9:0] word_index=position[12:3];

    function automatic [15:0] be16(input [15:0] value);
        be16={value[7:0],value[15:8]};
    endfunction
    function automatic [31:0] be32(input [31:0] value);
        be32={value[7:0],value[15:8],value[23:16],value[31:24]};
    endfunction
    function automatic [63:0] be64(input [63:0] value);
        be64={value[7:0],value[15:8],value[23:16],value[31:24],
            value[39:32],value[47:40],value[55:48],value[63:56]};
    endfunction
    function automatic [63:0] node_word(input [255:0] value,input [1:0] index);
        case(index)
            0:node_word=value[63:0]; 1:node_word=value[127:64];
            2:node_word=value[191:128]; default:node_word=value[255:192];
        endcase
    endfunction

    // Lengths are bounded standard preimages, never arbitrary byte programs.
    logic [12:0] requested_length;
    always_comb begin
        requested_length=0;
        case(shape)
            SLH_SEED:requested_length=102;
            SLH_VALUE,SLH_LIST:requested_length=13'd86+{1'b0,arity,4'd0};
            SLH_PRF:requested_length=domain==1 ? 13'd80+13'(message_length) : 13'd96;
            SLH_MESSAGE:requested_length=domain==0 ? 13'd48+13'(message_length) : 13'd68;
            XMSS_PRF:requested_length=domain==0 ? 13'd128 : 13'd96;
            XMSS_F:requested_length=96;
            XMSS_H:requested_length=128;
            XMSS_MESSAGE:requested_length=13'd128+13'(message_length);
            LMS_SECRET,LMS_CHAIN:requested_length=55;
            LMS_MESSAGE:requested_length=13'd54+13'(message_length);
            LMS_LEAF:requested_length=54;
            LMS_PARENT:requested_length=86;
            LMS_PUBLIC:requested_length=2166;
            default:begin end
        endcase
    end
    wire [5:0] requested_blocks=6'((requested_length+13'd72)>>6);
    wire slh_shape=shape<=4 || shape==SLH_LIST;
    wire bad_slh=(node_bytes!=16)
        || ((shape==SLH_SEED || shape==SLH_PRF || shape==SLH_MESSAGE) && arity!=1)
        || (shape==SLH_SEED && domain!=5 && domain!=6)
        || (shape==SLH_VALUE && domain!=0 && domain!=2 && domain!=3)
        || (shape==SLH_LIST && domain!=1 && domain!=4)
        || (shape==SLH_VALUE && arity!=1 && arity!=2)
        || (shape==SLH_LIST && (arity==0 || arity>68))
        || (shape==SLH_PRF && (domain!=1 && domain!=2))
        || (shape==SLH_MESSAGE && domain>2)
        || output_bytes!=((shape==SLH_MESSAGE || (shape==SLH_PRF && domain==1)) ? 32 : 16);
    wire bad_standard=node_bytes!=32 || output_bytes!=32
        || (shape==XMSS_PRF && (domain>4 || arity!=1 || request_address_type>2))
        || (shape!=XMSS_PRF && domain!=0)
        || (arity!=(shape==XMSS_H || shape==LMS_PARENT ? 2 : shape==LMS_PUBLIC ? 67 : 1));
    wire reject_request=shape==0 || !RECIPE_MASK[shape]
        || (request_recipe & ~64'h0fff_ff3f_3f00_0000)!=0
        || (slh_shape ? bad_slh : bad_standard)
        || recipe_blocks==0 || recipe_blocks<requested_blocks
        || ((shape==SLH_PRF && domain==1 || shape==SLH_MESSAGE && domain==0
            || shape==XMSS_MESSAGE || shape==LMS_MESSAGE) && 32'(message_length)>MAX_MESSAGE_BYTES);

    wire [255:0] slh_address={be32(request_b),be32(32'(request_a)),
        be32({12'd0,request_leaf}),be32({24'd0,domain}),
        be32(request_tree[31:0]),be32(request_tree[63:32]),32'd0,be32({27'd0,request_layer})};
    wire [175:0] compressed_address={slh_address[255:160],slh_address[159:152],
        slh_address[127:64],slh_address[31:24]};
    wire [255:0] xmss_address={be32(domain>=2 ? 32'(domain)-32'd2 : 32'd0),
        be32(request_b),be32(32'(request_a)),
        be32(request_address_type==2 ? 32'd0 : {12'd0,request_leaf}),
        be32({30'd0,request_address_type}),be32(request_tree[31:0]),
        be32(request_tree[63:32]),be32({27'd0,request_layer})};
    wire [255:0] encoded_index={be32(request_index),224'd0};
    wire [31:0] lms_q=shape==LMS_MESSAGE ? request_index : {12'd0,request_leaf};
    wire [31:0] lms_number=shape==LMS_LEAF || shape==LMS_PARENT ? request_b : lms_q;
    wire [15:0] lms_domain=shape==LMS_MESSAGE ? 16'h8181
        : shape==LMS_LEAF ? 16'h8282 : shape==LMS_PARENT ? 16'h8383 : 16'h8080;

    // Select the node containing the last payload byte in this producer
    // word. A boundary word uses the preceding node's saved 64-bit tail.
    wire [12:0] slh_payload_last=position>=80 ? position-13'd79 : 13'd0;
    wire [12:0] lms_payload_last=position>=16 ? position-13'd15 : 13'd0;
    assign list_index0=shape==SLH_LIST ? INDEX_BITS'(slh_payload_last>>4)
        : shape==LMS_PUBLIC ? INDEX_BITS'(lms_payload_last>>5) : {INDEX_BITS{1'b0}};
    assign list_index1=list_index0+1'b1;
    wire [255:0] slh_payload_node=shape==SLH_SEED ? 256'(secret_seed)
        : shape==SLH_LIST ? 256'(list_data0)
        : slh_payload_last>=16 ? 256'(request_right) : 256'(request_left);
    wire [255:0] lms_payload_node=shape==LMS_PUBLIC ? 256'(list_data0)
        : shape==LMS_PARENT && lms_payload_last>=32 ? 256'(request_right) : 256'(request_left);
    wire [255:0] lms_chain_node=shape==LMS_SECRET ? 256'(secret_seed) : 256'(request_left);

    wire hmac_outer=shape==SLH_PRF && domain==2;
    wire mgf=shape==SLH_MESSAGE && domain!=0;
    // D0 uses the same node RAM read port as R and the selected L0/L1.
    // The producer never needs two RAM nodes in one word.
    assign auxiliary_read_select=hmac_outer && position>=64 && position<96
        || mgf && position>=32 && position<64 ? 2'd1 : 2'd0;
    wire [9:0] message_index=shape==SLH_PRF ? word_index-10'd10
        : shape==SLH_MESSAGE ? word_index-10'd6
        : shape==XMSS_MESSAGE ? word_index-10'd16 : word_index-10'd6;
    assign message_word_address=message_index[3:0];

    logic [63:0] source_word;
    always_comb begin
        source_word=0;
        case(shape)
            SLH_SEED,SLH_VALUE,SLH_LIST:begin
                case(word_index)
                    0:source_word=public_seed[63:0];
                    1:source_word=public_seed[127:64];
                    8:source_word=compressed_address[63:0];
                    9:source_word=compressed_address[127:64];
                    10:source_word={slh_payload_node[15:0],compressed_address[175:128]};
                    default:if(position>=88) begin
                        if(position[3]) source_word=slh_payload_node[79:16];
                        else source_word={slh_payload_node[15:0],alignment_carry[63:16]};
                    end
                endcase
            end
            SLH_PRF:begin
                if(word_index<8) begin
                    source_word={8{hmac_outer ? 8'h5c : 8'h36}};
                    if(word_index<2) source_word=source_word ^ node_word(256'(secret_prf),word_index[1:0]);
                end else if(hmac_outer) source_word=node_word(auxiliary_read_data,word_index[1:0]);
                else if(word_index<10) source_word=node_word(256'(randomizer),word_index[1:0]);
                else source_word=message_word_data;
            end
            SLH_MESSAGE:begin
                if(word_index<2) source_word=node_word(256'(randomizer),word_index[1:0]);
                else if(word_index<4) source_word=node_word(256'(public_seed),word_index[1:0]-2'd2);
                else if(mgf) begin
                    if(word_index<8) source_word=node_word(auxiliary_read_data,word_index[1:0]);
                    else if(word_index==8) source_word={32'd0,be32(32'(domain)-32'd1)};
                end else if(word_index<6) source_word=node_word(256'(root),word_index[1:0]);
                else source_word=message_word_data;
            end
            XMSS_PRF:begin
                if(word_index==3) source_word=domain==0 ? 64'h0400000000000000 : 64'h0300000000000000;
                else if(word_index>=4 && word_index<8)
                    source_word=node_word(domain==0 ? 256'(secret_seed) : domain==1 ? 256'(secret_prf)
                        : 256'(public_seed),word_index[1:0]);
                else if(word_index>=8 && word_index<12)
                    source_word=node_word(domain==0 ? 256'(public_seed) : domain==1 ? encoded_index
                        : xmss_address,word_index[1:0]);
                else if(word_index>=12 && domain==0) source_word=node_word(xmss_address,word_index[1:0]);
            end
            XMSS_F,XMSS_H:begin
                if(word_index==3 && shape==XMSS_H) source_word=64'h0100000000000000;
                else if(word_index>=4 && word_index<8) source_word=node_word(256'(request_key),word_index[1:0]);
                else if(word_index>=8 && word_index<12) source_word=node_word(256'(request_left),word_index[1:0]);
                else if(word_index>=12) source_word=node_word(256'(request_right),word_index[1:0]);
            end
            XMSS_MESSAGE:begin
                if(word_index==3) source_word=64'h0200000000000000;
                else if(word_index>=4 && word_index<8) source_word=node_word(256'(randomizer),word_index[1:0]);
                else if(word_index>=8 && word_index<12) source_word=node_word(256'(root),word_index[1:0]);
                else if(word_index>=12 && word_index<16) source_word=node_word(encoded_index,word_index[1:0]);
                else if(word_index>=16) source_word=message_word_data;
            end
            LMS_SECRET,LMS_CHAIN:begin
                case(word_index)
                    0:source_word=request_identifier[63:0];
                    1:source_word=request_identifier[127:64];
                    2:source_word={lms_chain_node[7:0],shape==LMS_SECRET ? 8'hff : request_b[7:0],
                        be16(16'(request_a)),be32(lms_q)};
                    3:source_word=lms_chain_node[71:8];
                    4:source_word=lms_chain_node[135:72];
                    5:source_word=lms_chain_node[199:136];
                    6:source_word={8'd0,lms_chain_node[255:200]};
                    default:begin end
                endcase
            end
            LMS_MESSAGE:begin
                case(word_index)
                    0:source_word=request_identifier[63:0];
                    1:source_word=request_identifier[127:64];
                    2:source_word={randomizer[15:0],lms_domain,be32(lms_number)};
                    3:source_word=randomizer[79:16];
                    4:source_word=randomizer[143:80];
                    5:source_word=randomizer[207:144];
                    6:source_word={message_word_data[15:0],randomizer[255:208]};
                    default:source_word={message_word_data[15:0],alignment_carry[63:16]};
                endcase
            end
            LMS_LEAF,LMS_PARENT,LMS_PUBLIC:begin
                case(word_index)
                    0:source_word=request_identifier[63:0];
                    1:source_word=request_identifier[127:64];
                    2:source_word={lms_payload_node[15:0],lms_domain,be32(lms_number)};
                    default:if(position>=24) begin
                        case(position[4:3])
                            0:source_word=lms_payload_node[143:80];
                            1:source_word=lms_payload_node[207:144];
                            2:source_word={lms_payload_node[15:0],alignment_carry[63:16]};
                            default:source_word=lms_payload_node[79:16];
                        endcase
                    end
                endcase
            end
            default:begin end
        endcase
    end

    wire word_valid=state==PRODUCE;
    wire [63:0] stream_data=source_word;

    logic [63:0] padded_word;
    wire end_word=position[12:3]==input_length[12:3];
    wire past_end_word=position[12:3]>input_length[12:3];
    wire length_word=position[5:3]==7 && block_index==blocks-1'b1;
    always_comb begin
        padded_word=source_word;
        for(integer byte_index=0;byte_index<8;byte_index=byte_index+1) begin
            if(past_end_word || (end_word && 3'(byte_index)>=input_length[2:0]))
                padded_word[byte_index*8+:8]=0;
            if(end_word && 3'(byte_index)==input_length[2:0])
                padded_word[byte_index*8+:8]=8'h80;
        end
        if(length_word) padded_word=be64({48'd0,input_length,3'd0});
    end
    for(genvar word=0;word<8;word=word+1) begin: assembled_words
        always_ff @(posedge clk)
            if(!rst && state==PRODUCE && position[5:3]==3'(word))
                block_data[511-64*word-:64]<=be64(padded_word);
    end

    wire compression_ready,compression_valid;
    wire [255:0] compression_value;
    wire compression_submit=state==SUBMIT && compression_ready;
    sha256 #(.PIPELINE(1),.UNROLL(1),.TAG_BITS(1)) compression (
        .clk,.rst,.input_valid(state==SUBMIT),.input_ready(compression_ready),
        .input_cv(first_block ? INITIAL_CV : compression_value),.input_block(block_data),.input_tag(1'b0),
        .output_valid(compression_valid),.output_ready(state==COMPRESS),
        .output_cv(compression_value),.output_tag()
    );
    assign request_ready=state==IDLE && !rst;
    assign response_valid=state==RESPONSE && !rst;
    for(genvar byte_index=0;byte_index<DIGEST_BYTES;byte_index=byte_index+1) begin: digest_bytes
        if(byte_index<32) assign response_value[byte_index*8+:8]=!error && byte_index<output_bytes
            ? compression_value[255-byte_index*8-:8] : 8'd0;
        else assign response_value[byte_index*8+:8]=8'd0;
    end

    always_ff @(posedge clk) begin
        if(rst) begin
            state<=IDLE;error<=0;input_length<=0;position<=0;
            blocks<=0;block_index<=0;first_block<=1;alignment_carry<=0;
        end else case(state)
            IDLE:if(request_valid) begin
                error<=reject_request;input_length<=requested_length;blocks<=requested_blocks;
                position<=0;block_index<=0;first_block<=1;alignment_carry<=0;
                state<=reject_request ? RESPONSE : PRODUCE;
            end
            PRODUCE:begin
                position<=position+13'd8;
                if(shape==SLH_SEED || shape==SLH_VALUE || shape==SLH_LIST)
                    alignment_carry<=slh_payload_node[127:64];
                else if(shape==LMS_MESSAGE) alignment_carry<=message_word_data;
                else if(shape==LMS_LEAF || shape==LMS_PARENT || shape==LMS_PUBLIC)
                    alignment_carry<=lms_payload_node[255:192];
                if(position[5:3]==7) state<=SUBMIT;
            end
            SUBMIT:if(compression_ready) state<=COMPRESS;
            COMPRESS:if(compression_valid) begin
                first_block<=0;
                if(block_index==blocks-1'b1) state<=RESPONSE;
                else begin block_index<=block_index+1'b1;state<=PRODUCE;end
            end
            RESPONSE:if(response_ready) state<=IDLE;
            default:state<=IDLE;
        endcase
    end

    // Diagnostic state has a dedicated process and disappears in synthesis.
`ifndef SYNTHESIS
    logic [63:0] diagnostic_hashes,diagnostic_compressions;
    assign hash_count=diagnostic_hashes;
    assign permutation_count=diagnostic_compressions;
    always_ff @(posedge clk) begin
        if(rst) begin diagnostic_hashes<=0;diagnostic_compressions<=0;end
        else if(PROFILE_ENABLE) begin
            if(request_valid && request_ready && !reject_request) diagnostic_hashes<=diagnostic_hashes+1'b1;
            if(compression_submit) diagnostic_compressions<=diagnostic_compressions+1'b1;
        end
    end
    initial begin
        if(N!=32 || DIGEST_BYTES<32 || UNROLL!=1 || INDEX_BITS<7 || MAX_MESSAGE_BYTES>87)
            $fatal(1,"SHA2 scalar lane requires N32, K1U1 and bounded message/list ports");
    end
`else
    assign hash_count=64'd0;
    assign permutation_count=64'd0;
`endif
endmodule
`default_nettype wire

`endif
