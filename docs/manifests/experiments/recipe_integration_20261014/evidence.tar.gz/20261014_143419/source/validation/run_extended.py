from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
PROJECT = Path('/media/sk1/25700d07-be6e-4225-bd06-13baa4403116/Vivado/mHBS/tmp/mHBS')
OUTPUT = ROOT / 'validation' / 'extended'
OUTPUT.mkdir(parents=True, exist_ok=True)
PROFILES = ('slh_128f', 'slh_192f', 'slh_256f', 'slh_128s', 'slh_192s', 'slh_256s',
            'xmss_h10', 'xmss_h16', 'xmss_h20', 'lms_h10', 'lms_h15', 'lms_h20')
SOURCES = (ROOT / 'sources.txt').read_text().splitlines()
SOURCE_HASHES = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in SOURCES}
started = time.time()
records = []
lock = threading.Lock()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def publish(complete=False):
    data = dict(expected_records=72, complete=complete, passed=all(r['passed'] for r in records),
                elapsed_seconds=time.time()-started, source_sha256=SOURCE_HASHES,
                source_unchanged=all(sha(ROOT/p)==h for p,h in SOURCE_HASHES.items()),
                results=records, h20_full_keygen_sign_run=False)
    (ROOT/'validation/FINAL_VALIDATION.json').write_text(json.dumps(data, indent=2)+'\n')


def run(name, command, marker, environment=None, **details):
    env = os.environ.copy()
    env.pop('PROFILE_ENABLE', None)
    if environment:
        env.update(environment)
    log = OUTPUT / (name+'.log')
    begin = time.time()
    with log.open('w') as handle:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=handle, stderr=subprocess.STDOUT)
    text = log.read_text()
    record = dict(name=name, passed=result.returncode==0 and marker in text,
                  seconds=time.time()-begin, log=str(log), log_sha256=sha(log), **details)
    matches = re.findall(r'STATEFUL_PASS P(\d+)U(\d+) op=(\d+) cycles=(\d+) total=(\d+) hashes=(\d+) permutations=(\d+)', text)
    if matches:
        record['measurements']=[dict(zip(('pipeline','unroll','operation','cycles','total_cycles','hashes','permutations'),map(int,m))) for m in matches]
    with lock:
        records.append(record)
        publish()
    print(json.dumps(record), flush=True)
    if not record['passed']:
        raise RuntimeError(name+' failed; see '+str(log))
    return record


def fast_cases():
    for synthesis in (0, 1):
        env = {'SIM_SYNTHESIS': str(synthesis)}
        for profile in PROFILES:
            run(f'verify_synthesis{synthesis}_{profile}', ['bash','scripts/simulate_fast.sh',profile,'verify','4','1'], 'STATEFUL_PASS', env)
        for profile in ('xmss_h10','lms_h10'):
            for q in (1, 1023):
                vectors = PROJECT/'build/pu_generic/20261013_201408/audit/extended'/f'{profile}_q{q}'
                fixture = vectors/profile/'sign'
                run(f'sign_synthesis{synthesis}_{profile}_q{q}', ['bash','scripts/simulate_fast.sh',profile,'sign','4','1'], 'STATEFUL_PASS', dict(env,VECTORS_DIR=str(vectors)),
                    q=q, vectors_sha256={p.name:sha(p) for p in fixture.glob('*.mem')})


def extra_cases():
    for profile in ('slh_128f','xmss_h10','lms_h10'):
        run(f'keygen_{profile}', ['bash','scripts/simulate_fast.sh',profile,'keygen','4','1'], 'STATEFUL_PASS')
        run(f'sign_synthesis_{profile}', ['bash','scripts/simulate_fast.sh',profile,'sign','4','1'], 'STATEFUL_PASS', {'SIM_SYNTHESIS':'1'})
        run(f'verify_P3U2_{profile}', ['bash','scripts/simulate_fast.sh',profile,'verify','3','2'], 'STATEFUL_PASS')


def event_cases():
    for synthesis in (0, 1):
        env = {'SIM_SYNTHESIS':str(synthesis)}
        for profile in ('slh_128f','xmss_h10','lms_h10'):
            run(f'verify_stall_replay_reset_cut_synthesis{synthesis}_{profile}', ['bash','scripts/simulate.sh',profile,'verify','4','1','+STALL=1','+REPLAYS=2','+INTERRUPT=1','+CUT=5'], 'STATEFUL_PASS', env)
        run(f'slh_sign_stall_replay_reset_synthesis{synthesis}', ['bash','scripts/simulate.sh','slh_128f','sign','4','1','+STALL=1','+REPLAYS=2','+INTERRUPT=1'], 'STATEFUL_PASS', env)
        for name, options, marker in (
            ('q_overflow',['+Q=1024','+INVALID=1'],'INDEX_REJECT_PASS'),
            ('invalid_profile',['+PROFILE=9'],'INDEX_REJECT_PASS'),
            ('scalar_lane_fault',['+FAULT=1'],'STATEFUL_FAULT_PASS'),
            ('batch_lane_fault',['+FAULT=2'],'STATEFUL_FAULT_PASS'),
            ('illegal_state',['+FAULT=3'],'STATEFUL_FAULT_PASS')):
            run(f'{name}_synthesis{synthesis}', ['bash','scripts/simulate.sh','xmss_h10','verify','4','1',*options], marker, env)


def top_cases():
    run('top_four_macro_sign_views',['python3','scripts/check_top_signature.py'],'TOP_SIGNATURE_PASS')
    for synthesis in (0,1):
        for signature in (0,1):
            log=ROOT/f'build/top_signature_check/synthesis{synthesis}_signature{signature}/run.log'
            if 'TOP_SIGNATURE_PASS' not in log.read_text(): raise RuntimeError('Top macro view missing')


def hash_cases():
    for p,u in ((1,1),(12,1),(3,2)):
        run(f'recipes_P{p}U{u}', ['python3','scripts/check_recipes.py','--pipeline',str(p),'--unroll',str(u)], 'RECIPE_PASS cases=459')
    run('recipes_synthesis',['python3','scripts/check_recipes.py','--pipeline','4','--unroll','1','--synthesis'],'RECIPE_PASS cases=459')
    run('recipes_mask101e_P4U1',['python3','scripts/check_recipes.py','--pipeline','4','--unroll','1','--recipe-mask','0x101e'],'RECIPE_PASS cases=186')
    run('recipes_mask101e_P3U2_synthesis',['python3','scripts/check_recipes.py','--pipeline','3','--unroll','2','--recipe-mask','0x101e','--synthesis'],'RECIPE_PASS cases=186')
    run('pipeline_synthesis',['python3','scripts/check_pipeline.py','--synthesis'],'PIPELINE_PASS')
    for synthesis in (0,1):
        out=OUTPUT/f'statistics{synthesis}'
        out.mkdir(exist_ok=True)
        command=['verilator','--binary','--timing','-O3','-j','2','-Wno-fatal','--top-module','tb_statistics','--Mdir',str(out/'obj'),'rtl/hash/keccak.sv','rtl/hash/recipe.sv','tb/tb_statistics.sv']
        if synthesis:command.append('-DSYNTHESIS')
        run(f'statistics_compile{synthesis}',command,'Leaving directory')
        run(f'statistics{synthesis}',[str(out/'obj/Vtb_statistics')],'STATISTICS_PASS')


try:
    run('source_four_view_audit',['python3','scripts/audit_rtl_debug.py','--lint','--output','validation/source_audit.json'],'RTL_DEBUG_AUDIT_PASS')
    with ThreadPoolExecutor(max_workers=2) as pool:
        for future in as_completed([pool.submit(f) for f in (fast_cases,event_cases,top_cases,hash_cases,extra_cases)]):
            future.result()
    with lock:
        publish(complete=True)
    if not all(sha(ROOT/p)==h for p,h in SOURCE_HASHES.items()):raise RuntimeError('Frozen source changed')
    print('FINAL_VARIANT_VALIDATION_PASS',len(records),flush=True)
except Exception as error:
    with lock: publish(complete=True)
    print('FINAL_VARIANT_VALIDATION_FAIL',repr(error),flush=True)
    raise
