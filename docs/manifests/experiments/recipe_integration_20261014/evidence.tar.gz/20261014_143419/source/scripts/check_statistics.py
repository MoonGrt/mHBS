#!/usr/bin/env python3
"""Check 64-bit statistics carry and real fixed-hash completion through recipe."""
import argparse
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--synthesis', action='store_true',
                        help='Verify functional completion with diagnostic ports removed')
    args = parser.parse_args()
    work = ROOT / ('build/statistics_check_synthesis' if args.synthesis else 'build/statistics_check')
    work.mkdir(parents=True, exist_ok=True)
    command = [os.environ.get('VERILATOR', 'verilator'), '--binary', '--timing', '-O3',
               '-j', '2', '-Wno-fatal', '--top-module', 'tb_statistics', '--Mdir', str(work/'obj'),
               'rtl/hash/keccak.sv', 'rtl/hash/recipe.sv', 'tb/tb_statistics.sv']
    if args.synthesis:
        command.append('-DSYNTHESIS')
    with (work/'compile.log').open('w') as log:
        subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    result = subprocess.run([str(work/'obj/Vtb_statistics')], cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (work/'run.log').write_text(result.stdout)
    print(result.stdout, end='')
    result.check_returncode()
    if 'STATISTICS_PASS' not in result.stdout:
        raise RuntimeError('Statistics check did not report success')


if __name__ == '__main__':
    main()
