from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib,json,subprocess,threading,time
ROOT=Path(__file__).resolve().parents[1]
OUTPUT=ROOT/'validation'
START=time.time()
LOCK=threading.Lock()
RECORDS=[]
SOURCES=(ROOT/'sources.txt').read_text().splitlines()
SHA={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in SOURCES}
def publish(complete=False):
 data=dict(complete=complete,passed=all(r['passed'] for r in RECORDS),expected_records=8,
           elapsed_seconds=time.time()-START,results=RECORDS,source_sha256=SHA,
           source_unchanged=all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in SHA.items()))
 (OUTPUT/'SHARED_STATE_VALIDATION.json').write_text(json.dumps(data,indent=2)+'\n')
def run(shared,p,synthesis):
 overlay=OUTPUT/f'shared_state{shared}_source'
 label=f'recipes_shared{shared}_P{p}U1_synthesis{synthesis}'
 log=OUTPUT/(label+'.log')
 cmd=['python3',str(overlay/'scripts/check_recipes.py'),'--pipeline',str(p),'--unroll','1']
 if synthesis:cmd.append('--synthesis')
 begin=time.time()
 with log.open('w') as handle:
  result=subprocess.run(cmd,cwd=overlay,stdout=handle,stderr=subprocess.STDOUT)
 text=log.read_text()
 coverage=overlay/'build/recipe_check'/('P%dU1'%p+('_synthesis' if synthesis else ''))/'coverage.json'
 record=dict(name=label,shared_state=shared,pipeline=p,unroll=1,synthesis=synthesis,
             passed=result.returncode==0 and 'RECIPE_PASS cases=459' in text,seconds=time.time()-begin,
             log=str(log),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
             testbench_sha256=hashlib.sha256((overlay/'tb/tb_recipe.sv').read_bytes()).hexdigest())
 if coverage.exists():record['coverage']=json.loads(coverage.read_text())
 with LOCK:
  RECORDS.append(record);publish()
 print(json.dumps(record),flush=True)
 return record
with ThreadPoolExecutor(max_workers=2) as pool:
 for future in as_completed([pool.submit(run,s,p,v) for s in (0,1) for p in (4,12) for v in (0,1)]):future.result()
publish(complete=True)
print('SHARED_STATE_VALIDATION_'+('PASS' if all(r['passed'] for r in RECORDS) else 'FAIL'),len(RECORDS),flush=True)
raise SystemExit(not all(r['passed'] for r in RECORDS))
