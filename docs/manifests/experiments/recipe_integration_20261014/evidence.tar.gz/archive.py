from pathlib import Path
import difflib
import hashlib
import json
import shutil
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
RUNS = ROOT / 'build/pu_sign_matrix'
OUT = ROOT / 'docs/manifests/experiments/recipe_integration_20261014'
candidate = sys.argv[1]
experiments = json.loads((WORK / 'experiments.json').read_text())
baseline = experiments['baseline']
OUT.mkdir(parents=True, exist_ok=True)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


for run, name in ((baseline, 'BASELINE_SOURCE.json'), (candidate, 'SOURCE.json')):
    shutil.copyfile(RUNS / run / 'SOURCE.json', OUT / name)
validation = RUNS / candidate / 'source/validation'
shutil.copyfile(validation / 'FINAL_VALIDATION.json', OUT / 'VALIDATION.json')
shutil.copyfile(validation / 'source_audit.json', OUT / 'SOURCE_AUDIT.json')
shutil.copyfile(ROOT / 'build/recipe_inline_audit/mechanical_equivalence.json', OUT / 'MECHANICAL_MERGE.json')
dump('EXPERIMENTS.json', dict(**experiments, candidate=candidate))
states = {e['run_id']: json.loads((RUNS / e['run_id'] / 'status.json').read_text())
          for e in experiments['experiments']}
states[baseline] = json.loads((RUNS / baseline / 'status.json').read_text())
dump('MEASUREMENTS.json', states)
shutil.copyfile(ROOT / 'docs/report/Recipe_Integration_Matrix_20261014.json', OUT / 'COMPARISON.json')
old_source = RUNS / baseline / 'source'
new_source = RUNS / candidate / 'source'
names = set((old_source / 'sources.txt').read_text().splitlines())
names.update((new_source / 'sources.txt').read_text().splitlines())
names.update(['sources.txt', 'scripts/check_pipeline.py', 'scripts/check_recipes.py',
              'scripts/check_statistics.py', 'scripts/run_pu_sign_matrix.py',
              'scripts/validate_p4.sh', 'tb/tb_recipe.sv', 'tb/tb_pipeline.sv', 'tb/tb_statistics.sv'])
patch = []
for name in sorted(names):
    before, after = old_source / name, new_source / name
    patch.extend(difflib.unified_diff(before.read_text().splitlines(True) if before.exists() else [],
                                     after.read_text().splitlines(True) if after.exists() else [],
                                     fromfile='a/' + name if before.exists() else '/dev/null',
                                     tofile='b/' + name if after.exists() else '/dev/null'))
(OUT / 'candidate.patch').write_text(''.join(patch))
dump('CHECKPOINTS.json', [dict(run_id=run, path=str(path), bytes=path.stat().st_size, sha256=sha(path))
                         for run in (baseline, candidate)
                         for path in sorted((RUNS / run / 'synth').glob('*/common/synthesized.dcp'))])
with tarfile.open(OUT / 'evidence.tar.gz', 'w:gz') as archive:
    def add(path, name):
        archive.add(path, arcname=name, recursive=False)
    for run in states:
        folder = RUNS / run
        metadata = json.loads((folder / 'SOURCE.json').read_text())
        for name in ('SOURCE.json', 'status.json', 'runner.log'):
            add(folder / name, f'{run}/{name}')
        for name in metadata['sha256']:
            add(folder / 'source' / name, f'{run}/source/{name}')
        for part in ('synth', 'sim', 'source/validation'):
            for path in sorted((folder / part).rglob('*')):
                if path.is_file() and 'obj' not in path.parts and path.suffix in ('.log', '.rpt', '.txt', '.json', '.py'):
                    add(path, f'{run}/{path.relative_to(folder)}')
    for part in ('build/recipe_inline_audit', 'build/recipe_integration/shared_round_cleanup',
                 'build/recipe_integration/word_write_cleanup'):
        for path in sorted((ROOT / part).rglob('*')):
            if path.is_file() and path.suffix in ('.json', '.log', '.py'):
                add(path, str(path.relative_to(ROOT)))
    for path in sorted((new_source / 'build/recipe_check').rglob('*')):
        if path.is_file() and path.name in ('coverage.json', 'run.log', 'recipes.mem'):
            add(path, f'{candidate}/source/{path.relative_to(new_source)}')
    fixtures = ROOT / 'build/pu_generic/20261013_201408/audit/extended'
    for profile in ('xmss_h10', 'lms_h10'):
        for q in (1, 1023):
            source = fixtures / f'{profile}_q{q}'
            for path in sorted(source.rglob('*.mem')):
                add(path, 'boundary_vectors/' + str(path.relative_to(fixtures)))
    for suffix in ('.md', '.csv', '.json', '_Notes.md'):
        path = ROOT / 'docs/report' / ('Recipe_Integration_Matrix_20261014' + suffix)
        add(path, 'report_snapshot/' + path.name)
    add(ROOT / 'scripts/report_recipe_integration.py', 'report_recipe_integration.py')
    add(WORK / 'concurrency.jsonl', 'concurrency.jsonl')
    add(Path(__file__), 'archive.py')
(OUT / 'README.md').write_text(
    '# Recipe integration evidence\n\n'
    f'Baseline `{baseline}`; selected candidate `{candidate}`.\n\n'
    'The independent pipeline module is removed; recipe owns fixed contexts and the Keccak stages. '
    'COMPARISON.json records measured per-configuration cycle equality, workload equality and common-area changes.\n\n'
    'Evidence includes frozen sources/vectors, all experimental synthesis/simulation logs, '
    'selected-source validation, mechanical-merge checks, and the exact incremental patch. '
    'DCP paths and hashes are listed in CHECKPOINTS.json.\n\n'
    'Area uses common OOC with generic Keccak, 6.666667 ns and two Vivado threads. '
    'No new routed STA is claimed. ATP assumes U1=150 MHz and U2=110 MHz. '
    'h20 full Keygen/Sign stayed stopped.\n\n'
    'Any pending anomalous synthesis is a delivery-time snapshot and keeps running in the background. '
    'The live report can backfill results without changing this archive or the selected RTL.\n')
dump('SHA256.json', {p.name: sha(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'SHA256.json'})
print(OUT)
