# 有类型微程序实现的构建与验证

在仓库根目录运行。需要 Python 3、GNU Make、Icarus Verilog、Verilator、C++ 编译器和 OpenSSL 开发库。功能仿真不依赖 Vivado；综合入口使用 Vivado。

```bash
make test TAG=micro_check
make verify TAG=micro_full
make rtl-profile-test TAG=probe PROFILE=slh_192f OPERATION=verify
```

## 门禁与命令

| 命令 | 内容 |
|---|---|
| `make contract-test lint` | 默认源码闭包、公共接口、镜像/指令合同和 RTL lint |
| `make compile-microcode TAG=...` | 生成六组默认镜像，并执行六参数、三操作的 VM/独立参考门禁 |
| `make rtl-unit-test TAG=...` | 单次 Hash lane 的 hashlib 向量和处理器协议单元 |
| `make test TAG=...` | 合同、lint、模型、单元、18 组正常 RTL、独立 Hash 输入/结果多重集及顶层缓存对照 |
| `make hash-work-test TAG=...` | 在已生成的同 TAG 镜像上，比较六参数三操作的完整 Hash 输入/结果任务多重集 |
| `make rtl-profile-test TAG=... PROFILE=slh_128f OPERATION=sign` | 生成该参数的模型/向量，再执行指定操作；OPERATION 也接受 verify/all |
| `make rtl-all-profiles TAG=...` | 六参数模型及全部 Keygen/Sign/Verify RTL |
| `make verify TAG=...` / `make smoke TAG=...` | 正常门禁及扩展协议检查 |
| `make synth-core TAG=...` | 新共同核和控制存储的独立综合资源报告 |

`rtl-verification` 在已有同 TAG 模型向量上重跑正常及扩展 RTL。源码或镜像修改后须换新 TAG，避免将不同快照的结果混在同一报告。

## 校验内容

逐指令 VM 独立实现 ABI 4 TREE 与单链宏，逐次调用 hashlib 并记录每个内部 Hash，不调用旧 TREE/CHAIN 宏执行器。独立 SLH 参考检查公私钥、完整签名与验签结果；f 参数还检查仓库 ACVP KAT。Hash/置换次数同时与参考及适用的 v4.2 优化基线比较。

`test`、`smoke`、`verify` 在模型/RTL 后执行独立 Hash 工作核验。也可单独运行：

```bash
make hash-work-test TAG=micro_full
python3 scripts/verify_micro_hash_work.py --image-root build/micro/micro_full/images --out build/micro/micro_full/hash_work --jobs 3
```

该核验记录独立参考与逐指令 VM 的全部 Hash 输入和结果，按含重复次数的任务多重集比较，允许调度顺序改变。本次 18 例、10,896,336 项任务完全一致，Sign 也无额外或缺失任务。结果与输入/镜像/源码哈希保存在 TAG 的 `hash_work/`。默认 TAG 为 `micro_v4`；修改源码后仍应指定新 TAG。

RTL 比较完整输出字节、节点数、Hash/置换次数和逐 Hash 轨迹摘要。轨迹包含 recipe、layer、64 位 tree、leaf/a/b 和完整摘要，按组中 lane0/lane1 次序记录。它用于定位软件控制与硬件输入构造之间的差异。

默认工具链为 ABI 4。assembler、VM、RTL 的编码权限来自同一 schema，合同测试检查生成的 SV 定义与 Python 完全一致，并拒绝通用标量指令、非法空间索引和只读节点写入。ABI 1 软件工具及 ABI 2/3 封存源码单独保留，不能经默认 RTL 执行。

处理器单元覆盖 HASH 上下文快照、受限元数据重叠、分支预取清除、WAIT 原子提交、未激活 lane 保留、H_msg 持久保存、摘要拆分、WOTS 校验和、非法操作/越界及 Verify 输入等待。Hash lane 单元覆盖三种 n、五种配方、多块/边界长度、反压、非法输入及复位。

集成仿真区分普通 HASH、独立 CHAIN 与 TREE 实例。普通 HASH 发放一次授权；CHAIN 按模式、digit、逻辑槽和步号限定内部 PRF/F 序列；TREE 授权范围包含固定单树调度及子链。每次 sponge context 握手必须消耗对应授权，逐 Hash 核对地址与完成 trace；多块吸收不产生额外 Hash，宏结束后不能继续发射。

扩展集成检查还包括 ABI 1/2/3 header 拒绝、非零保留字段、非法索引类型和计数器溢出；Verify 输入停顿、中断复位、重放、节点供应中断、签名/消息篡改、故障退出、lane 交换和关闭统计。输入截断以观察等待和后续恢复为准，不伪造内部超时。

## 结果与资源边界

结果位于 `build/micro/<tag>/`：images、vectors、models.json、rtl.json、逐项日志与 binary/source 哈希。单元结果写入该 TAG 的 units 目录。通过状态以本次生成的 JSON 和日志为准；本指南不替代实际运行证据。

共同核提取保留通用 Job、同步程序端口和 descriptor 端口。程序 ROM、descriptor、共享节点存储和外围签名缓存应明确列出是否计入面积；使用实际综合结果确认 BRAM 映射。综合面积不能视为布线频率，旧宏执行器的面积/周期也不代表新核测量。

ABI 2 与 `8fba9865` 的比较由 `python3 scripts/report_micro_typed.py --check` 核验，归档为 `manifests/micro/validation/20261015_typed/`。同频 ATP 采用两版合格周期的较大值，各自周期 ATP 另列。ABI 2 功能验收是切换默认实现的门槛，面积/周期退化须如实记录，不用旧 ABI 1 RTL兼容模式混合测量。

ABI 2 优化版与 `e340c0a2` 的比较见 [ABI 2 优化报告](report/Microprogram_Typed_Optimization.md)。其独立归档为 `manifests/micro/validation/20261015_typed_optimized/`，不覆盖首版 ABI 2 或更早的 ABI 1 记录：

```bash
python3 scripts/report_micro_typed_optimization.py --check
```

重新生成需要同一 TAG 的完整功能门禁、`hash_work`、单位/顶层结果、六参数综合及 OOC 布线：

```bash
python3 scripts/report_micro_typed_optimization.py --run build/micro/typed_opt_selected --synth build/micro/typed_opt_minimal/synthesis --route build/micro/typed_opt_minimal/route
```

优化版另保留 `SYNTHESIS` 条件编译模式核验。先生成同 TAG 的模型、正常 RTL 和向量，再运行：

```bash
python3 scripts/verify_micro_synthesis_mode.py --run build/micro/typed_opt_selected --profile all --jobs 3
```

默认只查 128f 的 Keygen/Sign/Verify；`--profile all` 查六参数三操作。此流程显式定义 `SYNTHESIS`，固定 K2U2 并开启统计，将完整输出、逐 Hash 轨迹及全部周期/指令计数与正常仿真模式比较。结果单独写入 TAG 的 `synthesis_mode/`，由优化归档核验，不改变标准 61 例的含义。

`--synth` / `--route` 可引用已冻结且与默认源码、实际镜像一致的综合与布线，避免复制 DCP。`--alternative <目录>` 可封存另一实现的正常操作、镜像/Job/输出、源码及完整物理测量；对比范围单独列明，不混入默认门禁。

可用 `--baseline-profile <JSON>` 附加首版镜像的逐指令开销分析，用 `--lane-ablation <目录>` 附加单 lane 的 source/report A/B 证据。检查器重新核对源文件、原始资源与最终采用的 RTL 身份；单模块面积不能替代最终共同核和布线测量。归档检查不依赖 build 目录，也不重新运行密码运算或 Vivado。

第二轮优化单独封存在 `manifests/micro/validation/20261015_typed_optimized_round2/`，以完整的上一轮归档为基线，比较范围与时序限制见[第二轮优化报告](report/Microprogram_Typed_Optimization_Round2.md)：

```bash
python3 scripts/report_micro_typed_optimization_round2.py --check
```

重新生成先完成同 TAG 的 61 例正常/扩展 RTL、单位、顶层、Hash 工作证明、SYNTHESIS 宏模式、六参数综合及 OOC 布线，再运行 `python3 scripts/report_micro_typed_optimization_round2.py --run build/micro/<tag>`。已有测量可通过 `--synth` 与 `--route` 指定；检查器要求其实际 RTL 和镜像与默认实现一致。该流程不会覆盖前一轮归档。

本次默认逐 bit TARGET 实现与共享窗口备选的完整封存命令为：

```bash
python3 scripts/report_micro_typed_optimization_round2.py --run build/micro/typed_opt2_best --alternative build/micro/typed_opt2_complete --lane-ablation build/micro/typed_opt2_hash
```

历史 ABI 1 已封存记录见[微程序处理器报告](report/Microprogram_Processor.md)。`python3 scripts/report_micro.py --check` 核验 `manifests/micro/validation/20261015/` 的文件及源码快照哈希，不依赖 build；该检查不重新运行仿真。

优化版与原版的资源、周期、消融和 ATP 对照见[优化报告](report/Microprogram_Optimization.md)，使用 `python3 scripts/report_micro_optimization.py --check` 核验。布线命令为：

```bash
python3 scripts/micro_route.py --synthesis build/micro/<tag>/synthesis --out build/micro/<tag>/route --period 20
```

该流程对一个已初始化的 128f 外壳执行 OOC 布线，回读物理 ROM，报告满足至少 0.1 ns setup 裕量的内部时钟周期及 hold。外部数据端口设 false path，因此它只衡量共同核时序，不代替板级接口约束。其余参数复用共同核的周期估算须与独立布线结果区分。

## v4.2 基线

`legacy-test`、`legacy-smoke`、`legacy-verify` 及 `legacy-synth-*`/`legacy-route-common` 使用 `manifests/v42_sources.txt` 和独立 legacy 顶层。`make reproduce-v42 reproduce-ku` 仍核验原始归档。[历史周期](v4.2/Cycles.md)和[历史面积](v4.2/LUT21k.md)只适用于其记录的源码与镜像。

## 固定 K1U1 的 ABI 2 历史实现

生产核只有一个物理 Hash lane、每周期一轮 Keccak。L0/L1 是逻辑结果槽，每次 HASH 必须显式选择且有效 mask 为 1 或 2；mask 0/3 不得启动 Hash。现版没有物理 lane swap，原 swap 扩展测试由 mask3 原子故障替代。利用率按一个物理 lane 的活动周期除以总周期，一次 Keccak 置换应计 24 个活动周期。

运行默认六参数模型、61 项正常与扩展 RTL 场景、单元、公共顶层和 SYNTHESIS 宏模式，仍使用上文 micro_flow/verify_micro_* 工具。串行替代镜像与默认镜像分别核对各自 VM 的有序 Hash 轨迹，算法输出与 Hash 工作集合对照独立参考；不能拿两个调度不同的有序轨迹互比。

本轮证据与不同配置成本口径见 [K1U1 优化报告](report/Microprogram_K1U1_Optimization.md)。独立归档核验：

```bash
python3 scripts/report_micro_k1u1_optimization.py --check
```

此前 K2U2 及 ABI 1/2 归档保持原样，其资源、活动周期与利用率沿用当时配置口径。

K1U1 第二轮的消息 LUTRAM、SHAKE 本地清零和 image 显式捕获循环优化独立封存在 `manifests/micro/validation/20261016_k1u1_round2/`。它以完整上一轮 K1U1 归档为基线，按相同配置重算六参数三操作的周期、布线面积和 ATP；普通核验命令为 `python3 scripts/report_micro_k1u1_round2.py --check`。消息单元额外覆盖长消息后紧跟短消息、三个 n、两种消息配方、末字垃圾及复位重放，确认无需清零的消息 RAM 不泄漏历史尾部。

K1U1 第三轮以第二轮不可变归档为比较基线，验证统一节点 RAM 的固定分区、跨地址搬运、边界故障原子性、复位有效位和未激活结果保持；另用 SYNTHESIS 宏模式运行，防止仿真观察视图掩盖真实读端口错误。64 bit 流式吸收继续检查完整 Hash 输入/结果，后续块增加的周期计入总周期及 ATP。新证据见 [K1U1 第三轮报告](report/Microprogram_K1U1_Round3.md)，核验命令为 `python3 scripts/report_micro_k1u1_round3.py --check`；此前归档不覆盖。

## ABI 3 单链宏历史实现

新增阻塞 CHAIN 的 FULL、CAP_FULL、CAP_PREFIX、SUFFIX 模式；树、链号推进、端点保存和输出保持 image 控制。普通 HASH/WAIT 继续单次执行。宏式、显式链与双逻辑槽调度镜像使用相同 RTL/binary；每种镜像分别与其 VM 有序 trace 对照，再与独立参考比较完整输出与 Hash 工作多重集。

宏单位覆盖全部 digit、n 与逻辑槽、空后缀、PRF 后立即截取、捕获终点重合、奇数末链、CURSOR 范围、两配方预检、在途冲突、运行中错误的架构状态原子性，以及宏内复位和重放。SYNTHESIS 宏模式核验真实 RAM 端口与同样的完整输出/逐 Hash trace；公共顶层继续检查签名缓存全部读回。

以 `a9b4e0e2` 与 `20261016_k1u1_round3` 不可变归档为基线，单独封存 ABI 3 镜像、源码、单位/协议/功能证据、六参数综合与整核布线。首测 100 MHz，同时报告合格频率和同频/各自频率 ATP；功能边界通过即切默认，不以 ATP 不退化为硬门槛。检查命令为 `python3 scripts/report_micro_chain_macro.py --check`。

## ABI 4 完整单棵 TREE

默认镜像只控制树之间的调度。TREE、显式树＋CHAIN、全显式三类 ABI 4 镜像及双逻辑槽、小树栈式/逐层实验使用同一 RTL/binary；每种镜像分别与 VM 的有序 Hash trace 对照，跨镜像使用完整输出和 Hash 输入/结果多重集比较。程序均须不超过 512 条。

TREE 单位和扩展门覆盖五种 kind/mode、TOP_SHORTCUT、digit 0…15、奇数链尾、首末叶、最大 FORS 高度、完整 64 位 TREE、全部配方预检、快照扰动、输入停顿、单次退休、宏内故障、缓存作废与复位重放。预检无副作用与运行中整 Job 终止分开验收。每次物理 Hash 具有普通 HASH/独立 CHAIN/TREE 归属，TREE 忙周期包括子链，统计不得重复相加。

当前冻结源码的完整验收、共同核综合和布线可按以下命令重跑：

```bash
python3 scripts/micro_flow.py all --tag tree_check --jobs 3 --extended
python3 scripts/verify_micro_units.py --out build/micro/tree_check/units
python3 scripts/verify_micro_synthesis_mode.py --run build/micro/tree_check --profile all --jobs 3
python3 scripts/micro_synth.py --out build/micro/tree_check/synthesis
python3 scripts/micro_route.py --synthesis build/micro/tree_check/synthesis --out build/micro/tree_check/route --period 10
```

新报告以 db659460 与其 CHAIN 优化封存证据为直接基线，采用相同器件、K1U1、缓存配置和至少 0.1 ns setup 裕量。只有 128f 实际布线，其余五参数明确采用冻结共同核估算。历史证据不覆盖；离线核验见 `python3 scripts/report_micro_tree_macro.py --check`，不依赖 Git、build 或 EDA。
