`timescale 1ns/1ps
`default_nettype none

// One SHAKE256 context per request. A context can absorb multiple rate blocks,
// but completion never starts another hash. The retained state is also the
// result register, so the caller can route a result back into a later request.
module shake_context #(
    parameter integer UNROLL = 1,
    parameter integer DIGEST_BYTES = 49
) (
    input wire clk, rst,
    input wire context_valid,
    output wire context_ready,
    input wire fast_block_valid,
    output wire fast_block_ready,
    input wire [1087:0] fast_block_data,
    input wire block_valid,
    output wire block_ready,
    input wire [63:0] block_data,
    input wire block_last,
    output logic response_valid,
    output wire [DIGEST_BYTES*8-1:0] response_digest
);
    localparam [1:0] IDLE=0, WAIT_BLOCK=1, RUN=2;
    logic [1:0] state;
    logic first_block, running_last;
    logic [4:0] append_index;
    logic [4:0] round_index;
    logic [1599:0] sponge_state;
    wire [1599:0] round_state [0:UNROLL];
    wire [1599:0] advanced_state=round_state[UNROLL];

    assign context_ready=state==IDLE;
    assign block_ready=state==WAIT_BLOCK;
    assign fast_block_ready=(state==IDLE && context_valid)
        || (state==WAIT_BLOCK && first_block && append_index==0);
    assign response_digest=sponge_state[DIGEST_BYTES*8-1:0];
    assign round_state[0]=sponge_state;
    genvar round_step;
    generate for(round_step=0;round_step<UNROLL;round_step=round_step+1) begin: rounds
        localparam [4:0] ROUND_OFFSET=round_step;
        (* keep_hierarchy="yes" *) keccak round_logic (
            .state_in(round_state[round_step]),
            .round_index(round_index+ROUND_OFFSET),
            .state_out(round_state[round_step+1])
        );
    end endgenerate

    wire take_fast=fast_block_valid && fast_block_ready;
    wire take_stream=block_valid && block_ready && !take_fast;
    wire clear_stream=take_stream && first_block && append_index==0;
    genvar word_index;
    generate for(word_index=0;word_index<25;word_index=word_index+1) begin: words
        wire select_stream=word_index<17 && take_stream && append_index==5'(word_index);
        wire [63:0] fast_word;
        if(word_index<17) assign fast_word=fast_block_data[word_index*64 +:64];
        else assign fast_word=64'd0;
        // Absorb directly into one selected word; the lane supplies one
        // 64-bit word per accepting edge, for seventeen edges per rate block.
        wire [63:0] input_word=block_data;
        // Only word zero is selected on the first streaming beat. Every
        // later rate word has already been cleared at that edge.
        wire [63:0] absorb_word=input_word
            ^ (sponge_state[word_index*64 +:64]
                & {64{word_index>=2 || !clear_stream}});
        if(word_index>=17) begin: capacity
            // Both input forms clear the capacity; use the FF clear input
            // rather than carrying a zero alternative through its data mux.
            always_ff @(posedge clk)
                if(!rst) begin
                    if(take_fast || clear_stream)
                        sponge_state[word_index*64 +:64]<=64'd0;
                    else if(state==RUN)
                        sponge_state[word_index*64 +:64]<=advanced_state[word_index*64 +:64];
                end
        end else begin: rate
            wire [63:0] next_word=take_fast ? fast_word
                : select_stream ? absorb_word : advanced_state[word_index*64 +:64];
            always_ff @(posedge clk)
                if(!rst) begin
                    if(clear_stream && !select_stream)
                        sponge_state[word_index*64 +:64]<=64'd0;
                    else if(state==RUN || take_fast || select_stream)
                        sponge_state[word_index*64 +:64]<=next_word;
                end
        end
    end endgenerate

    initial begin
        if(UNROLL<1 || UNROLL>24 || 24%UNROLL!=0)
            $error("single SHAKE context UNROLL must divide 24");
        if(DIGEST_BYTES<1 || DIGEST_BYTES>136)
            $error("single SHAKE context digest must fit one rate block");
    end
    always_ff @(posedge clk) begin
        if(rst) begin
            state<=IDLE;
            first_block<=1;
            running_last<=0;
            append_index<=0;
            round_index<=0;
            response_valid<=0;
        end else begin
            response_valid<=0;
            case(state)
                IDLE: if(context_valid) begin
                    first_block<=1;
                    append_index<=0;
                    if(take_fast) begin
                        running_last<=1;
                        round_index<=0;
                        state<=RUN;
                    end else state<=WAIT_BLOCK;
                end
                WAIT_BLOCK: if(take_fast) begin
                    running_last<=1;
                    round_index<=0;
                    state<=RUN;
                end else if(take_stream) begin
                    if(append_index==16) begin
                        append_index<=0;
                        running_last<=block_last;
                        round_index<=0;
                        state<=RUN;
                    end else append_index<=append_index+1'b1;
                end
                RUN: if(32'(round_index)+UNROLL>=24) begin
                    if(running_last) begin
                        response_valid<=1;
                        state<=IDLE;
                    end else begin
                        first_block<=0;
                        state<=WAIT_BLOCK;
                    end
                end else round_index<=round_index+5'(UNROLL);
                default:state<=IDLE;
            endcase
        end
    end
endmodule
`default_nettype wire
