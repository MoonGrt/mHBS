`line 1 "rtl/hash/keccak.sv" 1
`timescale 1ns / 1ps
`default_nettype none

`line 4 "rtl/hash/keccak.sv" 0
 
 
 
module keccak (
    input  wire [1599:0] state_in,
    input  wire [4:0]    round_index,
    output wire [1599:0] state_out
);
 
    wire [63:0] a[0:24];
    wire [63:0] c[0:4];
    wire [63:0] d[0:4];
    wire [63:0] rotated_a[0:24];
    wire [63:0] rotated_d[0:24];
    wire [63:0] rc;
    genvar x, y;

`line 21 "rtl/hash/keccak.sv" 0
    function automatic [63:0] rotl64;
        input [63:0] value;
        input integer amount;
        begin
            rotl64 = amount == 0 ? value : (value << amount) | (value >> (64 - amount));
        end
    endfunction

`line 29 "rtl/hash/keccak.sv" 0
    function automatic integer rho_offset;
        input integer lane;
        begin
            case (lane)
                0: rho_offset = 0;
                1: rho_offset = 1;
                2: rho_offset = 62;
                3: rho_offset = 28;
                4: rho_offset = 27;
                5: rho_offset = 36;
                6: rho_offset = 44;
                7: rho_offset = 6;
                8: rho_offset = 55;
                9: rho_offset = 20;
                10: rho_offset = 3;
                11: rho_offset = 10;
                12: rho_offset = 43;
                13: rho_offset = 25;
                14: rho_offset = 39;
                15: rho_offset = 41;
                16: rho_offset = 45;
                17: rho_offset = 15;
                18: rho_offset = 21;
                19: rho_offset = 8;
                20: rho_offset = 18;
                21: rho_offset = 2;
                22: rho_offset = 61;
                23: rho_offset = 56;
                24: rho_offset = 14;
                default: rho_offset = 0;
            endcase
        end
    endfunction

`line 63 "rtl/hash/keccak.sv" 0
    function automatic [63:0] round_constant;
        input [4:0] index;
        begin
            case (index)
                0: round_constant = 64'h0000000000000001;
                1: round_constant = 64'h0000000000008082;
                2: round_constant = 64'h800000000000808a;
                3: round_constant = 64'h8000000080008000;
                4: round_constant = 64'h000000000000808b;
                5: round_constant = 64'h0000000080000001;
                6: round_constant = 64'h8000000080008081;
                7: round_constant = 64'h8000000000008009;
                8: round_constant = 64'h000000000000008a;
                9: round_constant = 64'h0000000000000088;
                10: round_constant = 64'h0000000080008009;
                11: round_constant = 64'h000000008000000a;
                12: round_constant = 64'h000000008000808b;
                13: round_constant = 64'h800000000000008b;
                14: round_constant = 64'h8000000000008089;
                15: round_constant = 64'h8000000000008003;
                16: round_constant = 64'h8000000000008002;
                17: round_constant = 64'h8000000000000080;
                18: round_constant = 64'h000000000000800a;
                19: round_constant = 64'h800000008000000a;
                20: round_constant = 64'h8000000080008081;
                21: round_constant = 64'h8000000000008080;
                22: round_constant = 64'h0000000080000001;
                23: round_constant = 64'h8000000080008008;
                default: round_constant = 0;
            endcase
        end
    endfunction

`line 96 "rtl/hash/keccak.sv" 0
    assign rc = round_constant(round_index);
    generate
        for (y = 0; y < 5; y = y + 1) begin : map_y
            for (x = 0; x < 5; x = x + 1) begin : map_x
                localparam integer I = x + 5 * y;
                localparam integer DEST = y + 5 * ((2 * x + 3 * y) % 5);
                assign a[I] = state_in[64*I+:64];
                localparam integer NEXT  = ((x + 1) % 5) + 5 * y;
                localparam integer NEXT2 = ((x + 2) % 5) + 5 * y;
                wire [63:0] chi;
                assign rotated_a[DEST] = rotl64(a[I], rho_offset(I));
                assign rotated_d[DEST] = rotl64(d[x], rho_offset(I));
 
                
                
                
                               
                    
                       
                         
                         
                         
                        
                    
                    
                

`line 123 "rtl/hash/keccak.sv" 0
                assign chi = (rotated_a[I] ^ rotated_d[I]) ^ (
                    (~(rotated_a[NEXT] ^ rotated_d[NEXT])) & (rotated_a[NEXT2] ^ rotated_d[NEXT2]));

`line 126 "rtl/hash/keccak.sv" 0
                assign state_out[64*I+:64] = chi ^ (I == 0 ? rc : 64'd0);
            end
        end
        for (x = 0; x < 5; x = x + 1) begin : columns
            assign c[x] = a[x] ^ a[x+5] ^ a[x+10] ^ a[x+15] ^ a[x+20];
            assign d[x] = c[(x+4)%5] ^ rotl64(c[(x+1)%5], 1);
        end
    endgenerate
endmodule

`line 136 "rtl/hash/keccak.sv" 0
 
 



`line 141 "rtl/hash/keccak.sv" 0
     
         


`line 145 "rtl/hash/keccak.sv" 0
            




`line 150 "rtl/hash/keccak.sv" 0
`default_nettype wire

`line 152 "rtl/hash/keccak.sv" 2
`line 1 "rtl/hash/pipeline.sv" 1
`timescale 1ns / 1ps
`default_nettype none
 
 
 
module pipeline #(
 parameter integer PIPELINE=2,
 localparam integer TAG_BITS=PIPELINE>1 ? $clog2(PIPELINE) : 1
)(
 
    output logic [63:0] hash_count,permutation_count,

`line 13 "rtl/hash/pipeline.sv" 0
 input wire clk,rst,input wire [5:0] node_bytes,
 input wire request_valid,output wire request_ready,input wire [TAG_BITS-1:0] request_tag,
 input wire [4:0] request_steps,request_capture_after,input wire request_capture,
 input wire [1:0] request_family,input wire request_no_seed,
 input wire [3:0] request_start,input wire [255:0] request_initial_value,
 input wire [3:0] request_fixed_shape,input wire request_pair,
 input wire [255:0] request_right,
 input wire [127:0] identifier,
 input wire [255:0] secret_seed,public_seed,
 input wire [4:0] request_layer,input wire [63:0] request_tree,
 input wire [19:0] request_leaf,input wire [7:0] request_a,input wire [31:0] request_b,
 input wire [7:0] seed_domain,step_domain,
 input wire [TAG_BITS-1:0] read_tag,
 output wire [255:0] read_digest,read_capture,
 output wire response_valid,input wire response_ready,output logic [TAG_BITS-1:0] response_tag,
 output wire [255:0] response_digest,response_capture,
 output wire perm_valid,input wire perm_ready,output wire [1599:0] perm_state,
 output wire [TAG_BITS-1:0] perm_tag,input wire perm_done,input wire [1599:0] perm_digest,
 input wire [TAG_BITS-1:0] perm_result_tag
);
 
    function automatic [31:0] be32(input [31:0] v);
        be32 = {v[7:0], v[15:8], v[23:16], v[31:24]};
    endfunction
    wire [255:0] seed_address = {
        be32(request_b),
        be32({24'd0, request_a}),
        be32({12'd0, request_leaf}),
        be32({24'd0, seed_domain}),
        be32(request_tree[31:0]),
        be32(request_tree[63:32]),
        32'd0,
        be32({27'd0, request_layer})
    };
    wire [255:0] step_address = {
        be32(request_b),
        be32({24'd0, request_a}),
        be32({12'd0, request_leaf}),
        be32({24'd0, step_domain}),
        be32(request_tree[31:0]),
        be32(request_tree[63:32]),
        32'd0,
        be32({27'd0, request_layer})
    };
    wire [255:0] address[0:PIPELINE-1];
    logic [4:0] steps[0:PIPELINE-1], iteration[0:PIPELINE-1], capture_after[0:PIPELINE-1];
    logic [PIPELINE-1:0] busy, complete, capture_enable;
     
    logic [PIPELINE-1:0] preserve_counter;
    (* ram_style="distributed" *) logic [255:0] digest[0:PIPELINE-1];
    (* ram_style="distributed" *) logic [255:0] captured[0:PIPELINE-1];
     
     
    localparam [6:0] SEED = 7'b0000001, STEP = 7'b0000010, KEY = 7'b0000100,
        MASK = 7'b0001000, FINAL = 7'b0010000, MASK1 = 7'b0100000, SINGLE = 7'b1000000;
    wire [1:0] family[0:PIPELINE-1];
    wire [3:0] fixed_shape[0:PIPELINE-1];
    wire [PIPELINE-1:0] paired;
    logic [3:0] shared_shape;
    logic shared_pair;
    logic [6:0] phase[0:PIPELINE-1];
    (* ram_style="distributed" *) logic [255:0] key_value[0:PIPELINE-1];
    logic [PIPELINE-1:0] captured_valid, initial_pending, capture_initial;
    assign read_digest = initial_pending[read_tag] ? key_value[read_tag] : digest[read_tag];
    assign read_capture = captured_valid[read_tag] ?
        (capture_initial[read_tag] ? key_value[read_tag] : captured[read_tag]) : 256'd0;
    wire [TAG_BITS-1:0] t = perm_result_tag;
    logic [PIPELINE-1:0] node_phase, more_steps;
    wire node_done = node_phase[t];
    wire again = perm_done && (!node_done || more_steps[t]);
    wire capture_now = perm_done && node_done && capture_enable[t] &&
        iteration[t] == capture_after[t];
    wire [6:0] next_phase = phase[t][2] ? MASK : phase[t][3] ?
        (paired[t] ? MASK1 : FINAL) : phase[t][5] ? FINAL : family[t] == 1 ? KEY : STEP;
    wire [4:0] next_step = node_done ? iteration[t] : iteration[t] - 1'b1;
    logic [255:0] next_address;
    always_comb begin
        next_address = address[t];
        if (!preserve_counter[t]) next_address[224+:32] = be32({27'd0, next_step});
    end
    assign request_ready = !rst && !again && perm_ready && request_tag < PIPELINE &&
        (!busy[request_tag] || (response_valid && response_ready && response_tag == request_tag));
    wire accept = request_valid && request_ready;
    wire [3:0] requested_shape = request_fixed_shape;
    wire requested_pair = request_pair;
    wire zero_request = request_no_seed && request_steps == 0 && requested_shape == 0;
    assign perm_valid = again || (accept && !zero_request);
     
    wire [255:0]
        block_address = again ? next_address : request_no_seed ? step_address : seed_address;
    wire [1:0] block_family = again ? family[t] : request_family;
    wire [6:0] first_phase = requested_shape == 8 ? KEY : requested_shape == 7 ? SEED :
        requested_shape != 0 ? SINGLE : !request_no_seed ? SEED : request_family == 1 ? KEY : STEP;
    wire [6:0] block_phase = again ? next_phase : first_phase;
    wire [3:0] block_step = again ? next_step[3:0] : request_start;
    wire [3:0] block_shape = again ? fixed_shape[t] : requested_shape;
    wire block_pair = again ? paired[t] : requested_pair;
    wire [255:0] block_value = again ? (phase[t][5] ? digest[t] : phase[t][3] ?
                                        digest[t] ^ perm_digest[255:0] : perm_digest[255:0]) :
        requested_shape == 1 || requested_shape == 9 ? secret_seed :
        request_no_seed ? request_initial_value : secret_seed;
    wire [255:0] block_right = again ? captured[t] ^ perm_digest[255:0] : request_right;
    wire [1599:0] unified_state;
    generate
        begin : formatter
            logic [255:0] f0, f1, f2, f3, masked_address;
            logic [183:0] prefix;
            logic [7:0] domain;
            logic [1:0] layout;
            logic two;
            logic [1599:0] data;
            wire seed = block_phase[0] || block_shape == 7;
            wire prf = block_phase[2] || block_phase[3] || block_phase[5];
            always_comb begin
                masked_address = {
                    be32(block_phase[3] ? 32'd1 : block_phase[5] ? 32'd2 : 32'd0),
                    block_shape != 0 ? block_address[255:224] : be32({28'd0, block_step}),
                    block_address[223:192],
                    block_address[191:160],
                    block_address[159:128],
                    96'd0
                };
                f0 = public_seed;
                f1 = block_address;
                f2 = block_value;
                f3 = block_right;
                layout = 0;
                two = block_pair;
                prefix = 0;
                domain = 0;
                if (block_family == 1) begin
                    layout = 1;
                    domain = block_shape == 5 || prf ? 8'd3 :
                        seed ? 8'd4 : block_pair ? 8'd1 : 8'd0;
                    f1 = block_shape == 5 ? block_value :
                        seed ? secret_seed : prf ? public_seed : key_value[t];
                    f2 = block_shape == 5 ? {block_address[191:160], 224'd0} :
                        seed ? public_seed : prf ? masked_address : block_value;
                    f3 = seed ? masked_address : block_right;
                    two = seed || (block_pair && !prf);
                end else if (block_family == 2) begin
                    if (block_shape == 14 || block_shape == 15) begin
                        layout = 3;
                        prefix = {
                            8'd0,
                            block_shape == 14 ? 16'h8282 : 16'h8383,
                            block_address[255:224],
                            identifier
                        };
                    end else begin
                        layout = 2;
                        two = 0;
                        prefix = {
                            (seed || block_shape == 9) ? 8'hff :
                                block_shape == 10 ? block_address[255:248] : {4'd0, block_step},
                            block_address[223:216],
                            8'd0,
                            block_address[191:160],
                            identifier
                        };
                    end
                    f1 = block_value;
                    f2 = block_right;
                end
                data = 0;
                case (node_bytes)
                    16: begin
                        data[511:0] = {block_value[127:0], block_address, public_seed[127:0]};
                        if (two) begin
                            data[639:512] = block_right[127:0];
                            data[647:640] = 8'h1f;
                        end else data[519:512] = 8'h1f;
                    end
                    24: begin
                        data[639:0] = {block_value[191:0], block_address, public_seed[191:0]};
                        if (two) begin
                            data[831:640] = block_right[191:0];
                            data[839:832] = 8'h1f;
                        end else data[647:640] = 8'h1f;
                    end
                    default:
                    case (layout)
                        0: begin
                            data[767:0] = {f2, f1, f0};
                            if (two) begin
                                data[1023:768]  = f3;
                                data[1031:1024] = 8'h1f;
                            end else data[775:768] = 8'h1f;
                        end
                        1: begin
                            data[255:248] = domain;
                            data[511:256] = f1;
                            data[767:512] = f2;
                            if (two) begin
                                data[1023:768]  = f3;
                                data[1031:1024] = 8'h1f;
                            end else data[775:768] = 8'h1f;
                        end
                        2: begin
                            data[183:0]   = prefix;
                            data[439:184] = f1;
                            data[447:440] = 8'h1f;
                        end
                        3: begin
                            data[175:0]   = prefix[175:0];
                            data[431:176] = f1;
                            if (two) begin
                                data[687:432] = f2;
                                data[695:688] = 8'h1f;
                            end else data[439:432] = 8'h1f;
                        end
                    endcase
                endcase
                data[1087] = 1;
            end
            assign unified_state = data;
        end
    endgenerate
    assign perm_state = unified_state;
    assign perm_tag   = again ? t : request_tag;
    logic response_held;
    logic [TAG_BITS-1:0] held_tag;
    assign response_valid = |complete;
    always_comb begin
        response_tag = 0;
        for (integer j = PIPELINE - 1; j >= 0; j = j - 1)
        if (complete[j]) response_tag = TAG_BITS'(j);
        if (response_held) response_tag = held_tag;
    end
    assign response_digest = initial_pending[response_tag] ? key_value[response_tag] :
        digest[response_tag];
    assign response_capture = captured_valid[response_tag] ?
        (capture_initial[response_tag] ? key_value[response_tag] : captured[response_tag]) : 256'd0;
     
     
    wire key_return = perm_done && phase[t][2];
    wire initial_transfer = key_return && initial_pending[t];
    wire key_write = key_return || (accept && request_no_seed);
    wire [TAG_BITS-1:0] key_write_tag = key_return ? t : request_tag;
    wire [255:0] key_write_data = key_return ? perm_digest[255:0] : request_initial_value;
    wire mask_left = perm_done && paired[t] && phase[t][3];
    wire digest_write = perm_done && (node_done || initial_transfer || mask_left);
    wire [255:0] digest_write_data = initial_transfer ? key_value[t] :
        mask_left ? digest[t] ^ perm_digest[255:0] : perm_digest[255:0];
    wire capture_transfer = initial_transfer && capture_initial[t];
    wire right_write = accept && requested_pair && requested_shape == 8;
    wire captured_write = capture_now || capture_transfer || right_write;
    wire [TAG_BITS-1:0] captured_write_tag = right_write ? request_tag : t;
    wire [255:0] captured_write_data = right_write ? request_right :
        capture_transfer ? key_value[t] : perm_digest[255:0];
    always_ff @(posedge clk) begin
        if (!rst) begin
            if (key_write) key_value[key_write_tag] <= key_write_data;
            if (digest_write) digest[t] <= digest_write_data;
            if (captured_write) captured[captured_write_tag] <= captured_write_data;
        end
    end
    always_ff @(posedge clk) begin
        if (rst) begin
            node_phase <= 0;
            more_steps <= 0;
            initial_pending <= 0;
            capture_initial <= 0;
            captured_valid <= 0;
            response_held <= 0;
            held_tag <= 0;
            busy <= 0;
            complete <= 0;
            capture_enable <= 0;
            preserve_counter <= 0;
        end else begin
            if (response_valid && !response_ready && !response_held) begin
                response_held <= 1;
                held_tag <= response_tag;
            end
            if (response_valid && response_ready) response_held <= 0;
            if (response_valid && response_ready) begin
                complete[response_tag] <= 0;
                busy[response_tag] <= 0;
            end
            if (accept) begin
                busy[request_tag] <= 1;
                steps[request_tag] <= request_steps + {1'b0, request_start};
                iteration[request_tag] <= request_no_seed ? {1'b0, request_start} + 1'b1 : 5'd0;
                phase[request_tag] <= first_phase;
                node_phase[request_tag] <= first_phase[0] || first_phase[1] ||
                    first_phase[6];
                more_steps[request_tag] <= request_no_seed ? request_steps > 1 : request_steps != 0;
                if (busy == 0) begin
                    shared_shape <= requested_shape;
                    shared_pair <= requested_pair;
                end
                preserve_counter[request_tag] <= step_domain == 3 || requested_shape != 0;
                initial_pending[request_tag] <= request_no_seed;
                if (zero_request) complete[request_tag] <= 1;
                capture_after[request_tag]   <= request_capture_after;
                capture_enable[request_tag]  <= request_capture;
                captured_valid[request_tag]  <= 0;
                capture_initial[request_tag] <= 0;
                if (request_no_seed && request_capture &&
                    request_capture_after == {1'b0, request_start}) begin
                    capture_initial[request_tag] <= 1;
                    captured_valid[request_tag]  <= 1;
                end
            end
            if (perm_done) begin
                if (capture_now) begin
                    capture_initial[t] <= 0;
                    captured_valid[t]  <= 1;
                end
                if (capture_transfer) capture_initial[t] <= 0;
                if (digest_write) initial_pending[t] <= 0;
                if (again) begin
                    phase[t] <= next_phase;
                    node_phase[t] <= next_phase[0] || next_phase[1] ||
                        next_phase[4] || next_phase[6];
                    if (node_done) more_steps[t] <= iteration[t] + 1'b1 < steps[t];
                    if (node_done) iteration[t] <= iteration[t] + 1'b1;
                end else complete[t] <= 1;
            end
        end
    end
    generate
        begin : shared_coordinates
            logic [4:0] layer;
            logic [63:0] tree;
            logic [7:0] domain;
            logic [1:0] kind;
            logic [19:0] leaves[0:PIPELINE-1];
            logic [7:0] chains[0:PIPELINE-1];
            logic [31:0] indices[0:PIPELINE-1];
            always_ff @(posedge clk)
                if (!rst && accept) begin
                    if (busy == 0) begin
                        layer  <= request_layer;
                        tree   <= request_tree;
                        domain <= step_domain;
                        kind   <= request_family;
                    end
                    leaves[request_tag]  <= request_leaf;
                    chains[request_tag]  <= request_a;
                    indices[request_tag] <= request_b;
                end
 
            always @(posedge clk)
                if (!rst && accept && |busy) begin
                    if (request_layer != layer || request_tree != tree || request_family != kind ||
                        step_domain != domain || requested_shape != shared_shape ||
                        requested_pair != shared_pair)
                        $fatal(1, "shared coordinates changed before contexts drained");
                end

`line 365 "rtl/hash/pipeline.sv" 0
            for (genvar j = 0; j < PIPELINE; j++) begin
                assign address[j] = {
                    be32(indices[j]),
                    be32({24'd0, chains[j]}),
                    be32({12'd0, leaves[j]}),
                    be32({24'd0, domain}),
                    be32(tree[31:0]),
                    be32(tree[63:32]),
                    32'd0,
                    be32({27'd0, layer})
                };
                assign family[j] = kind;
                assign fixed_shape[j] = shared_shape;
                assign paired[j] = shared_pair;
            end
        end
    endgenerate
 
     
    always_ff @(posedge clk) begin : debug_statistics
        if (rst) begin
            hash_count <= 0;
            permutation_count <= 0;
        end else if (perm_done) begin
            hash_count <= hash_count + 1'b1;
            permutation_count <= permutation_count + 1'b1;
        end
    end

`line 394 "rtl/hash/pipeline.sv" 0
endmodule
`default_nettype wire

`line 397 "rtl/hash/pipeline.sv" 2
`line 1 "rtl/hash/recipe.sv" 1
`timescale 1ns / 1ps
`default_nettype none
 
 
 
module recipe #(
    parameter integer N = 16,
    parameter integer DIGEST_BYTES = N==16 ? 34 : 32, INDEX_BITS = 7,
    parameter integer UNROLL = 2, PIPELINE = 1,
    parameter integer MAX_MESSAGE_BYTES = 87,
    parameter [15:0] RECIPE_MASK = 16'hffff,
    parameter bit SHARED_STATE=0,
    localparam integer TAG_BITS=PIPELINE>1 ? $clog2(PIPELINE) : 1
) (
 
    output wire [63:0] batch_hashes,batch_permutations,
    output logic [63:0] hash_count,permutation_count,

`line 19 "rtl/hash/recipe.sv" 0
    input wire clk, rst,
    input wire batch_mode,batch_request_valid,output wire batch_request_ready,
    input wire [TAG_BITS-1:0] batch_request_tag,
    input wire [4:0] batch_steps,batch_capture_after,input wire batch_capture_enable,
    input wire [19:0] batch_leaf,input wire [7:0] batch_a,input wire [31:0] batch_b,
    input wire [1:0] batch_family,input wire batch_no_seed,
    input wire [3:0] batch_start,input wire [255:0] batch_initial_value,
    input wire [3:0] batch_fixed_shape,input wire batch_pair,input wire [255:0] batch_right,
    input wire [7:0] batch_seed_domain,batch_step_domain,
    output wire batch_response_valid,input wire batch_response_ready,
    output wire [TAG_BITS-1:0] batch_response_tag,
    output wire [255:0] batch_response_digest,batch_response_capture,
    input wire [TAG_BITS-1:0] batch_read_tag,
    output wire [255:0] batch_read_digest,batch_read_capture,
    input wire [5:0] node_bytes,
    input wire request_valid, output wire request_ready,
    input wire [63:0] request_recipe, request_step_recipe,
    input wire request_chain,
    input wire [4:0] request_steps, request_capture_after,
    input wire request_capture,
    input wire [N*8-1:0] secret_seed, secret_prf, public_seed, root, randomizer,
    input wire [127:0] identifier,
    input wire [MAX_MESSAGE_BYTES*8-1:0] message_buffer,
    input wire [6:0] message_length,
    input wire [4:0] request_layer,
    input wire [63:0] request_tree,
    input wire [19:0] request_leaf,
    input wire [INDEX_BITS-1:0] request_a,
    input wire [31:0] request_b,
    input wire [N*8-1:0] request_left, request_right,
    output wire [INDEX_BITS-1:0] list_index0, list_index1,list_next_index0,
    input wire [N*8-1:0] list_data0, list_data1,
    output wire response_valid, input wire response_ready,
    output wire [DIGEST_BYTES*8-1:0] response_value,
    output wire [N*8-1:0] response_capture,
    output logic error
);
 
    localparam [3:0] ADDRESS_SEED = 1,
        ADDRESS_VALUE = 2, MESSAGE_PRF = 3, MESSAGE_DIGEST = 4, INDEX_PRF = 5, ROOT_MESSAGE = 6,
        MASKED_SEED = 7, MASKED_VALUE = 8, PREFIX_SEED = 9, PREFIX_VALUE = 10, PREFIX_MESSAGE = 11,
        ADDRESS_LIST = 12, PREFIX_LIST = 13, PREFIX_LEAF = 14, PREFIX_PARENT = 15;
    typedef enum logic [2:0] {
        IDLE,
        START,
        STREAM,
        WAIT_HASH,
        RESPONSE,
        FIXED_ISSUE,
        FIXED_WAIT
    } state_t;
    state_t state;
    localparam bit STREAM_ENABLE = (RECIPE_MASK & 16'h3858) != 0;
    logic [4:0] rate_block;
    logic [3:0] beat;
    wire [63:0] recipe = request_recipe;
    logic [15:0] seed_shapes;
    logic [12:0] seed_length;
    logic [2:0] stream_node_words;
    wire [15:0] shapes = seed_shapes;
     
     
     
     
    function automatic [12:0] decode_length(input [63:0] desc);
        reg [12:0] nodes;
        begin
            nodes = node_bytes == 16 ? {1'b0, desc[47:40], 4'b0} : node_bytes == 24 ?
                ({1'b0, desc[47:40], 4'b0} + {2'b0, desc[47:40], 3'b0}) : {desc[47:40], 5'b0};
            if (!STREAM_ENABLE || !RECIPE_MASK[desc[59:56]]) decode_length = 0;
            else
                case (desc[59:56])
                    ADDRESS_SEED: decode_length = node_bytes + 32 + node_bytes;
                    ADDRESS_VALUE, ADDRESS_LIST: decode_length = node_bytes + 32 + nodes;
                    MESSAGE_PRF: decode_length = 2 * node_bytes + message_length;
                    MESSAGE_DIGEST: decode_length = 3 * node_bytes + message_length;
                    INDEX_PRF: decode_length = 96;
                    ROOT_MESSAGE: decode_length = 128 + message_length;
                    MASKED_SEED: decode_length = 128;
                    MASKED_VALUE: decode_length = 13'd64 + {desc[47:40], 5'd0};
                    PREFIX_SEED, PREFIX_VALUE: decode_length = 55;
                    PREFIX_MESSAGE: decode_length = 54 + message_length;
                    PREFIX_LIST: decode_length = 13'd22 + {desc[47:40], 5'd0};
                    PREFIX_LEAF: decode_length = 54;
                    PREFIX_PARENT: decode_length = 86;
                    default: decode_length = 0;
                endcase
        end
    endfunction
    always_ff @(posedge clk) begin
        if (!rst && state == IDLE && request_valid) begin
            seed_shapes <= (16'b1 << request_recipe[59:56]) & RECIPE_MASK;
            seed_length <= decode_length(request_recipe);
            stream_node_words <= node_bytes[5:3];
        end
    end
    wire [7:0] domain = recipe[55:48];
    wire [31:0] a = request_a, b = request_b;
    wire [31:0] leaf = {12'd0, request_leaf};
    wire [12:0] input_length = seed_length;
    wire [5:0] stream_node_bytes = {stream_node_words, 3'b0};
    logic [127:0] stream_data;
    wire [255:0] address = {
        be32(b),
        be32(a),
        be32(leaf),
        be32({24'd0, domain}),
        be32(request_tree[31:0]),
        be32(request_tree[63:32]),
        32'd0,
        be32({27'd0, request_layer})
    };
    wire [12:0] rate_offset = ({8'd0, rate_block} << 7) + ({8'd0, rate_block} << 3);
    wire stream_last = rate_offset + 13'd136 > input_length;
    wire hash_ready, block_ready, finish_valid;
    wire [DIGEST_BYTES*8-1:0] digest;
    wire completed = finish_valid;
    assign response_value = bridge_response ?
        {{(DIGEST_BYTES * 8 - N * 8) {1'b0}}, engine_digest[N*8-1:0]} : digest;
    assign response_capture = engine_capture[N*8-1:0];
    wire [7:0] prefix_bytes = shapes[ADDRESS_LIST] ? stream_node_bytes + 32 : 22;
    logic staged_valid, staged_last;
    logic [127:0] staged_data;
    wire stream_accept = !staged_valid || block_ready;
     
     
     
    logic [12:0] position;
    logic [INDEX_BITS-1:0] list_cursor;
    logic [5:0] list_remainder;
    wire [4:0] stream_advance = beat != 8 ? 5'd16 : 5'd8;
    wire [6:0] next_remainder = {1'b0, list_remainder} + stream_advance;
    assign list_index0 = list_cursor;
    assign list_next_index0 = state == IDLE && request_valid ? INDEX_BITS'(0) :
        state == STREAM && stream_accept && position >= prefix_bytes &&
        next_remainder >= stream_node_bytes ? list_cursor + 1'b1 : list_cursor;
    assign list_index1 = list_index0 + 1'b1;
    assign request_ready = state == IDLE && (!scalar_fixed || (!batch_mode && engine_ready));
    assign response_valid = state == RESPONSE || (state == FIXED_WAIT && engine_valid);

`line 159 "rtl/hash/recipe.sv" 0
    function automatic [31:0] be32(input [31:0] value);
        be32 = {value[7:0], value[15:8], value[23:16], value[31:24]};
    endfunction
     
     
    wire [2:0] node_words = stream_node_words;
    wire [703:0] padded_message = {8'd0, message_buffer};
     
     
     
    function automatic [63:0] node_word(input [255:0] data, input [1:0] index);
        begin
            case (index)
                0: node_word = data[63:0];
                1: node_word = data[127:64];
                2: node_word = data[191:128];
                default: node_word = data[255:192];
            endcase
        end
    endfunction
    function automatic [63:0] message_word(input [5:0] index);
        begin
            message_word = index < 11 ? padded_message[index*64+:64] : 64'd0;
        end
    endfunction
     
     
     
    function automatic [12:0] decode_source(input [5:0] index, input bit lms_only);
        reg [2:0] source;
        reg [5:0] selected_index;
        reg [3:0] literal;
        begin
            source = 0;
            selected_index = index;
            literal = 0;
            (* parallel_case *) case (1'b1)
                shapes[MESSAGE_PRF]:
                if (!lms_only && RECIPE_MASK[MESSAGE_PRF]) begin
                    if (index < node_words) source = 1;
                    else if (index < 2 * node_words) begin
                        source = 2;
                        selected_index = index - node_words;
                    end else begin
                        source = 5;
                        selected_index = index - 2 * node_words;
                    end
                end
                shapes[MESSAGE_DIGEST]:
                if (!lms_only && RECIPE_MASK[MESSAGE_DIGEST]) begin
                    if (index < node_words) source = 2;
                    else if (index < 2 * node_words) begin
                        source = 3;
                        selected_index = index - node_words;
                    end else if (index < 3 * node_words) begin
                        source = 4;
                        selected_index = index - 2 * node_words;
                    end else begin
                        source = 5;
                        selected_index = index - 3 * node_words;
                    end
                end
                shapes[ROOT_MESSAGE]:
                if (!lms_only && RECIPE_MASK[ROOT_MESSAGE]) begin
                    if (index == 3) literal = 4'd1;
                    else if (index < 4) literal = 0;
                    else if (index < 8) begin
                        source = 2;
                        selected_index = index - 4;
                    end else if (index < 12) begin
                        source = 4;
                        selected_index = index - 8;
                    end else if (index == 15) literal = 4'd2;
                    else if (index >= 16) begin
                        source = 5;
                        selected_index = index - 16;
                    end
                end
                shapes[PREFIX_MESSAGE]:
                if (RECIPE_MASK[PREFIX_MESSAGE]) begin
                     
                     
                    if (index >= 3 && index < 7) begin
                        source = 2;
                        selected_index = index - 3;
                    end else if (index >= 7) begin
                        source = 5;
                        selected_index = index - 7;
                    end
                end
                shapes[ADDRESS_LIST]:
                if (!lms_only && RECIPE_MASK[ADDRESS_LIST]) begin
                    if (index < node_words) source = 3;
                    else if (index < node_words + 4) begin
                        source = 6;
                        selected_index = index - node_words;
                    end else begin
                        source = 7;
                        selected_index = index - node_words - 4;
                    end
                end
                shapes[PREFIX_LIST]:
                if (!lms_only && RECIPE_MASK[PREFIX_LIST]) begin
                    case (index)
                        0: literal = 4'd3;
                        1: literal = 4'd4;
                        2: literal = 4'd5;
                        3: literal = 4'd6;
                        default: literal = 0;
                    endcase
                end
                default: begin
                end
            endcase
            decode_source = {literal, source, selected_index};
        end
    endfunction
     
     
     
    logic [12:0] source_control[0:2];
    wire [12:0] following_position = position + 13'(stream_advance);
    for (genvar word_slot = 0; word_slot < 3; word_slot++) begin : source_selectors
        always_ff @(posedge clk)
            if (!rst) begin
                if (state == START && hash_ready)
                    source_control[word_slot] <= decode_source(6'(word_slot), word_slot == 2);
                else if (state == STREAM && stream_accept)
                    source_control[word_slot] <= decode_source(
                        following_position[8:3] + 6'(word_slot), word_slot == 2);
            end
    end
    function automatic [63:0] source_word(input [12:0] control);
        reg [63:0] literal;
        reg [5:0] selected_index;
        begin
            selected_index = control[5:0];
            case (control[12:9])
                1: literal = 64'h0200000000000000;
                2: literal = {be32(leaf), 32'd0};
                3: literal = identifier[63:0];
                4: literal = identifier[127:64];
                5: literal = {list_data0[15:0], 16'h8080, be32(leaf)};
                6: literal = list_data0[79:16];
                default: literal = 0;
            endcase
            case (control[8:6])
                1: source_word = node_word(secret_prf, selected_index[1:0]);
                2: source_word = node_word(randomizer, selected_index[1:0]);
                3: source_word = node_word(public_seed, selected_index[1:0]);
                4: source_word = node_word(root, selected_index[1:0]);
                5: source_word = message_word(selected_index);
                6: source_word = node_word(address, selected_index[1:0]);
                7: source_word = node_word(list_data0, selected_index[1:0]);
                default: source_word = literal;
            endcase
        end
    endfunction
    logic [511:0] list_pair;
    always @* begin
        case (stream_node_bytes)
            16: list_pair = {256'd0, list_data1[127:0], list_data0[127:0]};
            24: list_pair = {128'd0, list_data1[191:0], list_data0[191:0]};
            default: list_pair = {list_data1, list_data0};
        endcase
    end
     
     
    logic [143:0] list_word_window;
    always @* begin
        case (list_remainder[4:3])
            0: list_word_window = list_pair[143:0];
            1: list_word_window = list_pair[207:64];
            2: list_word_window = list_pair[271:128];
            default: list_word_window = list_pair[335:192];
        endcase
    end
     
    wire [127:0] list_window = RECIPE_MASK[PREFIX_LIST] ? (
        list_remainder[1] ? list_word_window[143:16] : list_word_window[127:0]) : {64'd0, node_word(
        list_data0, list_remainder[4:3]
    )};
    logic [127:0] stream_payload;
    logic [191:0] source_window;
    always_comb begin
        source_window = {
            source_word(source_control[2]),
            source_word(source_control[1]),
            source_word(source_control[0])
        };
        stream_payload = source_window[127:0];
        if (shapes[PREFIX_MESSAGE]) begin
            stream_payload = source_window[143:16];
            if (position == 0) stream_payload = identifier;
            else if (position == 16) stream_payload[47:0] = {16'h8181, be32(leaf)};
        end else if ((shapes[ADDRESS_LIST] || shapes[PREFIX_LIST]) && position >= prefix_bytes)
            stream_payload = list_window;
    end

`line 358 "rtl/hash/recipe.sv" 0
     
     
    wire [12:0] remaining_bytes = input_length - position;
    wire padding_reached = position > input_length;
    wire partial_beat = remaining_bytes < 16;
    always_comb begin
        stream_data = stream_payload;
        for (integer i = 0; i < 16; i++) begin
            if (padding_reached || (partial_beat && remaining_bytes[3:0] <= 4'(i)))
                stream_data[i*8+:8] = 0;
            if (!padding_reached && partial_beat && remaining_bytes[3:0] == 4'(i))
                stream_data[i*8+:8] = 8'h1f;
            if (beat == 8) begin
                if (i >= 8) stream_data[i*8+:8] = 0;
                else if (i == 7 && stream_last) stream_data[i*8+7] = 1'b1;
            end
        end
    end

`line 377 "rtl/hash/recipe.sv" 0
    wire batch_perm_valid, batch_perm_ready, batch_perm_done;
    wire [1599:0] batch_perm_state, batch_perm_digest;
    wire [TAG_BITS-1:0] batch_perm_tag, batch_perm_result_tag;
    logic bridge_response;
     
     
    wire scalar_bridge = bridge_response ||
        (!batch_mode && state == IDLE && request_valid && scalar_fixed);
    wire engine_mode = batch_mode || scalar_bridge;
    wire engine_ready, engine_valid;
    wire [255:0] engine_digest, engine_capture;
    wire [3:0] scalar_shape = request_recipe[59:56];
    wire scalar_fixed = RECIPE_MASK[scalar_shape] &&
        (scalar_shape == 1 || scalar_shape == 2 || scalar_shape == 5 || scalar_shape == 7 ||
         scalar_shape == 8 || scalar_shape == 9 || scalar_shape == 10 || scalar_shape == 14 ||
         scalar_shape == 15);
    wire scalar_no_seed = !(request_chain && (scalar_shape == 1 || scalar_shape == 7 ||
                                              scalar_shape == 9)) && scalar_shape != 7;
    wire [1:0] scalar_family = (scalar_shape == 1 || scalar_shape == 2) ? 2'd0 :
        (scalar_shape == 9 || scalar_shape == 10 || scalar_shape == 14 || scalar_shape == 15) ?
        2'd2 : 2'd1;
    assign batch_request_ready = engine_ready && !scalar_bridge;
    assign batch_response_valid = engine_valid && !scalar_bridge;
    assign batch_read_digest = engine_digest;
    assign batch_read_capture = engine_capture;
    generate
        begin : chain_pipeline
             
            pipeline #(.PIPELINE(PIPELINE)) engine(
 
                .hash_count(batch_hashes),.permutation_count(batch_permutations),

`line 409 "rtl/hash/recipe.sv" 0
                .clk,.rst,.node_bytes,
                .request_valid(scalar_bridge ? state==IDLE && request_valid : batch_request_valid),.request_ready(engine_ready),
                .request_tag(scalar_bridge ? TAG_BITS'(0) : batch_request_tag),
                .request_steps(scalar_bridge ? (request_chain ? request_steps : 5'd0) : batch_steps),
                .request_capture_after(scalar_bridge ? (request_chain ? request_capture_after : scalar_no_seed ? 5'd1 : 5'd0) : batch_capture_after),
                .request_capture(scalar_bridge ? request_capture : batch_capture_enable),.secret_seed,.public_seed,
                .request_family(scalar_bridge ? scalar_family : batch_family),
                .request_no_seed(scalar_bridge ? scalar_no_seed : batch_no_seed),
                .request_start(scalar_bridge ? 4'd0 : batch_start),
                .request_fixed_shape(scalar_bridge ? (request_chain ? 4'd0 : scalar_shape) : batch_fixed_shape),
                .request_pair(scalar_bridge ? request_recipe[47:40]==2 : batch_pair),
                .request_right(scalar_bridge ? 256'(request_right) : batch_right),
                .request_initial_value(scalar_bridge ? (scalar_shape==5 ? 256'(secret_prf) : 256'(request_left)) : batch_initial_value),.identifier,
                .request_layer,.request_tree,
                .request_leaf(scalar_bridge ? request_leaf : batch_leaf),
                .request_a(scalar_bridge ? 8'(request_a) : batch_a),.request_b(scalar_bridge ? request_b : batch_b),
                .seed_domain(scalar_bridge ? request_recipe[55:48] : batch_seed_domain),
                .step_domain(scalar_bridge ? (request_chain ? request_step_recipe[55:48] : request_recipe[55:48]) : batch_step_domain),
                .response_valid(engine_valid),.response_ready(scalar_bridge ? state==FIXED_WAIT && response_ready : batch_response_ready),
                .response_tag(batch_response_tag),.response_digest(),.response_capture(),
                .read_tag(scalar_bridge ? TAG_BITS'(0) : batch_read_tag),.read_digest(engine_digest),.read_capture(engine_capture),
                .perm_valid(batch_perm_valid),.perm_ready(batch_perm_ready),.perm_state(batch_perm_state),.perm_tag(batch_perm_tag),
                .perm_done(batch_perm_done),.perm_digest(batch_perm_digest),.perm_result_tag(batch_perm_result_tag)
            );
             
            assign batch_response_digest  = engine_digest;
            assign batch_response_capture = engine_capture;
        end
    endgenerate
     
    localparam logic [1:0] HASH_IDLE = 2'd0;
    localparam logic [1:0] HASH_WAIT_BLOCK = 2'd1;
    localparam logic [1:0] HASH_RUN = 2'd2;

`line 443 "rtl/hash/recipe.sv" 0
    logic [1:0] hash_state;
    logic first_block, running_last;
    logic [3:0] append_index;
    wire [24:0] state_write_enable;
    wire [1599:0] state_write_data;
    logic [1599:0] sponge_state;
    logic [4:0] round_index;
    wire [1599:0] advanced_state;
    wire round_complete, round_update;
    logic p1_busy;
    logic [4:0] p1_round;
    wire p1_done = p1_busy && p1_round + UNROLL >= 24;
    always_ff @(posedge clk) begin
        if (rst) begin
            p1_busy  <= 0;
            p1_round <= 0;
        end else if (PIPELINE == 1) begin
            if (batch_perm_valid && batch_perm_ready) begin
                p1_busy  <= 1;
                p1_round <= 0;
            end else if (p1_done) p1_busy <= 0;
            else if (p1_busy) p1_round <= p1_round + 5'(UNROLL);
        end
    end
     
     
     
    localparam integer ROUNDS = UNROLL * PIPELINE;
    logic [1599:0] state_reg[0:PIPELINE-1];
    logic [PIPELINE-1:0] stage_valid;
    logic [4:0] stage_base[0:PIPELINE-1];
    logic [TAG_BITS-1:0] stage_tag[0:PIPELINE-1];
    logic sent;
    wire recycle = PIPELINE > 1 && stage_valid[PIPELINE-1] && stage_base[PIPELINE-1] + ROUNDS < 24;
    wire ready = !rst && !recycle;
    wire finished = PIPELINE > 1 && !rst && stage_valid[PIPELINE-1] && !recycle;
    wire normal_valid = hash_state == HASH_RUN && !sent;
    wire issue_valid = engine_mode ? batch_perm_valid : normal_valid;
    wire [1599:0] issue_state = engine_mode ? batch_perm_state : sponge_state;
    wire [TAG_BITS-1:0] issue_tag = engine_mode ? batch_perm_tag : '0;
    wire [1599:0] finished_state = state_reg[PIPELINE-1];
    wire [1599:0] stage_result[0:PIPELINE-1];
    for (genvar s = 0; s < PIPELINE; s = s + 1) begin : stages
        wire [1599:0] rounds[0:UNROLL];
        wire [4:0] start_round;
        wire [TAG_BITS-1:0] source_tag;
        wire source_valid;
        if (s == 0) begin : input_stage
            assign rounds[0] = PIPELINE == 1 ? sponge_state :
                recycle ? state_reg[PIPELINE-1] : issue_state;
            assign start_round = PIPELINE == 1 ? (engine_mode ? p1_round : round_index) :
                recycle ? stage_base[PIPELINE-1] + 5'(ROUNDS) : 5'd0;
            assign source_tag = recycle ? stage_tag[PIPELINE-1] : issue_tag;
            assign source_valid = PIPELINE > 1 && (recycle || issue_valid);
        end else begin : following_stage
            assign rounds[0] = state_reg[s-1];
            assign start_round = stage_base[s-1];
            assign source_tag = stage_tag[s-1];
            assign source_valid = stage_valid[s-1];
        end
        for (genvar r = 0; r < UNROLL; r = r + 1) begin : unrolled
             
            (* keep_hierarchy="yes" *) keccak round_logic(.state_in(rounds[r]),
                .round_index(start_round+5'(s*UNROLL+r)),.state_out(rounds[r+1]));
             
        end
        assign stage_result[s] = rounds[UNROLL];
        for (genvar w = 0; w < 25; w = w + 1) begin : words
            always_ff @(posedge clk)
                if (!rst) begin
                    if (PIPELINE == 1 && engine_mode) begin
                        if (batch_perm_valid && batch_perm_ready)
                            state_reg[s][64*w+:64] <= batch_perm_state[64*w+:64];
                        else if (p1_busy) state_reg[s][64*w+:64] <= rounds[UNROLL][64*w+:64];
                    end else if ((PIPELINE == 1 || (SHARED_STATE && s == PIPELINE - 1)) &&
                                 state_write_enable[w])
                        state_reg[s][64*w+:64] <= state_write_data[64*w+:64];
                    else if (source_valid) state_reg[s][64*w+:64] <= rounds[UNROLL][64*w+:64];
                end
        end
        always_ff @(posedge clk) begin
            if (rst) stage_valid[s] <= 0;
            else begin
                stage_valid[s] <= source_valid;
                if (source_valid) begin
                    stage_base[s] <= start_round;
                    stage_tag[s]  <= source_tag;
                end
            end
        end
    end
    assign batch_perm_ready = engine_mode && (PIPELINE == 1 ? (!p1_busy || p1_done) : ready);
    assign batch_perm_done = engine_mode && (PIPELINE == 1 ? p1_done : finished);
    assign batch_perm_digest = PIPELINE > 1 ? finished_state : stage_result[0];
    assign batch_perm_result_tag = PIPELINE > 1 ? stage_tag[PIPELINE-1] : '0;
    if (PIPELINE == 1 || SHARED_STATE) assign sponge_state = finished_state;
    assign advanced_state = PIPELINE == 1 ? stage_result[0] : finished_state;
    assign round_complete = PIPELINE == 1 ? round_index + UNROLL >= 24 : !engine_mode && finished;
    assign round_update   = hash_state == HASH_RUN && (PIPELINE == 1 || round_complete);
    always_ff @(posedge clk) begin
        if (rst) sent <= 0;
        else if (!engine_mode) begin
            if (normal_valid && ready) sent <= 1;
            if (finished) sent <= 0;
        end
    end
 
    always @(posedge clk)
        if (!rst && PIPELINE > 1 && SHARED_STATE && |state_write_enable)
            if (|(stage_valid & ~(finished ? PIPELINE'(1 << (PIPELINE - 1)) : {PIPELINE{1'b0}})))
                $fatal(1, "sponge write while pipeline occupied");

`line 555 "rtl/hash/recipe.sv" 0
    wire permutation_complete = !engine_mode && hash_state == HASH_RUN && round_complete;

`line 557 "rtl/hash/recipe.sv" 0
    assign hash_ready = hash_state == HASH_IDLE;
    assign block_ready = hash_state == HASH_WAIT_BLOCK;
    assign digest = sponge_state[DIGEST_BYTES*8-1:0];
    assign finish_valid = permutation_complete && running_last;

`line 562 "rtl/hash/recipe.sv" 0
 
    initial begin
        if (UNROLL < 1 || PIPELINE < 1 || PIPELINE > 24 || ROUNDS > 24 || (24 % ROUNDS) != 0)
            $error("recipe lane requires positive U/P and U*P dividing 24");
    end


`line 569 "rtl/hash/recipe.sv" 0
     
     
    wire take_stream = hash_state == HASH_WAIT_BLOCK && staged_valid;
    wire clear_stream = take_stream && first_block && append_index == 0;
     
     
    logic [127:0] previous_rate;
    always @* begin
        case (append_index)
            0: previous_rate = sponge_state[0+:128];
            1: previous_rate = sponge_state[128+:128];
            2: previous_rate = sponge_state[256+:128];
            3: previous_rate = sponge_state[384+:128];
            4: previous_rate = sponge_state[512+:128];
            5: previous_rate = sponge_state[640+:128];
            6: previous_rate = sponge_state[768+:128];
            7: previous_rate = sponge_state[896+:128];
            default: previous_rate = {64'd0, sponge_state[1024+:64]};
        endcase
    end
    wire [127:0] absorbed_block = staged_data ^ (previous_rate & {128{!clear_stream}});
    genvar word_index;
    generate
        for (word_index = 0; word_index < 25; word_index = word_index + 1) begin : state_words
            wire select_stream = word_index < 17 && take_stream && append_index == word_index / 2;
            wire [63:0] round_or_clear = (clear_stream || (SHARED_STATE && PIPELINE > 1)) ? 64'd0 :
                advanced_state[word_index*64+:64];
            wire [63:0]
                absorb_word = word_index % 2 == 0 ? absorbed_block[63:0] : absorbed_block[127:64];
            wire [63:0] next_word;
            assign next_word = select_stream ? absorb_word : round_or_clear;
            assign state_write_data[word_index*64+:64] = next_word;
             
             
            assign state_write_enable[word_index] = !rst && (
                (!(SHARED_STATE && PIPELINE > 1) && round_update) || select_stream || clear_stream);
            if (!SHARED_STATE && PIPELINE > 1) begin : private_state
                always_ff @(posedge clk)
                    if (state_write_enable[word_index])
                        sponge_state[word_index*64+:64] <= next_word;
            end
        end
    endgenerate

`line 613 "rtl/hash/recipe.sv" 0
    always_ff @(posedge clk) begin
        if (rst) begin
            hash_state   <= HASH_IDLE;
            first_block  <= 1;
            running_last <= 0;
            append_index <= 0;
            round_index  <= 0;
        end else
            case (hash_state)
                HASH_IDLE:
                if (state == START) begin
                    first_block  <= 1;
                    append_index <= 0;
                    hash_state   <= HASH_WAIT_BLOCK;
                end
                HASH_WAIT_BLOCK:
                if (staged_valid) begin
                    if (append_index == 8) begin
                        running_last <= staged_last;
                        append_index <= 0;
                        round_index  <= 0;
                        hash_state   <= HASH_RUN;
                    end else append_index <= append_index + 1'b1;
                end
                HASH_RUN:
                if (round_complete) begin
                    if (running_last) hash_state <= HASH_IDLE;
                    else begin
                        first_block <= 0;
                        hash_state  <= HASH_WAIT_BLOCK;
                    end
                end else if (PIPELINE == 1) round_index <= round_index + 5'(UNROLL);
                default: hash_state <= HASH_IDLE;
            endcase
    end

`line 649 "rtl/hash/recipe.sv" 0
    always_ff @(posedge clk) begin
        if (rst) begin
            staged_valid <= 0;
            staged_last <= 0;
            staged_data <= 0;
            position <= 0;
            list_cursor <= 0;
            list_remainder <= 0;
            bridge_response <= 0;
            state <= IDLE;
            error <= 0;
            rate_block <= 0;
            beat <= 0;
        end else begin
            if (STREAM_ENABLE && staged_valid && block_ready) staged_valid <= 0;
            case (state)
                IDLE:
                if (request_valid && request_ready) begin
                    staged_valid <= 0;
                    position <= 0;
                    list_cursor <= 0;
                    list_remainder <= 0;
                    error <= 0;
                    rate_block <= 0;
                    beat <= 0;
                    bridge_response <= scalar_fixed;
                    state <= scalar_fixed ? FIXED_WAIT : START;
                end
                FIXED_WAIT:
                if (engine_valid && response_ready) begin
                    bridge_response <= 0;
                    state <= IDLE;
                end
                START:
                if (hash_ready) begin
                    state <= STREAM;
                end
                STREAM:
                if (STREAM_ENABLE && stream_accept) begin
                    position <= position + 13'(stream_advance);
                    staged_data <= stream_data;
                    staged_valid <= 1;
                    staged_last <= stream_last;
                    if (beat == 8) staged_data[127:64] <= 0;
                    begin
                        if (position < prefix_bytes) begin
                            if (position + stream_advance >= prefix_bytes)
                                list_remainder <= position + stream_advance - prefix_bytes;
                        end else if (next_remainder >= stream_node_bytes) begin
                            list_remainder <= next_remainder - stream_node_bytes;
                            list_cursor <= list_cursor + 1'b1;
                        end else list_remainder <= next_remainder;
                    end
                    if (beat == 8) begin
                        beat <= 0;
                        if (stream_last) state <= WAIT_HASH;
                        else rate_block <= rate_block + 1'b1;
                    end else beat <= beat + 1'b1;
                end
                WAIT_HASH: if (completed) state <= RESPONSE;
                RESPONSE:
                if (response_ready) begin
                    bridge_response <= 0;
                    state <= IDLE;
                end
                default: state <= IDLE;
            endcase
        end
    end

`line 719 "rtl/hash/recipe.sv" 0
 
     
    always_ff @(posedge clk) begin : debug_statistics
        if (rst) begin
            hash_count <= 0;
            permutation_count <= 0;
        end else begin
            if (state == START && hash_ready) hash_count <= hash_count + 1'b1;
            if (state == STREAM && STREAM_ENABLE && stream_accept && beat == 8)
                permutation_count <= permutation_count + 1'b1;
        end
    end

`line 732 "rtl/hash/recipe.sv" 0
endmodule
`default_nettype wire

`line 735 "rtl/hash/recipe.sv" 2
`line 1 "rtl/memory/value.sv" 1
`timescale 1ns / 1ps
`default_nettype none
 
 
 
module value #(
    parameter integer WIDTH=256, DEPTH=136, ADDRESS_BITS=8
) (
    input wire clk,write_enable,
    input wire [ADDRESS_BITS-1:0] write_address,
    input wire [WIDTH-1:0] write_data,
    input wire [ADDRESS_BITS-1:0] read0,read1,
    output wire [WIDTH-1:0] value0,value1
);
 
    wire [WIDTH-1:0] bank_value[0:1];
    for (genvar bank = 0; bank < 2; bank = bank + 1) begin : banks
        wire we = write_enable && write_address[0] == bank;
        wire [ADDRESS_BITS-1:0] ra = read0[0] == bank ? read0 : read1;
        if (DEPTH == 136) begin : compact
            (* ram_style="distributed" *)logic [WIDTH-1:0] main[0:63];
            (* ram_style="distributed" *)logic [WIDTH-1:0] tail[ 0:3];
            always_ff @(posedge clk)
                if (we) begin
                    if (!write_address[7]) main[write_address[6:1]] <= write_data;
                    else if (write_address < 136) tail[write_address[2:1]] <= write_data;
                end
            assign bank_value[bank] = ra[7] ? tail[ra[2:1]] : main[ra[6:1]];
        end else begin : regular
            (* ram_style="distributed" *) logic [WIDTH-1:0] words[0:DEPTH/2-1];
            always_ff @(posedge clk) if (we) words[write_address[ADDRESS_BITS-1:1]] <= write_data;
            assign bank_value[bank] = words[ra[ADDRESS_BITS-1:1]];
        end
    end
    assign value0 = read0[0] ? bank_value[1] : bank_value[0];
    assign value1 = read0[0] ? bank_value[0] : bank_value[1];
endmodule
`default_nettype wire

`line 40 "rtl/memory/value.sv" 2
`line 1 "rtl/memory/signature.sv" 1
`timescale 1ns / 1ps
`default_nettype none

`line 4 "rtl/memory/signature.sv" 0
 
 
 
module signature (
    input wire clk,rst,finish,abort,
    input wire write_valid,input wire [255:0] write_data,input wire [5:0] write_bytes,
    input wire read_enable,input wire [10:0] read_address,
    output logic read_valid,output logic [255:0] read_data,
    output logic [5:0] node_bytes,output logic [5:0] read_bytes,
    output wire complete,output logic error,
    output logic [10:0] nodes,output logic [15:0] length
);
 
     
    (* ram_style = "block" *) logic [255:0] main_memory[0:1023];
    (* ram_style = "block" *) logic [255:0] middle_memory[0:511];
    (* ram_style = "distributed" *) logic [255:0] tail_memory[0:21];
    (* ram_style = "distributed" *) logic [5:0] byte_counts[0:1557];

`line 23 "rtl/memory/signature.sv" 0
    logic [255:0] main_data;
    logic [255:0] middle_data;
    logic [255:0] tail_data;
    logic [1:0] read_bank;

`line 28 "rtl/memory/signature.sv" 0
     
    wire size_ok = (write_bytes == 4 || write_bytes == 16 ||
                    write_bytes == 24 || write_bytes == 32) &&
                   (write_bytes == 4 || node_bytes == 0 || write_bytes == node_bytes);
    wire writing = write_valid && !rst && !finish && !abort && !error;
    wire reading = read_enable && complete && read_address < nodes;

`line 35 "rtl/memory/signature.sv" 0
    assign complete = finish && !rst && !abort && !error && nodes != 0;

`line 37 "rtl/memory/signature.sv" 0
     
    always_ff @(posedge clk) begin
        if (writing && nodes < 1558 && size_ok) begin
            byte_counts[nodes] <= write_bytes;
            if (!nodes[10]) begin
                main_memory[nodes[9:0]] <= write_data;
            end else if (!nodes[9]) begin
                middle_memory[nodes[8:0]] <= write_data;
            end else begin
                tail_memory[nodes[4:0]] <= write_data;
            end
        end

`line 50 "rtl/memory/signature.sv" 0
        if (reading) begin
            read_bytes <= byte_counts[read_address];
            if (!read_address[10]) begin
                main_data <= main_memory[read_address[9:0]];
                read_bank <= 0;
            end else if (!read_address[9]) begin
                middle_data <= middle_memory[read_address[8:0]];
                read_bank   <= 1;
            end else begin
                tail_data <= tail_memory[read_address[4:0]];
                read_bank <= 2;
            end
        end
    end

`line 65 "rtl/memory/signature.sv" 0
    always_comb begin
        case (read_bank)
            0: read_data = main_data;
            1: read_data = middle_data;
            default: read_data = tail_data;
        endcase
    end

`line 73 "rtl/memory/signature.sv" 0
    always_ff @(posedge clk) begin
        if (rst) begin
            nodes <= 0;
            length <= 0;
            node_bytes <= 0;
            error <= 0;
            read_valid <= 0;
        end else begin
            read_valid <= reading;
            if (abort) error <= 1;

`line 84 "rtl/memory/signature.sv" 0
            if (writing) begin
                if (nodes >= 1558 || !size_ok) begin
                    error <= 1;
                end else begin
                    nodes  <= nodes + 1'b1;
                    length <= length + {10'd0, write_bytes};
                    if (write_bytes != 4) node_bytes <= write_bytes;
                end
            end
        end
    end
endmodule

`line 97 "rtl/memory/signature.sv" 0
`default_nettype wire

`line 99 "rtl/memory/signature.sv" 2
`line 1 "rtl/executor/sequencer.sv" 1
`timescale 1ns / 1ps
`default_nettype none
 
 
module sequencer (
 input wire clk,rst,start,input wire [3:0] entry,output wire ready,output logic done,
 output wire [3:0] program_address,input wire [63:0] program_data,
 output wire [3:0] template_address,input wire [63:0] template_data,
 output wire command_valid,input wire command_ready,command_done,output wire [47:0] command
);
 
    typedef enum logic [2:0] {
        IDLE,
        FETCH,
        LOAD,
        ISSUE,
        WAIT_MACRO
    } state_t;
    state_t state;
    logic [3:0] pc;
    logic [63:0] token;
    logic [16:0] template_word;
    logic [10:0] coordinate, stride;
    logic [5:0] remaining;
    logic [1:0] sp;
    logic [3:0] loop_pc[0:1];
    logic [5:0] loop_remaining[0:1];
    logic [10:0] loop_bias[0:1], loop_delta[0:1];
    wire [1:0] kind = token[63:62];
    wire [5:0] back_count = {1'b0, token[61:57]} + 6'd1;
    assign program_address = pc;
    assign template_address = token[61:58];
    assign ready = state == IDLE;
    assign command_valid = state == ISSUE;
     
    assign command = {
        1'b0,
        template_word[2:0],
        3'd0,
        template_word[7:3],
        3'd0,
        template_word[12:8],
        template_word[15],
        template_word[16],
        template_word[14:13],
        coordinate,
        13'd0
    };
     
    integer i;
    always_ff @(posedge clk) begin
        if (rst) begin
            state <= IDLE;
            done <= 0;
            pc <= 0;
            token <= 0;
            template_word <= 0;
            coordinate <= 0;
            stride <= 0;
            remaining <= 0;
            sp <= 0;
            for (i = 0; i < 2; i = i + 1) begin
                loop_pc[i] <= 0;
                loop_remaining[i] <= 0;
                loop_bias[i] <= 0;
                loop_delta[i] <= 0;
            end
        end else begin
            done <= 0;
            case (state)
                IDLE:
                if (start) begin
                    pc <= entry;
                    sp <= 0;
                    loop_bias[0] <= 0;
                    loop_bias[1] <= 0;
                    state <= FETCH;
                end
                FETCH: begin
                    token <= program_data;
                    state <= LOAD;
                end
                LOAD: begin
                    if (kind == 3) begin
                        done  <= 1;
                        state <= IDLE;
                    end else if (kind == 2) begin
                        if (sp != 0 && loop_pc[sp-1] == pc) begin
                            if (loop_remaining[sp-1] > 1) begin
                                loop_remaining[sp-1] <= loop_remaining[sp-1] - 1'b1;
                                loop_bias[sp-1] <= loop_bias[sp-1] + loop_delta[sp-1];
                                pc <= pc - back_count;
                            end else begin
                                loop_bias[sp-1] <= 0;
                                sp <= sp - 1'b1;
                                pc <= pc + 1'b1;
                            end
                        end else begin
                            loop_pc[sp] <= pc;
                            loop_remaining[sp] <= token[56:51];
                            loop_bias[sp] <= token[50:40];
                            loop_delta[sp] <= token[50:40];
                            sp <= sp + 1'b1;
                            pc <= pc - back_count;
                        end
                        state <= FETCH;
                    end else begin
                        template_word <= template_data[16:0];
                        coordinate <= token[57:47] + loop_bias[0] + loop_bias[1];
                        stride <= token[40:30];
                        remaining <= token[46:41];
                        state <= ISSUE;
                    end
                end
                ISSUE:   if (command_ready) state <= WAIT_MACRO;
                WAIT_MACRO:
                if (command_done) begin
                    if (remaining != 0) begin
                        remaining <= remaining - 1'b1;
                        coordinate <= coordinate + stride;
                        state <= ISSUE;
                    end else begin
                        pc <= pc + 1'b1;
                        state <= FETCH;
                    end
                end
                default: state <= IDLE;
            endcase
        end
    end
endmodule
`default_nettype wire

`line 134 "rtl/executor/sequencer.sv" 2
`line 1 "rtl/executor/executor.sv" 1
`timescale 1ns / 1ps
`default_nettype none
 
 
module executor #(
    parameter integer UNROLL=2, PIPELINE=1
) (
 
    output logic [15:0] error_code,
    output wire [63:0] hash_count, permutation_count,
    output logic [63:0] cycles,

`line 13 "rtl/executor/executor.sv" 0
    input wire [63:0] image_header, profile_descriptor,
    output wire [3:0] program_address,
    output wire [3:0] template_address,
    input wire [63:0] program_data, template_data,
    input wire [3:0] job_entry,
    output wire [9:0] descriptor_addresses,
    input wire [127:0] descriptor_data,
    input wire clk, rst,
    input wire job_valid, output wire job_ready, input wire [1:0] job_operation,
    input wire [6:0] job_message_length,
    input wire [31:0] job_index, input wire [127:0] job_identifier,
    input wire [255:0] job_secret_seed, job_secret_prf, job_public_seed, job_randomizer, job_public_root,
    input wire message_valid, output wire message_ready,
    input wire [63:0] message_data,
    input wire verify_valid, output wire verify_ready,
    input wire [255:0] verify_data,
    output logic verify_pass,
    output wire out_valid, output wire [255:0] out_data,
    output wire [5:0] out_bytes,
    output wire busy, output logic done, error
);
 
    localparam integer N = 32, W = 256, V = 392, INDEX_BITS = 8, MAX_MESSAGE_BYTES = 87;
    localparam integer DIGEST_BYTES = 49;
     
     
    localparam integer FORS_DIGEST_BITS = 320;
    wire [4:0] config_code = profile_descriptor[4:0];
    wire decoded_stateful = config_code >= 5'h18 && config_code <= 5'h1d;
    wire decoded_xmss = decoded_stateful && config_code < 5'h1b;
    wire valid_profile=profile_descriptor[63:5]==0 && (decoded_stateful
        || config_code==0 || config_code==1 || config_code==2 || config_code==4 || config_code==5 || config_code==6);
    wire [4:0] decoded_height=(config_code==5'h18 || config_code==5'h1b) ? 5'd10
        : config_code==5'h19 ? 5'd16 : config_code==5'h1c ? 5'd15 : 5'd20;
    logic stateful, xmss, small_signature;
    logic [4:0] stateful_height;
    logic [1:0] profile_code;
    logic [5:0] node_bytes;
    wire [3:0] chain_max = 4'd15;
    wire [3:0] FORS_A=small_signature ? (profile_code==0 ? 4'd12 : 4'd14)
        : profile_code==0 ? 4'd6 : profile_code==1 ? 4'd8 : 4'd9;
    wire [3:0] HP=small_signature ? (profile_code[1] ? 4'd8 : 4'd9)
        : profile_code[1] ? 4'd4 : 4'd3;
    wire [7:0] LEN1 = {1'b0, node_bytes, 1'b0};
    wire [63:0] descriptors[0:7];
     
     
    assign descriptors[0] = descriptor_data[63:0];
    assign descriptors[1] = descriptor_data[127:64];
    assign descriptors[2] = 64'd0;
    assign descriptors[3] = descriptor_data[63:0];
    assign descriptors[4] = descriptor_data[63:0];
    assign descriptors[5] = descriptor_data[127:64];
    assign descriptors[6] = descriptor_data[63:0];
    assign descriptors[7] = descriptor_data[63:0];
    typedef enum logic [6:0] {
        IDLE, MESSAGE, LAUNCH, FETCH, LOAD_DESCRIPTOR, DECODE,
        TREE_INIT, CHAIN_SETUP, CHAIN_STORE,
        CHAIN_OUTPUT0=10,
        CHAIN_NEXT=14, REDUCE_SETUP, LEAF_SETUP,
        PUSH_NODE, PARENT_SETUP, PARENT_DONE, AUTH_OUTPUT, TREE_FINISH,
        HASH_ISSUE, HASH_WAIT, HASH_RESULT, ROUTE, TRANSFORM,
        EMIT, EMIT_NEXT, OUTPUT_CHUNK, DRAIN, FINISH, FAILED,
        VERIFY_INPUT, VERIFY_RANDOM, VERIFY_CHAIN_INPUT,
        VERIFY_CHAIN_RUN, VERIFY_CHAIN_ADVANCE,
         
        PIPE_ISSUE, PIPE_WAIT, PIPE_LOAD, PIPE_CAPTURE, PIPE_CAPTURE_NEXT, PIPE_ADVANCE,
        LT_SETUP, LT_STORE, LT_COPY, LT_NEXT, LT_FINISH, SF_REDUCED, SF_LEAF, SF_LEAF_DONE, SF_RANDOM,
        PIPE_VERIFY_INPUT, LT_PIPE_INIT,LT_PIPE_ISSUE,LT_PIPE_WAIT,LT_PIPE_ADVANCE,
        FORS_PICK,FORS_AUTH0,FORS_BEGIN,FORS_LEFT,FORS_RIGHT,FORS_ISSUE,FORS_WAIT,FORS_LEVEL,FORS_AUTH1,FORS_PUSH,
        FORS_LEAF_NEXT,FORS_ROOT_NEXT,PUSH_STACK
    } state_t;
    state_t state, hash_return, output_return;
    task automatic enter_state(input state_t next_state);
        begin
            state <= next_state;
        end
    endtask
     
     
     
     
    (* dont_touch="yes" *) logic abort_execution;
    wire execution_rst = rst || abort_execution;
    logic [1:0] operation;
    wire verifying = operation == 2;
    state_t verify_return;
     
    wire [255:0] secret_seed = job_secret_seed, secret_prf = job_secret_prf;
    wire [255:0] public_seed = job_public_seed, randomizer = job_randomizer;
    logic [MAX_MESSAGE_BYTES*8-1:0] message_buffer;
    logic [6:0] message_length, message_received;
    logic [W-1:0] value[0:3];
    logic [FORS_DIGEST_BITS-W-1:0] fors_digest_tail;
    logic [63:0] scalar_tree;
    logic [19:0] scalar_leaf;
    logic [11:0] checksum;
    logic [7:0] transform_index;
    logic [7:0] lt_count, lt_cursor;
    logic [3:0] lt_level;
    localparam integer FORS_BATCH = 4 * ((PIPELINE + 3) / 4);
    localparam integer FORS_SCRATCH = 112;
    logic fors_level, fors_roots_pending;
    logic [4:0] fors_total, fors_offset, fors_root_cursor;
    logic [20:0] fors_base;
    wire fors_target_group = target >= fors_base && target < fors_base + 21'(fors_total);
    wire fors_target_wave=fors_target_group && target>=fors_base+21'(fors_offset)
        && target<fors_base+21'(fors_offset)+21'(PIPELINE);
    wire [4:0] fors_outputs = fors_total >> (fors_level ? 2 : 1);
    wire sign_only = stateful && !verifying && standalone_chain && macro_flags[2];
    logic [4:0] layer;
    logic [5:0] group_index;
    logic [3:0] macro_op, macro_flags;
    logic [4:0] macro_desc, macro_route;
    logic [63:0] saved_descriptor, saved_chain_descriptor;
    wire [63:0] descriptor = saved_descriptor;
    wire [63:0] route_descriptor = descriptors[1];

`line 131 "rtl/executor/executor.sv" 0
    logic seq_start, seq_complete;
    wire seq_ready, seq_done, cmd_valid;
    wire [47:0] cmd;
     
    sequencer sequencer (
        .clk,.rst(execution_rst),.start(seq_start),.entry(job_entry),.ready(seq_ready),.done(seq_done),
        .program_address,.program_data,.template_address,.template_data,
        .command_valid(cmd_valid),.command_ready(state==FETCH),.command_done(seq_complete),.command(cmd)
    );
     

`line 142 "rtl/executor/executor.sv" 0
    logic [4:0] chain_id, parent_id;
    wire [63:0] chain_descriptor = saved_chain_descriptor;
    logic standalone_chain;
    logic [4:0] tree_height, node_level, auth_level;
    logic [1:0] indexing;
    logic [20:0] target, leaf_cursor, node_index;
    logic [INDEX_BITS-1:0] chain_cursor, endpoint_count;
    localparam integer PIPE_BATCH = PIPELINE;
    localparam integer TAG_BITS   = PIPELINE > 1 ? $clog2(PIPELINE) : 1;
    localparam integer COUNT_BITS = $clog2(PIPELINE + 1);
    logic pipe_cache_valid, pipe_batch_used;
    logic pipe_rolling;
    logic [PIPE_BATCH-1:0] pipe_active;
    logic [7:0] pipe_next_chain, pipe_completed;
    logic [7:0] pipe_chain_index[0:PIPE_BATCH-1];
    logic [TAG_BITS-1:0] roll_slot;
    wire [PIPE_BATCH-1:0] roll_free=~pipe_active | (pipe_valid ? (PIPE_BATCH'(1)<<pipe_tag) : '0);
    always_comb begin
        roll_slot = 0;
        for (integer j = PIPE_BATCH - 1; j >= 0; j--) if (roll_free[j]) roll_slot = TAG_BITS'(j);
    end
    wire  [  TAG_BITS-1:0] issue_slot = pipe_rolling ? roll_slot : pipe_issue_slot;
    logic [  TAG_BITS-1:0] pipe_issue_slot;
    logic [COUNT_BITS-1:0] pipe_pair;
    logic [PIPE_BATCH-1:0] pipe_done_mask, pipe_expected_mask;
    wire [255:0] pipe_read_result, pipe_read_capture;
    logic [7:0] pipe_seed_domain, pipe_step_domain;
     
     
    wire pipe_direct = indexing != 1 && (stateful ? (!verifying && !sign_only) : operation == 1);
    wire fors_pipe = state == FORS_LEFT || state == FORS_ISSUE || state == FORS_WAIT;
    wire fors_leaves = indexing == 1 && !verifying && (state == PIPE_ISSUE || state == PIPE_WAIT);
    wire lt_pipe = state == LT_PIPE_ISSUE || state == LT_PIPE_WAIT;
    wire pipe_mode=state==PIPE_ISSUE || state==PIPE_WAIT || state==PIPE_VERIFY_INPUT || lt_pipe || fors_pipe;
    wire pipe_ready, pipe_valid, pipe_selected;
    wire lt_batch_complete =
        ((pipe_done_mask | (pipe_valid ? (PIPE_BATCH'(1) << pipe_tag) : '0)) &
         pipe_expected_mask) == pipe_expected_mask;
    wire [TAG_BITS-1:0] pipe_tag;
 
    wire [63:0] pipe_hashes, pipe_permutations;

`line 184 "rtl/executor/executor.sv" 0
    wire  [255:0] selected_capture = pipe_batch_used ? pipe_read_capture : lane_capture;
    logic [255:0] node_value;
    localparam integer STACK_BASE = 68, AUTH_BASE = 88;

`line 188 "rtl/executor/executor.sv" 0
    logic [4:0] hash_recipe_id;
    assign descriptor_addresses = {
        state == CHAIN_SETUP ? chain_descriptor[48:44] : macro_route, hash_recipe_id[4:0]
    };
    always @* begin
        hash_recipe_id = macro_desc;
        case (state)
            TREE_INIT: hash_recipe_id = {1'b0, saved_descriptor[58:52]};
            EMIT: hash_recipe_id = emit_base + emit_cursor;
            CHAIN_SETUP: hash_recipe_id = chain_descriptor[59:52];
            VERIFY_CHAIN_RUN: hash_recipe_id = chain_descriptor[48:44];
            REDUCE_SETUP, LT_SETUP, LT_PIPE_INIT: hash_recipe_id = chain_descriptor[43:36];
            SF_LEAF: hash_recipe_id = chain_descriptor[35:28];
            PARENT_SETUP: hash_recipe_id = parent_id;
            default: begin
            end
        endcase
    end
    logic [63:0] task_recipe, task_step;
    logic task_chain;
    logic task_capture;
    logic [4:0] task_steps, task_capture_after;
    logic [19:0] task_leaf;
    logic [INDEX_BITS-1:0] task_a;
    logic [31:0] task_b;
     
     
     
    wire [255:0] parent_right = verifying && hash_return==PARENT_DONE && !node_index[0] ? emit_value : node_value;
     
     
     
    wire verify_step_needed = task_b[3:0] != chain_max;
    wire lane_ready, lane_valid, lane_error;
    wire [V-1:0] lane_value;
    wire [255:0] lane_capture;
    wire [INDEX_BITS-1:0] lane_list0, lane_list1, lane_list_next;
 
    wire [63:0] lane_hashes, lane_permutations;
    logic [63:0] hash_base, permutation_base;


`line 230 "rtl/executor/executor.sv" 0
    logic [V-1:0] result;
     
     
    localparam logic [1:0] ROUTE_HASH = 0, ROUTE_NODE = 1, ROUTE_SAVED = 2, ROUTE_EMIT = 3;
    logic [1:0] route_source;
    wire [V-1:0] route_value = route_source==ROUTE_HASH ? result
        : {{(V-W){1'b0}}, (route_source==ROUTE_NODE ? node_value
                        : route_source==ROUTE_SAVED ? value[3] : emit_value)};
     
 
    wire [63:0] total_hashes = lane_hashes + pipe_hashes;
    wire [63:0] total_permutations = lane_permutations + pipe_permutations;
    assign hash_count = total_hashes - hash_base;
    assign permutation_count = total_permutations - permutation_base;


`line 246 "rtl/executor/executor.sv" 0
    logic endpoint_write;
    logic [INDEX_BITS-1:0] endpoint_address;
    wire [INDEX_BITS-1:0] endpoint_read0, endpoint_read1;
    logic [255:0] endpoint_data;
    wire [255:0] endpoint_value0, endpoint_value1;
     
     
    wire root_write = state == ROUTE && macro_route != 0 && route_descriptor[53];
     
    (* keep_hierarchy="yes" *) value #(.WIDTH(W),.DEPTH(136),.ADDRESS_BITS(INDEX_BITS)) endpoints (
        .clk,.write_enable(endpoint_write),.write_address(endpoint_address),.write_data(endpoint_data),
        .read0(endpoint_read0),.read1(endpoint_read1),.value0(endpoint_value0),.value1(endpoint_value1)
    );
     
    wire [INDEX_BITS-1:0] batch_chain_index=pipe_rolling ? pipe_next_chain : chain_cursor+INDEX_BITS'(pipe_issue_slot);
    wire [20:0] batch_leaf_index=leaf_cursor+21'(fors_leaves ? fors_offset : 0)+21'(pipe_issue_slot);
    assign pipe_selected=(state==PIPE_ISSUE || state==LT_PIPE_ISSUE || state==FORS_ISSUE || (state==PIPE_VERIFY_INPUT && verify_valid))
        && (fors_pipe || (pipe_rolling ? (pipe_next_chain<endpoint_count && |roll_free) : pipe_expected_mask[pipe_issue_slot]));
     
    recipe #(.N(N),.DIGEST_BYTES(DIGEST_BYTES),.INDEX_BITS(INDEX_BITS),.UNROLL(UNROLL),.PIPELINE(PIPELINE),.MAX_MESSAGE_BYTES(MAX_MESSAGE_BYTES),
        .SHARED_STATE(1'b1),.RECIPE_MASK(16'hfffe)) lane (
 
        .hash_count(lane_hashes),
        .permutation_count(lane_permutations),
        .batch_hashes(pipe_hashes),.batch_permutations(pipe_permutations),

`line 272 "rtl/executor/executor.sv" 0
        .clk,.rst(execution_rst),.node_bytes,
        .batch_mode(pipe_mode),.batch_request_valid(pipe_selected),.batch_request_ready(pipe_ready),
        .batch_request_tag(issue_slot),
        .batch_steps(lt_pipe || fors_pipe ? 5'd0 : stateful && verifying ? {1'b0,chain_max}-digit(batch_chain_index)
        : (sign_only || (macro_flags[3] && leaf_cursor==target)) ? digit(batch_chain_index) : chain_descriptor[19:15]),
        .batch_family(stateful ? (xmss ? 2'd1 : 2'd2) : 2'd0),
        .batch_no_seed(lt_pipe || fors_pipe || (stateful && verifying)),.batch_start(stateful && verifying ? 4'(digit(batch_chain_index)) : 4'd0),
        .batch_initial_value(fors_pipe || lt_pipe ? endpoint_value0 : verify_data),
        .batch_fixed_shape(fors_pipe ? 4'd2 : lt_pipe ? 4'd8 : 4'd0),.batch_pair(lt_pipe || fors_pipe),.batch_right(endpoint_value1),
        .batch_capture_after(indexing==1 ? 5'd0 : digit(batch_chain_index)),
        .batch_capture_enable(!fors_pipe && !lt_pipe && !verifying && macro_flags[0] && (indexing==1 ? batch_leaf_index==target : leaf_cursor==target)),
        .batch_leaf(lt_pipe ? leaf_cursor[19:0] : indexing==1 ? scalar_leaf : leaf_cursor[19:0]),
        .batch_a(fors_pipe ? (fors_level ? 8'd2 : 8'd1) : lt_pipe ? {4'd0,lt_level} : indexing==1 ? 8'd0 : batch_chain_index),
        .batch_b(fors_pipe ? ((32'(group_index)<<FORS_A)>>(fors_level ? 2 : 1))+(32'(fors_base)>>(fors_level ? 2 : 1))+32'(fors_offset)+32'(pipe_issue_slot) : lt_pipe ? 32'(lt_cursor>>1)+32'(pipe_issue_slot) : indexing==1 ? (32'(group_index)<<FORS_A)+32'(batch_leaf_index) : 32'd0),
        .batch_seed_domain(pipe_seed_domain),.batch_step_domain(pipe_step_domain),
        .batch_response_valid(pipe_valid),.batch_response_ready(pipe_mode && state!=LT_PIPE_ISSUE && (!fors_pipe || state==FORS_WAIT)),.batch_response_tag(pipe_tag),
        .batch_response_digest(),.batch_response_capture(),
         
         
         
        .batch_read_tag(state==FORS_PICK ? TAG_BITS'(target-fors_base-21'(fors_offset)) : (lt_pipe || fors_pipe || fors_leaves || pipe_direct) && pipe_mode ? pipe_tag : TAG_BITS'(pipe_pair)),
        .batch_read_digest(pipe_read_result),.batch_read_capture(pipe_read_capture),
        .request_valid(state==HASH_ISSUE),
        .request_ready(lane_ready), .request_recipe(task_recipe), .request_step_recipe(task_step),
        .request_chain(task_chain), .request_steps(task_steps),
        .request_capture_after(task_capture_after),
        .request_capture(task_capture),
        .secret_seed,.secret_prf,.public_seed,.root(value[3][W-1:0]),
        .randomizer((task_recipe[59:56]==4 || task_recipe[59:56]==6 || (verifying && stateful)) ? value[0][W-1:0] : randomizer),
        .identifier(job_identifier),.message_buffer,.message_length,
        .request_layer(layer),.request_tree(scalar_tree),.request_leaf(task_leaf),
        .request_a(task_a),.request_b(task_b),.request_left(result[W-1:0]),.request_right(parent_right),
        .list_index0(lane_list0),.list_index1(lane_list1),.list_next_index0(lane_list_next),
        .list_data0(endpoint_value0),
        .list_data1(endpoint_value1),
        .response_valid(lane_valid),.response_ready(state==HASH_WAIT),
        .response_value(lane_value),.response_capture(lane_capture),.error(lane_error)
    );
     
 
    initial
        if(UNROLL<1 || PIPELINE<1 || PIPELINE>24 ||
        UNROLL*PIPELINE>24 || 24%(UNROLL*PIPELINE)!=0)
            $fatal(1, "Unsupported P/U configuration");



`line 319 "rtl/executor/executor.sv" 0
     
    logic [255:0] emit_value;
    logic [  5:0] emit_length;
    logic [  7:0] emit_base;
    logic [3:0] emit_count, emit_cursor;
    wire [63:0] emit_descriptor = descriptors[3];
     
     
    assign out_valid = state == OUTPUT_CHUNK;
    assign out_data = emit_value;
    assign out_bytes = emit_length;
    assign job_ready = state == IDLE;
    assign message_ready = state == MESSAGE;
    assign verify_ready=verifying && (state==VERIFY_INPUT || (state==PIPE_VERIFY_INPUT && pipe_ready));
    assign busy = state != IDLE;

`line 335 "rtl/executor/executor.sv" 0
    function automatic [31:0] be32(input [31:0] x);
        be32 = {x[7:0], x[15:8], x[23:16], x[31:24]};
    endfunction
    function automatic [4:0] digit(input [7:0] index);
        reg [7:0] checksum_index;
        begin
            checksum_index = index - LEN1;
            digit = 0;
            if (index < LEN1) begin
                digit = {1'b0, value[2][{(index[5:0]^6'd1), 2'b0}+:4]};
            end else begin
                case (checksum_index)
                    0: digit = {1'b0, checksum[11:8]};
                    1: digit = {1'b0, checksum[7:4]};
                    2: digit = {1'b0, checksum[3:0]};
                    default: digit = 0;
                endcase
            end
        end
    endfunction
    wire [FORS_DIGEST_BITS-1:0] fors_digest = {fors_digest_tail, value[1]};
    wire [FORS_DIGEST_BITS-1:0] fors_bitstream;
    genvar fb;
    generate
        for (fb = 0; fb < FORS_DIGEST_BITS; fb = fb + 1) begin : fors_bit_order
            assign fors_bitstream[fb] = fors_digest[(fb/8)*8+7-(fb%8)];
        end
    endgenerate
    function automatic [13:0] fors_target(input [5:0] group_number);
        reg [ 9:0] offset;
        reg [13:0] segment;
        begin
            case (FORS_A)
                6: offset = ({group_number, 2'b0} + {group_number, 1'b0});
                8: offset = {group_number, 3'b0};
                9: offset = ({group_number, 3'b0} + group_number);
                12: offset = ({group_number, 3'b0} + {group_number, 2'b0});
                default: offset = ({group_number, 4'b0} - {group_number, 1'b0});
            endcase
            segment = fors_bitstream >> offset;
             
            case (FORS_A)
                6: fors_target = {8'd0,segment[0],segment[1],segment[2],segment[3],segment[4],segment[5]};
                8: fors_target = {6'd0,segment[0],segment[1],segment[2],segment[3],segment[4],segment[5],segment[6],segment[7]};
                9: fors_target = {5'd0,segment[0],segment[1],segment[2],segment[3],segment[4],segment[5],segment[6],segment[7],segment[8]};
                12: fors_target = {2'd0,segment[0],segment[1],segment[2],segment[3],segment[4],segment[5],segment[6],segment[7],segment[8],segment[9],segment[10],segment[11]};
                default: fors_target = {segment[0],segment[1],segment[2],segment[3],segment[4],segment[5],segment[6],segment[7],segment[8],segment[9],segment[10],segment[11],segment[12],segment[13]};
            endcase
             
        end
    endfunction
    function automatic [63:0] parsed_tree(input [V-1:0] digest);
        reg [63:0] bytes;
        integer j;
        begin
            if (small_signature) begin
                case (node_bytes)
                    16: bytes = {digest[168+:56], 8'd0};
                    24: bytes = {digest[240+:56], 8'd0};
                    default: bytes = {digest[312+:56], 8'd0};
                endcase
            end else
                case (node_bytes)
                    16: bytes = digest[200+:64];
                    24: bytes = digest[264+:64];
                    default: bytes = digest[320+:64];
                endcase
            for (j = 0; j < 8; j = j + 1) parsed_tree[(7-j)*8+:8] = bytes[j*8+:8];
            if (small_signature && node_bytes != 32) parsed_tree[63:54] = 0;
            else if (!small_signature && node_bytes != 32) parsed_tree[63] = 0;
        end
    endfunction
    function automatic [9:0] parsed_leaf(input [V-1:0] digest);
        begin
            if (small_signature) begin
                case (node_bytes)
                    16: parsed_leaf = {1'b0, digest[224], digest[232+:8]};
                    24: parsed_leaf = {1'b0, digest[296], digest[304+:8]};
                    default: parsed_leaf = {2'b0, digest[368+:8]};
                endcase
            end else
                parsed_leaf=node_bytes==16 ? {7'b0,digest[264 +:3]}
                : node_bytes==24 ? {7'b0,digest[328 +:3]} : {6'b0,digest[384 +:4]};
        end
    endfunction
    task automatic fail;
        begin
            error <= 1;
            abort_execution <= 1;
            enter_state(FAILED);
        end
    endtask
    task automatic complete_macro;
        begin
            seq_complete <= 1;
            enter_state(FETCH);
        end
    endtask
    task automatic route_result(input [1:0] source);
        begin
            route_source <= source;
            enter_state(ROUTE);
        end
    endtask
    task automatic start_output(input [255:0] v, input [5:0] length, input state_t ret);
        begin
            emit_value <= v;
            emit_length <= length;
            output_return <= ret;
            enter_state(OUTPUT_CHUNK);
        end
    endtask
     
     
    task automatic advance_direct_batch;
        begin
            if (chain_cursor + PIPELINE < endpoint_count) begin
                chain_cursor <= chain_cursor + PIPELINE;
                pipe_pair <= 0;
                pipe_issue_slot <= 0;
                pipe_done_mask <= 0;
                for (integer q = 0; q < PIPE_BATCH; q = q + 1)
                pipe_expected_mask[q] <= 32'(chain_cursor) + PIPELINE + q < endpoint_count;
                enter_state(PIPE_ISSUE);
            end else begin
                chain_cursor <= endpoint_count - 1'b1;
                enter_state(CHAIN_NEXT);
            end
        end
    endtask
    task automatic start_hash(input [63:0] selected_recipe, input state_t ret);
        begin
            task_recipe <= selected_recipe;
            hash_return <= ret;
            enter_state(HASH_ISSUE);
        end
    endtask
    task automatic read_verify_node(input state_t ret);
        begin
            verify_return <= ret;
            enter_state(VERIFY_INPUT);
        end
    endtask

`line 479 "rtl/executor/executor.sv" 0
    always_comb begin
        endpoint_write = 0;
        endpoint_address = chain_cursor;
        endpoint_data = result[W-1:0];
        if (auth_write) begin
            endpoint_write = 1;
            endpoint_address = INDEX_BITS'(AUTH_BASE) + INDEX_BITS'(auth_write_level);
            endpoint_data = auth_write_data;
        end else if (stack_write) begin
            endpoint_write = 1;
            endpoint_address = INDEX_BITS'(STACK_BASE) + INDEX_BITS'(node_level);
            endpoint_data = node_value;
        end else if (fors_leaves || fors_pipe) begin
            endpoint_write = pipe_valid && (fors_leaves || state == FORS_WAIT);
            endpoint_address=INDEX_BITS'(FORS_SCRATCH)+INDEX_BITS'(fors_offset)+INDEX_BITS'(pipe_tag);
            endpoint_data = pipe_read_result;
        end else if (lt_pipe) begin
            endpoint_write = pipe_valid && state == LT_PIPE_WAIT;
            endpoint_address = (lt_cursor >> 1) + INDEX_BITS'(pipe_tag);
            endpoint_data = pipe_read_result;
        end else if (pipe_direct && pipe_mode) begin
            endpoint_write = pipe_valid;
            endpoint_address=pipe_rolling ? pipe_chain_index[pipe_tag] : chain_cursor+INDEX_BITS'(pipe_tag);
            endpoint_data = pipe_read_result;
        end else if (state == CHAIN_STORE && indexing != 1) begin
            endpoint_write = 1;
        end else if (state == LT_STORE || state == LT_COPY) begin
            endpoint_write = 1;
            endpoint_address = lt_cursor >> 1;
            endpoint_data = state == LT_COPY ? endpoint_value0 : result[W-1:0];
        end else if (root_write) begin
            endpoint_write = 1;
            endpoint_address = INDEX_BITS'(group_index);
            endpoint_data = route_value[W-1:0];
        end
    end

`line 516 "rtl/executor/executor.sv" 0
    generate
        begin : read_addresses
            logic [INDEX_BITS-1:0] address;
            always_ff @(posedge clk) begin
                if (rst) address <= 0;
                else if (state == REDUCE_SETUP || state == TREE_INIT) address <= 0;
                else if (state == PUSH_NODE)
                    address<=node_level==tree_height ? INDEX_BITS'(AUTH_BASE) : INDEX_BITS'(STACK_BASE)+INDEX_BITS'(node_level);
                else if (state == AUTH_OUTPUT)
                    address <= INDEX_BITS'(AUTH_BASE) + INDEX_BITS'(auth_level) + 1'b1;
                else if (state == HASH_ISSUE || state == HASH_WAIT) address <= lane_list_next;
                else if (state == LT_PIPE_INIT) address <= {lt_cursor[INDEX_BITS-1:1], 1'b0};
                else if (state == LT_PIPE_ISSUE && pipe_ready)
                    address <= lt_cursor + ((INDEX_BITS'(pipe_issue_slot) + 1'b1) << 1);
                else if (state == LT_PIPE_WAIT && lt_batch_complete) begin
                    if (lt_cursor + 2 * PIPELINE < lt_count) address <= lt_cursor + 2 * PIPELINE;
                    else if (lt_count[0]) address <= lt_count - 1'b1;
                    else address <= 0;
                end else if (state == LT_NEXT) address <= 0;
                else if (state == FORS_LEAF_NEXT)
                    address<=fors_target_group ? INDEX_BITS'(FORS_SCRATCH)+INDEX_BITS'((target-fors_base)^21'd1) : INDEX_BITS'(FORS_SCRATCH);
                else if(state==FORS_AUTH0 || state==FORS_BEGIN || state==FORS_AUTH1 || state==FORS_LEVEL)
                    address <= INDEX_BITS'(FORS_SCRATCH);
                else if (state == FORS_ISSUE && pipe_ready)
                    address<=pipe_issue_slot+1>=PIPELINE || (pipe_expected_mask>>(pipe_issue_slot+1))==0 ? INDEX_BITS'(FORS_SCRATCH) : INDEX_BITS'(FORS_SCRATCH)+((INDEX_BITS'(fors_offset)+INDEX_BITS'(pipe_issue_slot)+1'b1)<<1);
                else if (state == FORS_WAIT) begin
                    if (fors_offset + PIPELINE < fors_outputs)
                        address<=INDEX_BITS'(FORS_SCRATCH)+((INDEX_BITS'(fors_offset)+INDEX_BITS'(PIPELINE))<<1);
                    else if (fors_level) address <= INDEX_BITS'(FORS_SCRATCH);
                    else
                        address<=fors_target_group ? INDEX_BITS'(FORS_SCRATCH)+INDEX_BITS'(((target-fors_base)>>1)^21'd1) : INDEX_BITS'(FORS_SCRATCH);
                end else if (state == FORS_ROOT_NEXT)
                    address <= INDEX_BITS'(FORS_SCRATCH) + INDEX_BITS'(fors_root_cursor) + 1'b1;
            end
            assign endpoint_read0 = address;
            assign endpoint_read1 = address == 135 ? 8'd134 : address + 1'b1;
        end
    endgenerate

`line 555 "rtl/executor/executor.sv" 0
     
     
    wire auth_write=!verifying && macro_flags[1] && ((state==PUSH_NODE && node_level<tree_height && node_index==((target>>node_level)^1))
        || state==FORS_AUTH0 || state==FORS_AUTH1);
    wire [4:0] auth_write_level=state==FORS_AUTH0 ? 5'd0 : state==FORS_AUTH1 ? 5'd1 : node_level;
    wire [255:0] auth_write_data=state==FORS_AUTH0 || state==FORS_AUTH1 ? endpoint_value0 : node_value;
    wire stack_write=(state==PUSH_NODE || state==PUSH_STACK) && node_level<tree_height && !node_index[0] && !verifying;
 
    always @(posedge clk)
        if (!execution_rst) begin
            if (endpoint_write && endpoint_address >= 136)
                $fatal(1, "workspace write out of range");
            if (endpoint_read0 >= 136 || endpoint_read1 >= 136)
                $fatal(1, "workspace read out of range");
            if ((lt_pipe && state == LT_PIPE_ISSUE) || (fors_pipe && state != FORS_WAIT))
                if (endpoint_write) $fatal(1, "reduction write before batch inputs accepted");
        end


`line 574 "rtl/executor/executor.sv" 0
    reg [255:0] emit_source;
    always_comb begin
        case (emit_descriptor[59:56])
            0: emit_source = secret_seed;
            1: emit_source = secret_prf;
            2: emit_source = public_seed;
            3: emit_source = value[3][W-1:0];
            4: emit_source = xmss ? value[0] : randomizer;
            5: emit_source = {128'd0, job_identifier};
            6: emit_source = {224'd0, be32(job_index)};
            7: emit_source = be32(emit_descriptor[31:0]);
            default: emit_source = 0;
        endcase
    end

`line 589 "rtl/executor/executor.sv" 0
 
     
     
    logic [15:0] diagnostic_reason;
    always_comb begin : debug_failure_reason
        diagnostic_reason = 0;
         
        case (state)
            IDLE:
            if (job_valid) begin
                if (!valid_profile) diagnostic_reason = 16'h3009;
                else if (decoded_stateful && job_index >= (32'd1 << decoded_height))
                    diagnostic_reason = 16'h3008;
            end
            DECODE: if (macro_op < 1 || macro_op > 5) diagnostic_reason = 16'h3006;
            CHAIN_SETUP:
            if(endpoint_count==0 || endpoint_count>67 ||
                (!standalone_chain && (tree_height>20 || (indexing==1 && tree_height<2))))
                diagnostic_reason = 16'h300a;
            HASH_WAIT: if (lane_valid && lane_error) diagnostic_reason = 16'h3007;
            TRANSFORM: if (descriptor[59:56] != 1 && descriptor[59:56] != 2) diagnostic_reason = 16'h3006;
            12,16,24,6,8,9,AUTH_OUTPUT,CHAIN_NEXT,CHAIN_OUTPUT0,CHAIN_STORE,
            DRAIN,EMIT,EMIT_NEXT,FAILED,FETCH,FINISH,
            FORS_AUTH0,FORS_AUTH1,FORS_BEGIN,FORS_ISSUE,FORS_LEAF_NEXT,FORS_LEFT,FORS_LEVEL,FORS_PICK,FORS_PUSH,FORS_ROOT_NEXT,FORS_WAIT,
            HASH_ISSUE,HASH_RESULT,LAUNCH,LEAF_SETUP,LOAD_DESCRIPTOR,
            LT_COPY,LT_FINISH,LT_NEXT,LT_PIPE_ADVANCE,LT_PIPE_INIT,LT_PIPE_ISSUE,LT_PIPE_WAIT,LT_SETUP,LT_STORE,
            MESSAGE,OUTPUT_CHUNK,PARENT_DONE,PARENT_SETUP,
            PIPE_ISSUE,PIPE_LOAD,PIPE_VERIFY_INPUT,PIPE_WAIT,PUSH_NODE,PUSH_STACK,REDUCE_SETUP,
            ROUTE,SF_LEAF,SF_LEAF_DONE,SF_RANDOM,SF_REDUCED,TREE_FINISH,TREE_INIT,
            VERIFY_CHAIN_ADVANCE,VERIFY_CHAIN_INPUT,VERIFY_CHAIN_RUN,VERIFY_INPUT,VERIFY_RANDOM: diagnostic_reason = 0;
            default: diagnostic_reason = 16'h3006;
        endcase
         
    end
    always_ff @(posedge clk) begin : debug_statistics
        if (rst) begin
            cycles <= 0;
            hash_base <= 0;
            permutation_base <= 0;
            error_code <= 0;
        end else begin
            if (state == IDLE && job_valid) begin
                cycles <= 0;
                hash_base <= total_hashes;
                permutation_base <= total_permutations;
                error_code <= 0;
            end else if (state != IDLE && state != FAILED) cycles <= cycles + 1'b1;
            if (diagnostic_reason != 0) error_code <= diagnostic_reason;
        end
    end


`line 641 "rtl/executor/executor.sv" 0
    always_ff @(posedge clk) begin
        if (rst) begin
            enter_state(IDLE);
            done <= 0;
            error <= 0;

`line 647 "rtl/executor/executor.sv" 0
            abort_execution <= 0;
            seq_start <= 0;
            seq_complete <= 0;
            stateful <= 0;
            xmss <= 0;
            small_signature <= 0;
            stateful_height <= 10;
            profile_code <= 0;
            node_bytes <= 16;
            operation <= 0;
            scalar_tree <= 0;
            scalar_leaf <= 0;
            verify_pass <= 0;
            verify_return <= IDLE;
            macro_op <= 0;
            macro_desc <= 0;
            macro_route <= 0;
            macro_flags <= 0;
            task_chain <= 0;
            task_capture <= 0;

`line 668 "rtl/executor/executor.sv" 0
            layer <= 0;
            task_recipe <= 0;
            task_step <= 0;
            message_received <= 0;
            lt_count <= 0;
            lt_cursor <= 0;
            lt_level <= 0;
            fors_total <= 0;
            fors_offset <= 0;
            fors_root_cursor <= 0;
            fors_level <= 0;
            fors_roots_pending <= 0;
            fors_base <= 0;
            pipe_cache_valid <= 0;
            pipe_batch_used <= 0;
            pipe_pair <= 0;
            pipe_issue_slot <= 0;
            pipe_rolling <= 0;
            pipe_active <= 0;
            pipe_next_chain <= 0;
            pipe_completed <= 0;
            pipe_done_mask <= 0;
            pipe_expected_mask <= 0;

`line 692 "rtl/executor/executor.sv" 0
            task_steps <= 0;
            task_capture_after <= 0;
            task_leaf <= 0;
            task_a <= 0;
            task_b <= 0;
        end else begin
            done <= 0;
            seq_start <= 0;
            seq_complete <= 0;
            abort_execution <= 0;

`line 703 "rtl/executor/executor.sv" 0
            if (pipe_rolling && pipe_mode) begin
                if (pipe_valid) begin
                    pipe_active[pipe_tag] <= 0;
                    pipe_completed <= pipe_completed + 1'b1;
                end
                if (pipe_selected && pipe_ready) begin
                    pipe_active[issue_slot] <= 1;
                    pipe_chain_index[issue_slot] <= pipe_next_chain;
                    pipe_next_chain <= pipe_next_chain + 1'b1;
                end
            end
            if (pipe_mode) begin
                if(pipe_valid && state!=LT_PIPE_ISSUE && (!fors_pipe || state==FORS_WAIT))begin
                    pipe_done_mask[pipe_tag] <= 1;
                    if(!lt_pipe && pipe_direct && (pipe_rolling ? pipe_chain_index[pipe_tag]==0 : chain_cursor==0 && pipe_tag==0) && standalone_chain)
                        node_value <= pipe_read_result;
                end
            end
            case (state)
                IDLE:
                if (job_valid) begin
                    error <= 0;
                    operation <= job_operation;
                    stateful <= decoded_stateful;
                    xmss <= decoded_xmss;
                    stateful_height <= decoded_height;
                    small_signature <= !decoded_stateful && config_code[2];
                    profile_code <= config_code[1:0];
                    node_bytes<=decoded_stateful ? 6'd32 : config_code[1:0]==0 ? 6'd16 : config_code[1:0]==1 ? 6'd24 : 6'd32;
                    verify_pass <= 0;
                    message_length <= job_message_length;
                    message_received <= 0;
                    scalar_tree <= 0;
                    scalar_leaf <= decoded_stateful ? job_index[19:0] : 0;
                    layer <= 0;
                    group_index <= 0;

`line 740 "rtl/executor/executor.sv" 0
                    value[3] <= job_public_root;
                    if (!valid_profile) fail();
                    else if (decoded_stateful && job_index >= (32'd1 << decoded_height)) fail();
                    else if (job_operation) begin
                        enter_state(MESSAGE);
                    end else begin
                        enter_state(LAUNCH);
                    end
                end
                MESSAGE:
                if (message_valid) begin
                     
                     
                    message_buffer[{message_received[6:3], 6'b0}+:64] <= message_data;
                    message_received <= message_received + 7'd8;
                    if (message_received + 7'd8 >= message_length) enter_state(LAUNCH);
                end
                LAUNCH:
                if (seq_ready) begin
                    seq_start <= 1;
                    enter_state(FETCH);
                end
                FETCH: begin
                    if (seq_done) begin
                        if (verifying) begin
                            verify_pass <= value[2][127:0]==job_public_root[127:0]
                                    && (node_bytes==16 || value[2][191:128]==job_public_root[191:128])
                                    && (node_bytes!=32 || value[2][255:192]==job_public_root[255:192]);
                            enter_state(DRAIN);
                        end else enter_state(DRAIN);
                    end else if (cmd_valid) begin
                        macro_op <= cmd[47:44];
                        macro_desc <= cmd[43:36];
                        macro_route <= cmd[35:28];
                        macro_flags <= cmd[27:24];
                        layer <= cmd[23:19];
                        group_index <= cmd[18:13];
                        task_chain <= 0;
                        task_capture <= 0;
                        pipe_cache_valid <= 0;
                        pipe_batch_used <= 0;
                        task_steps <= 0;
                        enter_state(LOAD_DESCRIPTOR);
                    end
                end
                LOAD_DESCRIPTOR: begin
                    saved_descriptor <= descriptors[0];
                    enter_state(DECODE);
                end
                DECODE: begin
                    case (macro_op)
                        1: begin
                            task_leaf <= scalar_leaf;
                            task_a <= 0;
                            task_b <= 0;
                             
                             
                            if(verifying && stateful && (saved_descriptor[59:56]==5 || saved_descriptor[59:56]==11))
                                read_verify_node(SF_RANDOM);
                            else if (verifying && saved_descriptor[59:56] == 3)
                                read_verify_node(VERIFY_RANDOM);
                            else start_hash(saved_descriptor, HASH_RESULT);
                        end
                        2: begin
                            chain_id <= macro_desc;
                            standalone_chain <= 1;
                            indexing <= 0;
                            leaf_cursor <= stateful ? job_index[19:0] : 0;
                            target <= stateful ? job_index[19:0] : 0;
                            chain_cursor <= 0;
                            endpoint_count <= descriptor[27:20];
                            saved_chain_descriptor <= descriptor;
                            enter_state(CHAIN_SETUP);
                        end
                        3: enter_state(TREE_INIT);
                        4: begin
                            checksum <= 0;
                            transform_index <= 0;
                            enter_state(TRANSFORM);
                        end
                        5:
                        if (verifying && stateful) complete_macro();
                        else begin
                            emit_base   <= descriptor[59:52];
                            emit_count  <= descriptor[51:48];
                            emit_cursor <= 0;
                            enter_state(EMIT);
                        end
                        default: fail();
                    endcase
                end
                TREE_INIT: begin
                    fors_roots_pending <= 0;
                    pipe_cache_valid <= 0;
                    pipe_batch_used <= 0;
                    saved_chain_descriptor <= descriptors[6];

`line 837 "rtl/executor/executor.sv" 0
                    chain_id <= descriptor[59:52];
                    parent_id <= descriptor[51:44];
                    tree_height <= {descriptor[39], descriptor[43:40]};
                    indexing <= descriptor[33:32];
                    standalone_chain <= 0;
                    target<=stateful ? {1'b0,job_index[19:0]} : descriptor[37:36]==1 ? fors_target(
                        group_index
                    ) : scalar_leaf;
                    leaf_cursor <= verifying ? scalar_leaf : 0;
                    chain_cursor <= 0;
                    node_level <= 0;
                    auth_level <= 0;
                    endpoint_count <= descriptors[6][27:20];
                    if (stateful && verifying) begin
                        node_value <= value[2];
                        node_index <= job_index[19:0];
                        enter_state(PUSH_NODE);
                    end else enter_state(CHAIN_SETUP);
                end
                CHAIN_SETUP: begin
                    if(endpoint_count==0 || endpoint_count>67 || (!standalone_chain && (tree_height>20 || (indexing==1 && tree_height<2))))
                        fail();
                    else begin
                        if (indexing == 1 && !verifying) begin
                            fors_base <= leaf_cursor;
                            fors_offset <= 0;
                            fors_roots_pending <= 0;
                            fors_total<=((21'd1<<tree_height)-leaf_cursor)<FORS_BATCH ? 5'((21'd1<<tree_height)-leaf_cursor) : 5'(FORS_BATCH);
                        end
                        if (!pipe_cache_valid) begin
                            pipe_rolling<=pipe_direct && !(macro_flags[0] && leaf_cursor==target);
                            pipe_active <= 0;
                            pipe_next_chain <= chain_cursor;
                            pipe_completed <= 0;
                        end
                        if (stateful) begin
                            if (pipe_cache_valid) begin
                                pipe_pair <= pipe_pair + 1'b1;
                                enter_state(PIPE_LOAD);
                            end else begin
                                pipe_pair <= 0;
                                pipe_issue_slot <= 0;
                                pipe_done_mask <= 0;
                                for (integer q = 0; q < PIPE_BATCH; q = q + 1)
                                pipe_expected_mask[q] <= 32'(chain_cursor) + q < endpoint_count;
                                pipe_seed_domain <= descriptors[4][55:48];
                                pipe_step_domain <= descriptors[5][55:48];
                                enter_state(verifying ? PIPE_VERIFY_INPUT : PIPE_ISSUE);
                            end
                        end else if (verifying) begin
                            task_chain <= 0;
                            task_capture <= 0;
                            task_step <= descriptors[5];

`line 891 "rtl/executor/executor.sv" 0
                            task_steps <= 0;
                            task_leaf <= scalar_leaf;
                            task_a <= indexing == 1 ? 0 : chain_cursor;
                            task_b <= indexing == 1 ? (group_index << FORS_A) + target : digit(
                                chain_cursor
                            );
                            read_verify_node(VERIFY_CHAIN_INPUT);
                        end else if(!stateful && descriptors[4][59:56]==1 && descriptors[5][59:56]==2)begin
                            if (pipe_cache_valid) begin
                                pipe_pair <= pipe_pair + 1'b1;
                                enter_state(PIPE_LOAD);
                            end else begin
                                pipe_pair <= 0;
                                pipe_issue_slot <= 0;
                                pipe_done_mask <= 0;
                                for (integer q = 0; q < PIPE_BATCH; q = q + 1)
                                pipe_expected_mask[q]<=indexing==1 ? (q<FORS_BATCH && 32'(leaf_cursor)+q < (32'd1<<tree_height))
                                    : (32'(chain_cursor)+q < endpoint_count);
                                pipe_seed_domain <= descriptors[4][55:48];
                                pipe_step_domain <= descriptors[5][55:48];
                                enter_state(PIPE_ISSUE);
                            end
                        end else begin
                            pipe_batch_used <= 0;
                            task_chain <= 1;
                            task_step <= descriptors[5];

`line 918 "rtl/executor/executor.sv" 0
                            task_capture<=(indexing==1 ? leaf_cursor==target : leaf_cursor==target) && macro_flags[0];
                            task_leaf <= indexing == 1 ? scalar_leaf : leaf_cursor;
                            task_a <= indexing == 1 ? 0 : chain_cursor;
                            task_b <= indexing == 1 ? (group_index << FORS_A) + leaf_cursor : 0;
                            task_steps<=(sign_only || (macro_flags[3] && leaf_cursor==target))
                            ? digit(
                                chain_cursor
                            ) : chain_descriptor[19:15];
                            task_capture_after <= indexing == 1 ? 0 : digit(chain_cursor);
                            start_hash(descriptors[4], CHAIN_STORE);
                        end
                    end
                end
                PIPE_ISSUE: begin
                    if (pipe_rolling) begin
                        if (pipe_valid && pipe_completed + 1 >= endpoint_count) begin
                            pipe_rolling <= 0;
                            pipe_batch_used <= 1;
                            pipe_cache_valid <= 0;
                            chain_cursor <= endpoint_count - 1'b1;
                            enter_state(CHAIN_NEXT);
                        end
                    end else if (!pipe_expected_mask[pipe_issue_slot] || pipe_ready) begin
                        if(pipe_issue_slot+1>=PIPELINE ||
                           (pipe_direct && (pipe_expected_mask>>(pipe_issue_slot+1))==0))
                            enter_state(PIPE_WAIT);
                        else pipe_issue_slot <= pipe_issue_slot + 1'b1;
                    end
                end
                PIPE_VERIFY_INPUT:
                if (verify_valid && pipe_ready) begin
                    if(pipe_issue_slot+1>=PIPELINE || (pipe_expected_mask>>(pipe_issue_slot+1))==0)
                        enter_state(PIPE_WAIT);
                    else pipe_issue_slot <= pipe_issue_slot + 1'b1;
                end
                PIPE_WAIT:
                if(pipe_direct && !(macro_flags[0] && leaf_cursor==target)
                    && ((pipe_done_mask | (pipe_valid ? (PIPE_BATCH'(1)<<pipe_tag) : '0))
                        & pipe_expected_mask)==pipe_expected_mask)begin
                     
                     
                     
                    pipe_cache_valid <= 0;
                    pipe_batch_used <= 1;
                    pipe_pair <= 0;
                    advance_direct_batch();
                end else if ((pipe_done_mask & pipe_expected_mask) == pipe_expected_mask) begin
                    if (pipe_direct) begin
                        pipe_cache_valid <= 0;
                        pipe_batch_used <= 1;
                        pipe_pair <= 0;
                        if (macro_flags[0] && leaf_cursor == target) begin
                            start_output(pipe_read_capture, node_bytes, PIPE_CAPTURE_NEXT);
                            pipe_pair <= 1;
                        end else advance_direct_batch();
                    end else if (indexing == 1 && !verifying) begin
                        pipe_cache_valid <= 0;
                        pipe_batch_used  <= 1;
                        enter_state(FORS_PICK);
                    end else enter_state(PIPE_LOAD);
                end
                FORS_PICK: begin
                    if (fors_target_wave && macro_flags[0])
                        start_output(pipe_read_capture, node_bytes, FORS_LEAF_NEXT);
                    else enter_state(FORS_LEAF_NEXT);
                end
                FORS_LEAF_NEXT: begin
                    if (fors_offset + PIPELINE < fors_total) begin
                        fors_offset   <= fors_offset + 5'(PIPELINE);
                        pipe_issue_slot <= 0;
                        pipe_done_mask  <= 0;
                        for (integer q = 0; q < PIPE_BATCH; q++)
                        pipe_expected_mask[q] <= 32'(fors_offset) + PIPELINE + q < fors_total;
                        enter_state(PIPE_ISSUE);
                    end else if (fors_target_group) enter_state(FORS_AUTH0);
                    else enter_state(FORS_BEGIN);
                end
                FORS_AUTH0: enter_state(FORS_BEGIN);
                FORS_BEGIN: begin
                    fors_level <= 0;
                    fors_offset <= 0;
                    pipe_issue_slot <= 0;
                    pipe_done_mask <= 0;
                    for (integer q = 0; q < PIPE_BATCH; q++)
                    pipe_expected_mask[q] <= q < (fors_total >> 1);
                    pipe_seed_domain <= 3;
                    pipe_step_domain <= 3;
                    enter_state(FORS_LEFT);
                end
                FORS_LEFT: enter_state(FORS_ISSUE);
                FORS_ISSUE:
                if (pipe_ready) begin
                    if(pipe_issue_slot+1>=PIPELINE || (pipe_expected_mask>>(pipe_issue_slot+1))==0)
                        enter_state(FORS_WAIT);
                    else begin
                        pipe_issue_slot <= pipe_issue_slot + 1'b1;
                    end
                end
                FORS_WAIT:
                if(((pipe_done_mask | (pipe_valid ? (PIPE_BATCH'(1)<<pipe_tag) : '0)) & pipe_expected_mask)==pipe_expected_mask)begin
                    if (fors_offset + PIPELINE < fors_outputs) begin
                        fors_offset   <= fors_offset + 5'(PIPELINE);
                        pipe_issue_slot <= 0;
                        pipe_done_mask  <= 0;
                        for (integer q = 0; q < PIPE_BATCH; q++)
                        pipe_expected_mask[q] <= 32'(fors_offset) + PIPELINE + q < fors_outputs;
                        enter_state(FORS_LEFT);
                    end else if (fors_level) begin
                        fors_root_cursor <= 0;
                        enter_state(FORS_PUSH);
                    end else enter_state(fors_target_group ? FORS_AUTH1 : FORS_LEVEL);
                end
                FORS_AUTH1: enter_state(FORS_LEVEL);
                FORS_LEVEL: begin
                    fors_level <= 1;
                    fors_offset <= 0;
                    pipe_issue_slot <= 0;
                    pipe_done_mask <= 0;
                    for (integer q = 0; q < PIPE_BATCH; q++)
                    pipe_expected_mask[q] <= q < (fors_total >> 2);
                    enter_state(FORS_LEFT);
                end
                FORS_PUSH: begin
                    node_value <= endpoint_value0;
                    node_level <= 2;
                    node_index <= (fors_base >> 2) + 21'(fors_root_cursor);
                    leaf_cursor <= fors_base + (21'(fors_root_cursor) << 2) + 3;
                    fors_roots_pending <= 1;
                    pipe_cache_valid <= 0;
                    pipe_batch_used <= 0;
                    enter_state(PUSH_NODE);
                end
                FORS_ROOT_NEXT: begin
                    if (fors_root_cursor + 1 < (fors_total >> 2)) begin
                        fors_root_cursor <= fors_root_cursor + 1'b1;
                        enter_state(FORS_PUSH);
                    end else begin
                        fors_roots_pending <= 0;
                        leaf_cursor <= fors_base + 21'(fors_total);
                        chain_cursor <= 0;
                        enter_state(CHAIN_SETUP);
                    end
                end
                PIPE_LOAD: begin
                    pipe_batch_used <= 1;
                    pipe_cache_valid<=pipe_pair+1<PIPELINE && ((pipe_expected_mask>>(pipe_pair+1))!=0);
                    result <= {{(V - W) {1'b0}}, pipe_read_result};
                    enter_state(CHAIN_STORE);
                end
                CHAIN_STORE: begin
                    if (standalone_chain && chain_cursor == 0) node_value <= result[W-1:0];
                    task_chain <= 0;
                    if (sign_only || (!verifying && macro_flags[0] && leaf_cursor == target))
                        enter_state(CHAIN_OUTPUT0);
                    else enter_state(CHAIN_NEXT);
                end
                CHAIN_OUTPUT0:
                start_output(sign_only ? result[W-1:0] : selected_capture, node_bytes, CHAIN_NEXT);
                CHAIN_NEXT: begin
                    if (indexing != 1 && chain_cursor + 1 < endpoint_count) begin
                        chain_cursor <= chain_cursor + 1;
                        enter_state(CHAIN_SETUP);
                    end else if (sign_only) complete_macro();
                    else if (stateful && chain_descriptor[13:12] == 2) begin
                        lt_count  <= endpoint_count;
                        lt_cursor <= 0;
                        lt_level  <= 0;
                        enter_state(LT_PIPE_INIT);
                    end else if (standalone_chain && chain_descriptor[13:12] == 0)
                        route_result(ROUTE_NODE);
                    else if (!verifying && macro_flags[3] && leaf_cursor == target) begin
                        node_value <= 0;
                        node_level <= 0;
                        node_index <= leaf_cursor;
                        enter_state(PUSH_NODE);
                    end else if (chain_descriptor[13:12] == 0) begin
                        node_value <= result[W-1:0];
                        node_level <= 0;
                        node_index <= leaf_cursor;
                        enter_state(PUSH_NODE);
                    end else begin
                        enter_state(REDUCE_SETUP);
                    end
                end
                REDUCE_SETUP: begin
                    task_chain <= 0;
                    task_capture <= 0;
                    task_steps <= 0;
                    task_leaf <= leaf_cursor;
                    task_a <= 0;
                    task_b <= 0;
                    start_hash(descriptors[4], stateful ? SF_REDUCED : LEAF_SETUP);
                end
                LT_SETUP: enter_state(LT_PIPE_INIT);
                LT_PIPE_INIT: begin
                    pipe_rolling <= 0;
                    if (lt_cursor + 1 >= lt_count) enter_state(LT_COPY);
                    else begin
                        pipe_issue_slot  <= 0;
                        pipe_done_mask   <= 0;
                        pipe_seed_domain <= descriptors[4][55:48];
                        pipe_step_domain <= descriptors[4][55:48];
                        for (integer q = 0; q < PIPE_BATCH; q++)
                        pipe_expected_mask[q] <= 32'(lt_cursor) + 2 * q + 1 < lt_count;
                        enter_state(LT_PIPE_ISSUE);
                    end
                end
                LT_PIPE_ISSUE:
                if (pipe_ready) begin
                    if(pipe_issue_slot+1>=PIPELINE || (pipe_expected_mask>>(pipe_issue_slot+1))==0)
                        enter_state(LT_PIPE_WAIT);
                    else pipe_issue_slot <= pipe_issue_slot + 1'b1;
                end
                 
                 
                 
                LT_PIPE_WAIT: if (lt_batch_complete) begin
                    if (lt_cursor + 2 * PIPELINE < lt_count) begin
                        lt_cursor <= lt_cursor + 2 * PIPELINE;
                        enter_state(LT_PIPE_INIT);
                    end else if (lt_count[0]) begin
                        lt_cursor <= lt_count - 1'b1;
                        enter_state(LT_COPY);
                    end else if (lt_count <= 2) enter_state(LT_FINISH);
                    else begin
                        lt_count  <= (lt_count + 1) >> 1;
                        lt_cursor <= 0;
                        lt_level  <= lt_level + 1'b1;
                        enter_state(LT_PIPE_INIT);
                    end
                end
                LT_STORE, LT_COPY: enter_state(LT_NEXT);
                LT_NEXT: begin
                    if (lt_cursor + 2 < lt_count) begin
                        lt_cursor <= lt_cursor + 2;
                        enter_state(LT_SETUP);
                    end else if (lt_count <= 2) enter_state(LT_FINISH);
                    else begin
                        lt_count  <= (lt_count + 1) >> 1;
                        lt_cursor <= 0;
                        lt_level  <= lt_level + 1'b1;
                        enter_state(LT_SETUP);
                    end
                end
                LT_FINISH: begin
                    node_value <= endpoint_value0;
                    if (verifying && standalone_chain) begin
                        value[2] <= endpoint_value0;
                        complete_macro();
                    end else begin
                        node_index <= leaf_cursor;
                        node_level <= 0;
                        enter_state(PUSH_NODE);
                    end
                end
                SF_REDUCED: enter_state(SF_LEAF);
                SF_LEAF: begin
                    task_chain <= 0;
                    task_capture <= 0;
                    task_steps <= 0;
                    task_leaf <= leaf_cursor;
                    task_a <= 0;
                    task_b <= (32'd1 << stateful_height) + 32'(leaf_cursor);
                    start_hash(descriptors[0], SF_LEAF_DONE);
                end
                SF_LEAF_DONE: begin
                    node_value <= result[W-1:0];
                    if (verifying && standalone_chain) begin
                        value[2] <= result[W-1:0];
                        complete_macro();
                    end else begin
                        node_index <= leaf_cursor;
                        node_level <= 0;
                        enter_state(PUSH_NODE);
                    end
                end
                SF_RANDOM: begin
                    value[0] <= emit_value;
                    if (xmss) complete_macro();
                    else start_hash(saved_descriptor, HASH_RESULT);
                end
                LEAF_SETUP:
                if (standalone_chain) route_result(ROUTE_HASH);
                else begin
                    node_value <= result[W-1:0];
                    node_level <= 0;
                    node_index <= verifying ? target : leaf_cursor;
                    enter_state(PUSH_NODE);
                end
                PUSH_NODE, PUSH_STACK: begin
                    if (state == PUSH_NODE && auth_write && stack_write) enter_state(PUSH_STACK);
                    else begin
                        if (node_level == tree_height) begin
                            auth_level <= 0;
                            if (!verifying && macro_flags[1]) enter_state(AUTH_OUTPUT);
                            else enter_state(TREE_FINISH);
                        end else if (verifying) read_verify_node(PARENT_SETUP);
                        else if (node_index[0]) enter_state(PARENT_SETUP);
                        else begin
                            if (fors_roots_pending) enter_state(FORS_ROOT_NEXT);
                            else begin
                                leaf_cursor  <= leaf_cursor + 1'b1;
                                chain_cursor <= 0;
                                enter_state(CHAIN_SETUP);
                            end
                        end
                    end
                end
                PARENT_SETUP: begin
                    if(!verifying && macro_flags[3] && (node_index>>1)==(target>>(node_level+1))) begin
                        node_value <= 0;
                        node_index <= node_index >> 1;
                        node_level <= node_level + 1'b1;
                        enter_state(PUSH_NODE);
                    end else begin
                        task_chain <= 0;
                        task_capture <= 0;
                        task_steps <= 0;
                        task_leaf <= indexing == 1 ? scalar_leaf : 0;
                        task_a <= descriptors[7][59:56] == 8 ? node_level : node_level + 1'b1;
                        task_b<=indexing==1 ? ((group_index<<FORS_A)>>(node_level+1))+(node_index>>1)
                            : indexing==2 ? (1<<(tree_height-node_level-1))+(node_index>>1) : (node_index>>1);
                        result[W-1:0]<=verifying ? (node_index[0] ? emit_value : node_value) : endpoint_value0;
                        start_hash(descriptors[4], PARENT_DONE);
                    end
                end
                PARENT_DONE: begin
                    node_value <= result[W-1:0];
                    node_index <= node_index >> 1;
                    node_level <= node_level + 1'b1;
                    enter_state(PUSH_NODE);
                end
                AUTH_OUTPUT: begin
                    if (auth_level < tree_height) begin
                        start_output(endpoint_value0, node_bytes, AUTH_OUTPUT);
                        auth_level <= auth_level + 1'b1;
                    end else enter_state(TREE_FINISH);
                end
                TREE_FINISH: begin
                    if (stateful && verifying) value[2] <= node_value;
                    route_result(!verifying && macro_flags[3] ? ROUTE_SAVED : ROUTE_NODE);
                end
                HASH_ISSUE: if (lane_ready) enter_state(HASH_WAIT);
                HASH_WAIT:
                if (lane_valid) begin
                    result <= lane_value;
                    if (lane_error) fail();
                    else enter_state(hash_return);
                end
                HASH_RESULT: route_result(ROUTE_HASH);
                ROUTE: begin
                    if (macro_route == 0) complete_macro();
                    else begin
                        if (!route_descriptor[53]) begin
                            value[route_descriptor[57:56]] <= route_value[W-1:0];
                            if (route_descriptor[57:56] == 1)
                                fors_digest_tail <= route_value[FORS_DIGEST_BITS-1:W];
                        end
                        if (route_descriptor[54]) begin
                            scalar_tree <= parsed_tree(route_value);
                            scalar_leaf <= parsed_leaf(route_value);
                        end
                        if (!verifying && route_descriptor[55])
                            start_output(route_value[W-1:0], node_bytes, FETCH);
                        else enter_state(FETCH);
                        seq_complete <= 1;
                    end
                end
                TRANSFORM: begin
                    if (descriptor[59:56] == 2) begin
                        scalar_leaf <= scalar_tree & ((1 << descriptor[43:40]) - 1);
                        scalar_tree <= scalar_tree >> descriptor[43:40];
                        complete_macro();
                    end else if (descriptor[59:56] == 1) begin
                        checksum <= checksum + chain_max - digit(transform_index);
                        if (transform_index + 1 == LEN1) complete_macro();
                        else transform_index <= transform_index + 1'b1;
                    end else fail();
                end
                EMIT: begin
                    start_output(emit_source, emit_descriptor[53:48], EMIT_NEXT);
                end
                EMIT_NEXT: begin
                    if (emit_cursor + 1 < emit_count) begin
                        emit_cursor <= emit_cursor + 1'b1;
                        enter_state(EMIT);
                    end else complete_macro();
                end
                VERIFY_INPUT:
                if (verify_valid) begin
                    emit_value <= verify_data;
                    enter_state(verify_return);
                end
                VERIFY_RANDOM: route_result(ROUTE_EMIT);
                VERIFY_CHAIN_INPUT: begin
                     
                    result <= {{(V - W) {1'b0}}, emit_value};
                    if (indexing == 1) start_hash(task_step, LEAF_SETUP);
                    else enter_state(VERIFY_CHAIN_RUN);
                end
                VERIFY_CHAIN_RUN: begin
                    if (!verify_step_needed) begin
                        enter_state(CHAIN_STORE);
                    end else start_hash(descriptors[0], VERIFY_CHAIN_ADVANCE);
                end
                VERIFY_CHAIN_ADVANCE: begin
                    task_b <= {28'd0, task_b[3:0] + 4'd1};
                    enter_state(VERIFY_CHAIN_RUN);
                end
                OUTPUT_CHUNK: begin
                    if (pipe_direct && output_return == PIPE_CAPTURE_NEXT) begin
                        if (pipe_pair < PIPELINE && (pipe_expected_mask >> pipe_pair) != 0) begin
                            emit_value <= pipe_read_capture;
                            pipe_pair  <= pipe_pair + 1'b1;
                        end else advance_direct_batch();
                    end else enter_state(output_return);
                end
                DRAIN: enter_state(FINISH);
                FINISH: begin
                    done <= 1;
                    enter_state(IDLE);
                end
                FAILED: enter_state(IDLE);
                default: fail();
            endcase
        end
    end
endmodule
`default_nettype wire

`line 1348 "rtl/executor/executor.sv" 2
`line 1 "rtl/top/top.sv" 1
`timescale 1ns / 1ps
`default_nettype none

`line 4 "rtl/top/top.sv" 0
 
module top #(
    parameter integer UNROLL=2,PIPELINE=1,
    parameter [255:0] SECRET_SEED=256'h00000000000000000000000000000000d1d06dcbb9181a55aabce64467d6b81d,
    parameter [255:0] SECRET_PRF=256'h00000000000000000000000000000000ca423fc52136322bce5c73a684d95cb7,
    parameter [255:0] PUBLIC_SEED=256'h00000000000000000000000000000000f416dc35e41222ef87445111008541d5,
    parameter [255:0] RANDOMIZER=256'h00000000000000000000000000000000f416dc35e41222ef87445111008541d5,
    parameter [255:0] PUBLIC_ROOT=256'h000000000000000000000000000000003d774653892d5f3695b370c7cdab63ff,
    parameter [31:0] KEY_INDEX=0,
    parameter [127:0] IDENTIFIER=0,
    parameter [1:0] OPERATION=2'd1,
    parameter PROGRAM_INIT_FILE="tb/vectors/slh_128f/sign/program.mem",
    parameter TEMPLATE_INIT_FILE="tb/vectors/slh_128f/sign/template.mem",
    parameter DESCRIPTOR_INIT_FILE="tb/vectors/slh_128f/sign/descriptor.mem"
)(
 
    output logic [15:0] error_code,
    output logic [63:0] boot_cycles, keygen_cycles, sign_cycles,
    output wire [63:0] hash_count, permutation_count,

`line 24 "rtl/top/top.sv" 0
    input wire clk, rst,
    input wire message_valid, output wire message_ready,
    input wire [6:0] message_length, input wire [63:0] message_data,
    input wire verify_valid, output wire verify_ready,
    input wire [255:0] verify_data, output wire verify_pass,
    output logic busy, done, keygen_done,error,
    output wire out_valid, output wire [255:0] out_data, output wire [5:0] out_bytes,
    output wire [1:0] result_kind,
    input wire signature_read_enable, input wire [10:0] signature_read_address,
    output wire signature_read_valid, output wire [255:0] signature_read_data,
    output wire [5:0] signature_read_bytes,
    output wire [5:0] signature_node_bytes,
    output wire signature_valid,signature_error,
    output wire [10:0] signature_nodes, output wire [15:0] signature_length
);
 
    wire [3:0] program_address;
    wire [3:0] template_address;
    wire [63:0] program_data, template_data;
    wire [9:0] descriptor_addresses;
    wire [127:0] descriptor_data;

`line 46 "rtl/top/top.sv" 0
     
     
    (* rom_style = "distributed", DONT_TOUCH = "yes" *) logic [63:0] program_memory[0:15];
    (* rom_style = "distributed", DONT_TOUCH = "yes" *) logic [63:0] template_memory[0:15];
    (* rom_style = "distributed", DONT_TOUCH = "yes" *) logic [63:0] descriptor_memory[0:31];
    initial begin
        if (PROGRAM_INIT_FILE != "") $readmemh(PROGRAM_INIT_FILE, program_memory);
        if (TEMPLATE_INIT_FILE != "") $readmemh(TEMPLATE_INIT_FILE, template_memory);
        if (DESCRIPTOR_INIT_FILE != "") $readmemh(DESCRIPTOR_INIT_FILE, descriptor_memory);
    end
    assign program_data = program_memory[program_address];
    assign template_data = template_memory[template_address];
    assign descriptor_data = {
        descriptor_memory[descriptor_addresses[9:5]], descriptor_memory[descriptor_addresses[4:0]]
    };

`line 62 "rtl/top/top.sv" 0
     
    typedef enum logic [2:0] { HEADER, PROFILE, RELEASE, REQUEST, RUN, HALTED} phase_t;

`line 65 "rtl/top/top.sv" 0
    phase_t phase;
    logic [63:0] image_header, profile_descriptor;
    logic core_released;
    wire [9:0] core_descriptor_addresses;
    wire core_message_ready, core_job_ready, core_done, core_error;
 
    wire [15:0] core_error_code;
    wire [63:0] core_cycles;


`line 75 "rtl/top/top.sv" 0
    wire [3:0] entry = OPERATION ? image_header[44:41] : image_header[39:36];
    wire message_length_valid = OPERATION <= 2 &&
        (OPERATION ? (message_length >= 7'd1 && message_length <= 7'd87)
                       : message_length == 7'd0);
    wire core_rst = rst || !core_released;
    assign descriptor_addresses = !core_released
        ? {5'd0, (phase == HEADER ? 5'd0 : 5'd1)}
        : core_descriptor_addresses;
    assign result_kind = OPERATION;
    assign message_ready = phase == RUN && core_message_ready;

`line 86 "rtl/top/top.sv" 0
     
    executor #(.UNROLL(UNROLL),.PIPELINE(PIPELINE)) core (
 
        .error_code(core_error_code),
        .hash_count,.permutation_count,.cycles(core_cycles),

`line 92 "rtl/top/top.sv" 0
        .clk,.rst(core_rst),.image_header,.profile_descriptor,.job_entry(entry),
        .program_address,.program_data,.template_address,.template_data,
        .descriptor_addresses(core_descriptor_addresses),.descriptor_data,
        .job_valid(phase==REQUEST && message_length_valid),.job_ready(core_job_ready),
        .job_index(KEY_INDEX),.job_identifier(IDENTIFIER),
        .job_operation(OPERATION),.job_message_length(message_length),
        .job_secret_seed(SECRET_SEED),.job_secret_prf(SECRET_PRF),
        .job_public_seed(PUBLIC_SEED),.job_randomizer(RANDOMIZER),.job_public_root(PUBLIC_ROOT),
        .message_valid(message_valid && phase==RUN),.message_ready(core_message_ready),.message_data,
        .verify_valid(verify_valid && phase==RUN),.verify_ready,.verify_data,.verify_pass,
        .out_valid,.out_data,.out_bytes,
        .busy(),.done(core_done),.error(core_error)
    );
     

`line 107 "rtl/top/top.sv" 0
     
    always_ff @(posedge clk) begin
        if (rst) begin
            phase <= HEADER;
            core_released <= 0;
            busy <= 1;
            done <= 0;
            keygen_done <= 0;
            error <= 0;
            image_header <= 0;
            profile_descriptor <= 0;
        end else begin
            keygen_done <= 0;
            if (core_released && core_error) begin
                error <= 1;
                busy  <= 0;
                phase <= HALTED;
            end else begin
                case (phase)
                    HEADER: begin
                        image_header <= descriptor_data[63:0];
                        phase <= PROFILE;
                    end
                    PROFILE: begin
                        profile_descriptor <= descriptor_data[63:0];
                        core_released <= 1;
                        phase <= RELEASE;
                    end
                    RELEASE: phase <= REQUEST;
                    REQUEST: begin
                        if (!message_length_valid) begin
                            error <= 1;
                            busy  <= 0;
                            phase <= HALTED;
                        end else if (core_job_ready) begin
                            phase <= RUN;
                        end
                    end
                    RUN: begin
                        if (core_done) begin
                            if (!OPERATION) keygen_done <= 1;
                            done  <= 1;
                            busy  <= 0;
                            phase <= HALTED;
                        end
                    end
                    HALTED: begin
                    end
                    default: phase <= HALTED;
                endcase
            end
        end
    end

`line 161 "rtl/top/top.sv" 0
 
     
    always_ff @(posedge clk) begin
        if (rst) begin
            error_code <= 0;
            boot_cycles <= 0;
            keygen_cycles <= 0;
            sign_cycles <= 0;
        end else begin
            if (!core_released) boot_cycles <= boot_cycles + 1;
            if (core_released && core_error) begin
                error_code <= core_error_code;
            end else if (phase == REQUEST && !message_length_valid) begin
                error_code <= 16'h3002;
            end else if (phase == RUN && core_done) begin
                if (OPERATION == 1) sign_cycles <= core_cycles;
                else if (OPERATION == 0) keygen_cycles <= core_cycles;
            end
        end
    end

`line 182 "rtl/top/top.sv" 0
     

`line 184 "rtl/top/top.sv" 0
     
     
 
        

`line 189 "rtl/top/top.sv" 0
    localparam bit SIGNATURE_STORE_PRESENT = 0;


`line 192 "rtl/top/top.sv" 0
    generate
        if (SIGNATURE_STORE_PRESENT && OPERATION == 1) begin : stored_signature
             
            signature storage (
                .clk,.rst,.finish(done),.abort(error),
                .write_valid(out_valid),.write_data(out_data),.write_bytes(out_bytes),
                .read_enable(signature_read_enable),.read_address(signature_read_address),
                .read_valid(signature_read_valid),.read_data(signature_read_data),.read_bytes(signature_read_bytes),
                .node_bytes(signature_node_bytes),.complete(signature_valid),
                .error(signature_error),.nodes(signature_nodes),.length(signature_length)
            );
             
        end else begin : no_signature_store
            assign signature_read_valid = 0;
            assign signature_read_bytes = 0;
            assign signature_read_data = 0;
            assign signature_node_bytes = 0;
            assign signature_valid = 0;
            assign signature_error = 0;
            assign signature_nodes = 0;
            assign signature_length = 0;
        end
    endgenerate
endmodule

`line 217 "rtl/top/top.sv" 0
`default_nettype wire

`line 219 "rtl/top/top.sv" 2
`line 1 "rtl/top/common.sv" 1
 
`timescale 1ns / 1ps
`default_nettype none

`line 5 "rtl/top/common.sv" 0
 
module common #(parameter integer UNROLL=2,PIPELINE=1)(
 
    output logic [15:0] error_code,
    output logic [63:0] boot_cycles,keygen_cycles,sign_cycles,
    output wire [63:0] hash_count,permutation_count,

`line 12 "rtl/top/common.sv" 0
    input wire clk,rst,
    output wire [3:0] program_address, output wire [3:0] template_address,
    input wire [63:0] program_data, template_data,
    output wire [9:0] descriptor_addresses, input wire [127:0] descriptor_data,
    input wire [255:0] job_secret_seed, job_secret_prf, job_public_seed, job_randomizer, job_public_root,
    input wire [31:0] job_index, input wire [127:0] job_identifier,
    input wire [1:0] job_operation, input wire [6:0] message_length,
    input wire verify_valid, output wire verify_ready,
    input wire [255:0] verify_data, output wire verify_pass,
    input wire [63:0] message_data, input wire message_valid, output wire message_ready,
    output wire out_valid, output wire [255:0] out_data, output wire [5:0] out_bytes,
    output wire [1:0] result_kind, output logic busy, done, keygen_done, error
);
 
    typedef enum logic [2:0] { HEADER, PROFILE, RELEASE, REQUEST, RUN, HALTED} phase_t;

`line 28 "rtl/top/common.sv" 0
    phase_t phase;
    logic [63:0] image_header, profile_descriptor;
    logic core_released;
    wire [9:0] core_descriptor_addresses;
    wire core_message_ready, core_job_ready, core_done, core_error;
 
    wire [15:0] core_error_code;
    wire [63:0] core_cycles;


`line 38 "rtl/top/common.sv" 0
    wire [3:0] entry = job_operation ? image_header[44:41] : image_header[39:36];
    wire message_length_valid = job_operation <= 2 &&
        (job_operation ? (message_length >= 7'd1 && message_length <= 7'd87)
                       : message_length == 7'd0);
    wire core_rst = rst || !core_released;
    assign descriptor_addresses = !core_released
        ? {5'd0, (phase == HEADER ? 5'd0 : 5'd1)}
        : core_descriptor_addresses;
    assign result_kind = job_operation;
    assign message_ready = phase == RUN && core_message_ready;

`line 49 "rtl/top/common.sv" 0
     
    executor #(.UNROLL(UNROLL),.PIPELINE(PIPELINE)) core (
 
        .error_code(core_error_code),
        .hash_count,.permutation_count,.cycles(core_cycles),

`line 55 "rtl/top/common.sv" 0
        .clk,.rst(core_rst),.image_header,.profile_descriptor,.job_entry(entry),
        .program_address,.program_data,.template_address,.template_data,
        .descriptor_addresses(core_descriptor_addresses),.descriptor_data,
        .job_valid(phase==REQUEST && message_length_valid),.job_ready(core_job_ready),
        .job_index,.job_identifier,
        .job_operation,.job_message_length(message_length),
        .job_secret_seed,.job_secret_prf,
        .job_public_seed,.job_randomizer,.job_public_root,
        .message_valid(message_valid && phase==RUN),.message_ready(core_message_ready),.message_data,
        .verify_valid(verify_valid && phase==RUN),.verify_ready,.verify_data,.verify_pass,
        .out_valid,.out_data,.out_bytes,
        .busy(),.done(core_done),.error(core_error)
    );
     

`line 70 "rtl/top/common.sv" 0
     
    always_ff @(posedge clk) begin
        if (rst) begin
            phase <= HEADER;
            core_released <= 0;
            busy <= 1;
            done <= 0;
            keygen_done <= 0;
            error <= 0;
            image_header <= 0;
            profile_descriptor <= 0;
        end else begin
            keygen_done <= 0;
            if (core_released && core_error) begin
                error <= 1;
                busy  <= 0;
                phase <= HALTED;
            end else begin
                case (phase)
                    HEADER: begin
                        image_header <= descriptor_data[63:0];
                        phase <= PROFILE;
                    end
                    PROFILE: begin
                        profile_descriptor <= descriptor_data[63:0];
                        core_released <= 1;
                        phase <= RELEASE;
                    end
                    RELEASE: phase <= REQUEST;
                    REQUEST: begin
                        if (!message_length_valid) begin
                            error <= 1;
                            busy  <= 0;
                            phase <= HALTED;
                        end else if (core_job_ready) begin
                            phase <= RUN;
                        end
                    end
                    RUN: begin
                        if (core_done) begin
                            if (!job_operation) keygen_done <= 1;
                            done  <= 1;
                            busy  <= 0;
                            phase <= HALTED;
                        end
                    end
                    HALTED: begin
                    end
                    default: phase <= HALTED;
                endcase
            end
        end
    end

`line 124 "rtl/top/common.sv" 0
 
     
    always_ff @(posedge clk) begin
        if (rst) begin
            error_code <= 0;
            boot_cycles <= 0;
            keygen_cycles <= 0;
            sign_cycles <= 0;
        end else begin
            if (!core_released) boot_cycles <= boot_cycles + 1;

`line 135 "rtl/top/common.sv" 0
            if (core_released && core_error) begin
                error_code <= core_error_code;
            end else if (phase == REQUEST && !message_length_valid) begin
                error_code <= 16'h3002;
            end else if (phase == RUN && core_done) begin
                if (job_operation == 1) sign_cycles <= core_cycles;
                else if (job_operation == 0) keygen_cycles <= core_cycles;
            end
        end
    end

`line 146 "rtl/top/common.sv" 0
endmodule

`line 148 "rtl/top/common.sv" 0
`default_nettype wire

`line 150 "rtl/top/common.sv" 2
