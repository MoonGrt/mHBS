#!/usr/bin/env python3
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from hashlib import sha256
import json,re,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'sha256_balanced_h_20261022/H2_late_sigma_e/fixture/build'
METRICS=re.compile(r'SHA256_PASS P=(\d+) U=(\d+) vectors=(\d+) cycles=(\d+) stalls=(\d+) simultaneous=(\d+) reset_replay=(\d+)')
def metrics(path):
    result={}
    for log in path.glob('P*U*/run.log'):
        match=METRICS.search(log.read_text())
        if match:
            p,u,*values=map(int,match.groups());result[f'P{p}U{u}']=values
    return result
started=time.time()
def run(view):
    command=[sys.executable,str(ROOT/'fixture/scripts/check_sha256.py'),'--all','--jobs','2']
    if view=='synthesis': command+=['--synthesis']
    with (ROOT/(view+'.log')).open('w') as log:
        result=subprocess.run(command,cwd=ROOT/'fixture',stdout=log,stderr=subprocess.STDOUT)
    return view,result.returncode
with ThreadPoolExecutor(max_workers=2) as pool:
    codes=dict(pool.map(run,['normal','synthesis']))
reports={};comparison={}
for view,suffix in [('normal','sha256_check'),('synthesis','sha256_check_synthesis')]:
    report=json.loads((ROOT/'fixture/build'/suffix/'VALIDATION.json').read_text())
    reports[view]={'passed':report['passed'],'total':report['total'],'source_unchanged':report['source_unchanged']}
    got=metrics(ROOT/'fixture/build'/suffix);baseline=metrics(BASE/suffix)
    comparison[view]={'metrics_identical_to_H2':got==baseline,'configurations':len(got),'metrics':got}
summary={'schema':'mhbs.sha256.carry_select.validation.v1','label':'H3_16_16_carry_select','source':json.loads((ROOT/'SOURCE.json').read_text()),'return_codes':codes,'reports':reports,'vectors_per_configuration':181,'baseline_comparison':comparison,'elapsed_seconds':time.time()-started,'physical_status':'No Vivado launched; root must perform source-bound synthesis/route.'}
(ROOT/'VALIDATION_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'return_codes':codes,'reports':reports,'identical':{k:v['metrics_identical_to_H2'] for k,v in comparison.items()},'elapsed_seconds':summary['elapsed_seconds']}),flush=True)
if any(codes.values()) or not all(v['metrics_identical_to_H2'] for v in comparison.values()):sys.exit(1)
