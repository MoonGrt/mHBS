#!/usr/bin/env python3
"""Validate a frozen P1 scalar candidate; never launch Vivado or h20 tree builds."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import subprocess
import threading
import time

PROJECT = Path(__file__).resolve().parents[2]
PROFILES = ('slh_128f','slh_192f','slh_256f','slh_128s','slh_192s','slh_256s',
            'xmss_h10','xmss_h16','xmss_h20','lms_h10','lms_h15','lms_h20')
TARGETS = ('slh_128f','xmss_h10','lms_h10')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source',type=Path,required=True,help='Frozen source root containing sources.txt, RTL, scripts, model and vectors')
parser.add_argument('--workers',type=int,default=2)
args = parser.parse_args()
ROOT = args.source.resolve()
OUTPUT = ROOT/'validation/p1_scalar'
OUTPUT.mkdir(parents=True,exist_ok=True)
STARTED = time.time()
SOURCE_FILES = sorted(set((ROOT/'sources.txt').read_text().splitlines()) | {'sources.txt'} |
                      {str(p.relative_to(ROOT)) for d in ('tb','scripts','model') for p in (ROOT/d).rglob('*')
                       if p.is_file() and p.suffix in ('.sv','.cpp','.py','.sh','.mem','.json')})
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
SOURCE_HASHES = {name:sha(ROOT/name) for name in SOURCE_FILES}
RECORDS=[]
LOCK=threading.Lock()
GROUPS=[]


def case(name,command,marker='STATEFUL_PASS',environment=None,**details):
    return dict(name=name,command=command,marker=marker,environment=environment or {},details=details)


def fast(profile,op,p,u,synthesis,**options):
    env={'SIM_SYNTHESIS':str(synthesis)}
    env.update(options.pop('environment',{}))
    return case(f'{op}_P{p}U{u}_synthesis{synthesis}_{profile}'+options.pop('suffix',''),
                ['bash','scripts/simulate_fast.sh',profile,op,str(p),str(u)],environment=env,**options)


hash_cases=[case('source_four_macro_audit',['python3','scripts/audit_rtl_debug.py','--lint','--output','validation/p1_scalar/source_audit.json'],'RTL_DEBUG_AUDIT_PASS')]
for p,u in ((1,1),(1,2),(4,1)):
    for synthesis in (0,1):
        flag=['--synthesis'] if synthesis else []
        hash_cases.append(case(f'recipes_P{p}U{u}_synthesis{synthesis}',
                               ['python3','scripts/check_recipes.py','--pipeline',str(p),'--unroll',str(u),*flag],
                               'RECIPE_PASS cases=459'))
        hash_cases.append(case(f'statistics_P{p}U{u}_synthesis{synthesis}',
                               ['python3','scripts/check_statistics.py','--pipeline',str(p),'--unroll',str(u),*flag],
                               'STATISTICS_PASS'))
for u,synthesis in ((1,0),(2,1)):
    hash_cases.append(case(f'recipes_mask101e_P1U{u}_synthesis{synthesis}',
                           ['python3','scripts/check_recipes.py','--pipeline','1','--unroll',str(u),'--recipe-mask','0x101e',
                            *(['--synthesis'] if synthesis else [])],'RECIPE_PASS cases=186'))
for synthesis in (0,1):
    hash_cases.append(case(f'pipeline_P4U1_synthesis{synthesis}',
                           ['python3','scripts/check_pipeline.py',*(['--synthesis'] if synthesis else [])],'PIPELINE_PASS'))
GROUPS.append(hash_cases)

for u in (1,2):
    for synthesis in (0,1):
        group=[]
        for profile in (PROFILES if not synthesis else TARGETS):
            group.append(fast(profile,'verify',1,u,synthesis))
        for profile in TARGETS:
            group.append(fast(profile,'sign',1,u,synthesis))
            group.append(case(f'events_P1U{u}_synthesis{synthesis}_{profile}',
                              ['bash','scripts/simulate.sh',profile,'verify','1',str(u),'+STALL=1','+REPLAYS=2','+INTERRUPT=1','+CUT=5'],
                              environment={'SIM_SYNTHESIS':str(synthesis)}))
        for name,options,marker in (
            ('q_overflow',['+Q=1024','+INVALID=1'],'INDEX_REJECT_PASS'),
            ('invalid_profile',['+PROFILE=9'],'INDEX_REJECT_PASS'),
            ('scalar_lane_fault',['+FAULT=1'],'STATEFUL_FAULT_PASS'),
            ('illegal_state',['+FAULT=3'],'STATEFUL_FAULT_PASS')):
            group.append(case(f'{name}_P1U{u}_synthesis{synthesis}',
                              ['bash','scripts/simulate.sh','xmss_h10','verify','1',str(u),*options],marker,
                              {'SIM_SYNTHESIS':str(synthesis)}))
        if not synthesis:
            group.append(case(f'slh_sign_events_P1U{u}',
                              ['bash','scripts/simulate.sh','slh_128f','sign','1',str(u),'+STALL=1','+REPLAYS=2','+INTERRUPT=1']))
        if u==1 and not synthesis:
            for profile in TARGETS:
                group.append(fast(profile,'keygen',1,u,synthesis))
            for profile in ('xmss_h10','lms_h10'):
                for q in (1,1023):
                    vectors=PROJECT/'build/pu_generic/20261013_201408/audit/extended'/f'{profile}_q{q}'
                    fixture=vectors/profile/'sign'
                    group.append(fast(profile,'sign',1,u,synthesis,suffix=f'_q{q}',environment={'VECTORS_DIR':str(vectors)},q=q,
                                      vectors_sha256={p.name:sha(p) for p in fixture.glob('*.mem')}))
                for tamper in (1,2,3,4,5):
                    group.append(case(f'tamper{tamper}_P1U1_{profile}',
                                      ['bash','scripts/simulate.sh',profile,'verify','1','1',f'+TAMPER={tamper}']))
        GROUPS.append(group)
GROUPS.append([fast(profile,'verify',4,1,0) for profile in TARGETS])
EXPECTED=sum(len(group) for group in GROUPS)


def publish(complete=False):
    data=dict(schema='mhbs.p1_scalar.validation.v1',expected_records=EXPECTED,complete=complete,
              passed=(not complete or len(RECORDS)==EXPECTED) and all(r['passed'] for r in RECORDS),
              elapsed_seconds=time.time()-STARTED,source_root=str(ROOT),source_sha256=SOURCE_HASHES,
              runner=str(Path(__file__).resolve()),runner_sha256=sha(Path(__file__)),
              source_unchanged=all(sha(ROOT/name)==digest for name,digest in SOURCE_HASHES.items()),
              h20_full_keygen_sign_run=False,results=RECORDS)
    temporary=OUTPUT/'VALIDATION.json.tmp'
    temporary.write_text(json.dumps(data,indent=2)+'\n')
    temporary.replace(OUTPUT/'VALIDATION.json')


def run_group(group):
    for task in group:
        env=os.environ.copy();env.pop('PROFILE_ENABLE',None);env['SIM_SYNTHESIS']='0';env.update(task['environment'])
        log=OUTPUT/(task['name']+'.log')
        begin=time.time()
        with log.open('w') as handle:
            result=subprocess.run(task['command'],cwd=ROOT,env=env,stdout=handle,stderr=subprocess.STDOUT)
        output=log.read_text()
        record=dict(name=task['name'],command=task['command'],environment=task['environment'],
                    passed=result.returncode==0 and task['marker'] in output,
                    seconds=time.time()-begin,log=str(log),log_sha256=sha(log),**task['details'])
        matches=re.findall(r'STATEFUL_PASS P(\d+)U(\d+) op=(\d+) cycles=(\d+) total=(\d+) hashes=(\d+) permutations=(\d+)',output)
        if matches:
            record['measurements']=[dict(zip(('pipeline','unroll','operation','cycles','total_cycles','hashes','permutations'),map(int,m))) for m in matches]
        with LOCK:
            RECORDS.append(record);publish()
        print(json.dumps(record),flush=True)
        if not record['passed']:
            raise RuntimeError(task['name']+' failed; see '+str(log))


publish()
try:
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        for future in as_completed([pool.submit(run_group,group) for group in GROUPS]):
            future.result()
    publish(complete=True)
    if not all(sha(ROOT/name)==digest for name,digest in SOURCE_HASHES.items()):
        raise RuntimeError('Frozen inputs changed')
    print('P1_SCALAR_VALIDATION_PASS',len(RECORDS),flush=True)
except Exception as error:
    publish(complete=True)
    print('P1_SCALAR_VALIDATION_FAIL',repr(error),flush=True)
    raise
