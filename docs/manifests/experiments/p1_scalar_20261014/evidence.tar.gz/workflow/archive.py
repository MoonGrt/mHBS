from pathlib import Path
import difflib
import hashlib
import json
import shutil
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT/'build/pu_sign_matrix/20261014_143751'
RUN = ROOT/'build/pu_sign_matrix/20261014_155022'
OUT = ROOT/'docs/manifests/experiments/p1_scalar_20261014'
OUT.mkdir(parents=True,exist_ok=True)
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def dump(name,data):
    (OUT/name).write_text(json.dumps(data,indent=2)+'\n')

for source,name in ((BASE/'SOURCE.json','BASELINE_SOURCE.json'),(RUN/'SOURCE.json','SOURCE.json'),
                    (RUN/'status.json','MEASUREMENTS.json'),
                    (RUN/'source/validation/p1_scalar/VALIDATION.json','VALIDATION.json'),
                    (ROOT/'build/p1_scalar_20261014/STRUCTURE_REVIEW.json','STRUCTURE_REVIEW.json'),
                    (ROOT/'docs/report/P1_Scalar_20261014.json','COMPARISON.json')):
    shutil.copyfile(source,OUT/name)
metadata=json.loads((RUN/'SOURCE.json').read_text())
files=(RUN/'source/sources.txt').read_text().splitlines()
assert all(sha(RUN/'source'/name)==metadata['sha256'][name] for name in metadata['sha256'])
assert all(sha(ROOT/name)==metadata['sha256'][name] for name in files)
patch=[]
for name in sorted(set(files+['tb/tb_recipe.sv','tb/tb_statistics.sv','scripts/check_statistics.py','scripts/report_p1_scalar.py'])):
    a,b=BASE/'source'/name,RUN/'source'/name
    patch.extend(difflib.unified_diff(a.read_text().splitlines(True) if a.exists() else [],b.read_text().splitlines(True),
                                    fromfile='a/'+name if a.exists() else '/dev/null',tofile='b/'+name))
(OUT/'candidate.patch').write_text(''.join(patch))
checkpoints=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
             for p in sorted((RUN/'synth').glob('*/common/synthesized.dcp'))]
dump('CHECKPOINTS.json',checkpoints)
with tarfile.open(OUT/'evidence.tar.gz','w:gz') as tar:
    def add(p,name):tar.add(p,arcname=name,recursive=False)
    for run in (BASE,RUN):
        data=json.loads((run/'SOURCE.json').read_text())
        for name in data['sha256']:
            add(run/'source'/name,f'{run.name}/source/{name}')
        for name in ('SOURCE.json','status.json','runner.log'):
            add(run/name,f'{run.name}/{name}')
        for part in ('sim','synth','source/validation'):
            for p in sorted((run/part).rglob('*')):
                if p.is_file() and p.suffix in ('.log','.rpt','.json','.py','.txt') and 'obj' not in p.parts:
                    add(p,f'{run.name}/{p.relative_to(run)}')
    for p in sorted((ROOT/'build/p1_scalar_20261014').glob('*')):
        if p.is_file() and p.suffix in ('.py','.json','.jsonl'):
            add(p,f'workflow/{p.name}')
    for suffix in ('.md','.csv','.json','_Notes.md'):
        p=ROOT/'docs/report'/('P1_Scalar_20261014'+suffix)
        add(p,f'report_snapshot/{p.name}')
    for profile in ('xmss_h10','lms_h10'):
        for q in (1,1023):
            folder=ROOT/'build/pu_generic/20261013_201408/audit/extended'/f'{profile}_q{q}'
            for p in sorted(folder.rglob('*.mem')):
                add(p,f'boundary_vectors/{profile}_q{q}/{p.relative_to(folder)}')
(OUT/'README.md').write_text('''# P1 scalar execution evidence

Baseline `20261014_143751`; candidate `20261014_155022`.

P1 uses scalar recipes and a single iterative Keccak state. P>1 retains scheduled contexts inside recipe. The pipeline module stays deleted. Full Sign cycles and workload counters are measured anew; do not reuse the previous P1 cycles.

Area is common OOC on xc7a200tffg1156-3, Vivado 2025.2, generic Keccak, 6.666667 ns, default timing-driven synthesis, two threads. ATP uses assumed 150 MHz for U1 and 110 MHz for U2. No new routed STA. h20 full Keygen/Sign remain stopped.

Frozen RTL, vectors, validation, logs, reports, structure review and incremental patch are archived. DCP files remain at CHECKPOINTS.json paths with hashes. Any unfinished synthesis keeps running; this archive is a delivery snapshot.
''')
dump('SHA256.json',{p.name:sha(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='SHA256.json'})
print(OUT)
