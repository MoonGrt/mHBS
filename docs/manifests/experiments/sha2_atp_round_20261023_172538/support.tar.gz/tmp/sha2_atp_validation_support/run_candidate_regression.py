from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,json,subprocess,os,time,shutil
import argparse
parser=argparse.ArgumentParser(description="Run 29 SHA2 candidate regression groups against an isolated frozen source/test view")
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--work', type=Path, required=True)
parser.add_argument('--tests-root', type=Path, default=Path.cwd())
parser.add_argument('--plan', action='store_true')
parser.add_argument('--job', action='append', help='Repeat exact job names to restrict work')
parser.add_argument('--skip-job', action='append', default=[])
args=parser.parse_args()
source=args.source.resolve();WORK=args.work.resolve();OUT=WORK/'regression';ROOT=WORK/'isolated';OUT.mkdir(parents=True,exist_ok=True)
if not ROOT.exists():
    ROOT.mkdir()
    for name in ('scripts','model'):
        shutil.copytree(args.tests_root.resolve()/name,ROOT/name,ignore=shutil.ignore_patterns('__pycache__'))
    shutil.copytree(args.tests_root.resolve()/'tb',ROOT/'tb',ignore=shutil.ignore_patterns('vectors','__pycache__'))
    (ROOT/'tb/vectors').symlink_to(args.tests_root.resolve()/'tb/vectors',target_is_directory=True)
    for name in ('rtl','tb'):
        shutil.copytree(source/name,ROOT/name,dirs_exist_ok=True)
    shutil.copy2(source/'sources.txt',ROOT/'sources.txt')
identity={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ('rtl','scripts','model','tb') for p in (ROOT/d).rglob('*') if p.is_file() and not p.is_symlink() and '/vectors/' not in str(p) and '__pycache__' not in str(p)}
identity['sources.txt']=hashlib.sha256((ROOT/'sources.txt').read_bytes()).hexdigest()
(WORK/'ISOLATED_SOURCE.json').write_text(json.dumps(identity,indent=2)+'\n')
def check():
    assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==value for name,value in identity.items()),'isolated source/test drift' 
jobs=[]
for p,u in [(1,1),(4,1),(4,2),(12,1)]:
    jobs.append((f'recipe_P{p}U{u}',['python3','scripts/check_recipes.py','--hash','sha2','--pipeline',str(p),'--unroll',str(u)],'RECIPE_PASS cases=345'))
for p,u,s in [(1,1,0),(4,1,0),(4,1,1),(4,2,0),(12,1,0),(24,1,0),(12,2,0)]:
    jobs.append((f'cache_P{p}U{u}_s{s}',['python3','scripts/check_sha2_prefix_cache.py','--pipeline',str(p),'--unroll',str(u)]+(['--synthesis'] if s else []),'SHA2_PREFIX_CACHE_PASS'))
for p,u,s in [(4,1,0),(4,2,0),(12,1,0),(4,1,1)]:
    jobs.append((f'pipeline_P{p}U{u}_s{s}',['python3','scripts/check_pipeline.py','--hash','sha2','--pipeline',str(p),'--unroll',str(u)]+(['--synthesis'] if s else []),'PIPELINE_PASS'))
for s,store in [(0,0),(0,1),(1,0),(1,1)]:
    jobs.append((f'top_s{s}_store{store}',['python3','scripts/check_top_signature.py','--hash','sha2','--synthesis',str(s),'--signature',str(store)],'TOP_SIGNATURE_PASS'))
for profile in ['slh_128f','slh_128s','xmss_h10','lms_h10']:
    for op in ['keygen','verify']:
        jobs.append((f'{profile}_{op}',['bash','scripts/simulate_fast.sh',profile,op,'4','1'],'STATEFUL_PASS'))
for name,options in [('verify_replay',['+STALL=1','+REPLAYS=2','+INTERRUPT=1']),('verify_tamper',['+STALL=1','+TAMPER=1'])]:
    jobs.append((name,['bash','scripts/simulate.sh','slh_128f','verify','4','1',*options],'STATEFUL_PASS'))
if args.job:
    jobs=[job for job in jobs if job[0] in args.job]
    if len(jobs)!=len(args.job):raise ValueError('Unknown or duplicate --job')
jobs=[job for job in jobs if job[0] not in args.skip_job]
(WORK/'PLAN.json').write_text(json.dumps(dict(source=str(source),isolated=str(ROOT),jobs=[dict(name=n,command=c,marker=m) for n,c,m in jobs],synthesis=False,routing=False,h20=False),indent=2)+'\n')
if args.plan:raise SystemExit(0)
def run(job):
    name,command,marker=job;check();started=time.monotonic();folder=OUT/name;folder.mkdir(exist_ok=True)
    env=os.environ.copy();env.update(HASH_BACKEND='sha2',SIM_FAST_OPT_SLOW='-O1')
    with (folder/'run.log').open('w') as stream:
        code=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT).returncode
    content=(folder/'run.log').read_text();check()
    result=dict(name=name,command=command,returncode=code,passed=code==0 and marker in content,elapsed_seconds=time.monotonic()-started,markers=[line for line in content.splitlines() if '_PASS' in line])
    (folder/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);return result
results=[]
with ThreadPoolExecutor(max_workers=4) as pool:
    for result in pool.map(run,jobs):
        results.append(result)
        (OUT/'PROGRESS.json').write_text(json.dumps(dict(complete=False,completed=len(results),required=len(jobs),results=results),indent=2)+'\n')
check();summary=dict(complete=True,passed=all(row['passed'] for row in results),required=len(jobs),results=results)
summary['required']=len(summary['results']);(OUT/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');(OUT/'PROGRESS.json').write_text(json.dumps(summary,indent=2)+'\n');print('REGRESSION_COMPLETE',summary['passed'],summary['required'],flush=True)
if not summary['passed']:raise SystemExit(1)
