from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib,json,subprocess,os,re,time,traceback,shutil
ROOT=Path.cwd(); RUN=ROOT/'build/sha2_prefix_cache/20261023_152208'; OUT=RUN/'final_validation'
OUT.mkdir(exist_ok=True)
SOURCES=json.loads((RUN/'FINAL_SOURCE.json').read_text())['sha256']
def check_source():
    for path,expected in SOURCES.items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==expected,path
check_source()
def dump(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2)+'\n')
def run(ident,command,folder,marker='STATEFUL_PASS ',backend='sha2',extra=None,fast=False):
    check_source();before=time.monotonic();folder.mkdir(parents=True,exist_ok=True);logpath=folder/'run.log'
    env={**os.environ,'HASH_BACKEND':backend,'SIM_FAST_OPT_SLOW':'-O1','PYTHONUNBUFFERED':'1'}
    commands=[command]
    if fast:
        # Compile through the existing locked cache, then capture this run to
        # an independent file rather than racing another vector's canonical log.
        compile_env={**env,'SIM_COMPILE_ONLY':'1'}
        with (folder/'compile_driver.log').open('w') as log:
            compile_result=subprocess.run(command,cwd=ROOT,env=compile_env,stdout=log,stderr=subprocess.STDOUT)
        if compile_result.returncode:
            record=dict(name=ident,passed=False,command=command,log=str(folder/'compile_driver.log'),returncode=compile_result.returncode)
            dump(folder/'RESULT.json',record);return record
        p,u=command[-2:];profile,operation=command[2:4]
        suffix='_sha2' if backend=='sha2' else ''
        binary=ROOT/f'build/sim/P{p}U{u}_fast_o3_synthesis0_slow_O1{suffix}/obj/Vtb_fast'
        vectors=ROOT/'tb/vectors'
        if backend=='sha2':vectors=vectors/'sha2'
        command=[str(binary),f'+VECTOR={vectors/profile/operation}'];commands.append(command)
    with logpath.open('w') as log:result=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    output=logpath.read_text();passed=result.returncode==0 and marker in output
    record=dict(name=ident,passed=passed,commands=commands,log=str(logpath),elapsed_seconds=time.monotonic()-before,returncode=result.returncode,source_sha256=SOURCES)
    if extra:record.update(extra)
    m=re.search(r'cycles=(\d+).*?hashes=(\d+) permutations=(\d+)(?:.*?logical_permutations=(\d+))?',output)
    if m:
        record.update(cycles=int(m[1]),hashes=int(m[2]),compressions=int(m[3]))
        if m[4]:record['logical_compressions']=int(m[4])
    check_source();dump(folder/'RESULT.json',record);print(json.dumps(record),flush=True);return record
jobs=[]
# Start the long scalar XMSS immediately; cover each other architecture too.
focus_specs=[(p,u,profile) for profile in ['xmss_h10','lms_h10','slh_128f'] for p,u in [(1,1),(4,1),(4,2),(12,1)]]
for p,u,profile in focus_specs:
    folder=OUT/'focus'/f'P{p}U{u}'/profile
    jobs.append(('focus',lambda p=p,u=u,profile=profile,folder=folder:run(f'P{p}U{u}/{profile}/sign',['bash','scripts/simulate_fast.sh',profile,'sign',str(p),str(u)],folder,extra=dict(configuration=f'P{p}U{u}',profile=profile),fast=True)))
for backend,profile,op in [('sha2','slh_128s',x) for x in ['keygen','sign','verify']]+[('shake','slh_128f','sign')]:
    folder=OUT/'compatibility'/backend/profile/op
    jobs.append(('compat',lambda backend=backend,profile=profile,op=op,folder=folder:run(f'{backend}/{profile}/{op}',['bash','scripts/simulate_fast.sh',profile,op,'1','1'],folder,backend=backend,extra=dict(backend=backend,profile=profile,operation=op),fast=True)))
for synthesis,signature in [(0,0),(0,1),(1,0),(1,1)]:
    folder=OUT/'top'/f's{synthesis}_store{signature}'
    jobs.append(('top',lambda synthesis=synthesis,signature=signature,folder=folder:run(f'top/s{synthesis}/store{signature}',['python3','scripts/check_top_signature.py','--hash','sha2','--synthesis',str(synthesis),'--signature',str(signature)],folder,'TOP_SIGNATURE_PASS ',extra=dict(synthesis=synthesis,signature=signature))))
for p,u,synthesis in [(1,1,False),(4,1,False),(4,2,False),(12,1,False),(4,1,True)]:
    folder=OUT/'cache'/f'P{p}U{u}_synthesis{int(synthesis)}'
    command=['python3','scripts/check_sha2_prefix_cache.py','--pipeline',str(p),'--unroll',str(u)]+(['--synthesis'] if synthesis else [])
    jobs.append(('cache',lambda folder=folder,command=command,p=p,u=u,synthesis=synthesis:run(f'cache/P{p}U{u}/synthesis{int(synthesis)}',command,folder,'SHA2_PREFIX_CACHE_PASS ',extra=dict(configuration=f'P{p}U{u}',synthesis=synthesis))))
jobs.append(('recipe',lambda:run('recipe/P4U1',['python3','scripts/check_recipes.py','--hash','sha2','--pipeline','4','--unroll','1'],OUT/'recipe','RECIPE_PASS cases=345')))
jobs.append(('pipeline',lambda:run('pipeline/P4U1',['python3','scripts/check_pipeline.py','--hash','sha2','--pipeline','4','--unroll','1'],OUT/'pipeline','PIPELINE_PASS ')))
for name,options,required in [('replay',['+STALL=1','+REPLAYS=2','+INTERRUPT=1'],2),('tamper',['+STALL=1','+TAMPER=1'],1)]:
    folder=OUT/'verify'/name
    jobs.append(('verify',lambda name=name,options=options,required=required,folder=folder:run('verify/'+name,['bash','scripts/simulate.sh','slh_128f','verify','4','1',*options],folder,extra=dict(required_replays=required))))
results={key:[] for key in ['focus','compat','top','cache','recipe','pipeline','verify']}
with ThreadPoolExecutor(max_workers=5) as pool:
    futures={pool.submit(fn):kind for kind,fn in jobs}
    for future in as_completed(futures):
        kind=futures[future]
        try:record=future.result()
        except Exception as exc:record=dict(passed=False,error=str(exc),traceback=traceback.format_exc())
        results[kind].append(record)
        dump(OUT/'PROGRESS.json',dict(complete=False,results=results))
check_source()
# Preserve all global bench summaries before any later experiment reuses them.
for folder in ['P1U1','P4U1','P4U2','P12U1','P4U1_synthesis']:
    original=ROOT/'build/sha2_prefix_cache'/folder/'coverage.json'
    shutil.copy2(original,OUT/'cache'/f'{folder}_coverage.json')
for name,original in [('recipe',ROOT/'build/recipe_check/P4U1_sha2/coverage.json'),('pipeline',ROOT/'build/pipeline_check/sha2_P4U1/coverage.json')]:
    shutil.copy2(original,OUT/name/'coverage.json')
for kind,title,expected in [('focus','FOCUS_SIGN',12),('compat','COMPATIBILITY',4),('top','TOP_SIGNATURE',4),('cache','CACHE_BENCH',5),('recipe','RECIPE',1),('pipeline','PIPELINE',1),('verify','VERIFY_REPLAY',2)]:
    records=results[kind];passed=len(records)==expected and all(x.get('passed') for x in records)
    dump(OUT/(title+'_RESULTS.json'),dict(passed=passed,required=expected,results=records,source_sha256=SOURCES))
counts={kind:dict(passed=sum(x.get('passed',False) for x in records),required=len(records)) for kind,records in results.items()}
summary=dict(passed=all(x.get('passed') for records in results.values() for x in records),complete=True,counts=counts,source_sha256=SOURCES)
# Final all source assertion ties every row to this exact frozen design.
check_source();dump(OUT/'VALIDATION_SUMMARY.json',summary);dump(OUT/'PROGRESS.json',dict(**summary,results=results));print('FINAL_VALIDATION_COMPLETE',json.dumps(summary),flush=True)
