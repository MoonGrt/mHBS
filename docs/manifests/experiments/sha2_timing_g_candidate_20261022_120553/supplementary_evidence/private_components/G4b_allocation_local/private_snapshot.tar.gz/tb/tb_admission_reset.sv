`timescale 1ns/1ps
`default_nettype none
// All P contexts live, 2P requests, complete-bank hold, response stalls and reuse.
module tb_admission_reset #(parameter integer PIPELINE=12,UNROLL=1,
 localparam integer TAG_BITS=PIPELINE>1 ? $clog2(PIPELINE) : 1);
 logic clk=0;always #5 clk=~clk;
 logic rst=1,valid=0,ready_response=0;
 wire ready,response_valid;
 logic [TAG_BITS-1:0] tag=0,read_tag=0;
 logic [1:0] family;
 wire [TAG_BITS-1:0] response_tag;
 logic [4:0] steps=0,capture_after=0;
 logic no_seed=0,capture_enable=1,pair=0;
 logic [3:0] start=0,fixed_shape=0;
 logic [7:0] a=0,seed_domain=8'h83,step_domain=8'h83;
 logic [31:0] b=0;
 logic [255:0] initial_value=0,right_value=0,secret_seed,public_seed;
 logic [127:0] identifier;
 wire [5:0] node_bytes=
`ifdef MHBS_SHA2
  family_arg==0 ? 6'd16 :
`endif
  6'd32;
 wire [255:0] digest,capture,response_digest,response_capture;
 wire [63:0] hashes,permutations;
 recipe #(.N(32),.DIGEST_BYTES(49),.INDEX_BITS(8),.PIPELINE(PIPELINE),.UNROLL(UNROLL),.SHARED_STATE(1'b1)) dut(
  .clk,.rst,.batch_mode(1'b1),.batch_request_valid(valid),.batch_request_ready(ready),
  .batch_request_tag(tag),.batch_steps(steps),.batch_capture_after(capture_after),.batch_capture_enable(capture_enable),
  .batch_leaf(leaf),.batch_a(a),.batch_b(b),.batch_family(family),.batch_no_seed(no_seed),
  .batch_start(start),.batch_initial_value(initial_value),.batch_fixed_shape(fixed_shape),.batch_pair(pair),.batch_right(right_value),
  .batch_seed_domain(seed_domain),.batch_step_domain(step_domain),.batch_response_valid(response_valid),.batch_response_ready(ready_response),
  .batch_response_tag(response_tag),.batch_response_digest(response_digest),.batch_response_capture(response_capture),.batch_read_tag(read_tag),
  .batch_read_digest(digest),.batch_read_capture(capture),
`ifndef SYNTHESIS
  .batch_hashes(hashes),.batch_permutations(permutations),
`endif
  .node_bytes(node_bytes),.request_valid(1'b0),.request_ready(),.request_recipe(64'd0),.request_step_recipe(64'd0),
  .request_chain(1'b0),.request_steps(5'd0),.request_capture_after(5'd0),.request_capture(1'b0),
  .secret_seed,.secret_prf(256'd0),.public_seed,.root(256'd0),.randomizer(256'd0),.identifier,
  .message_buffer(696'd0),.message_length(7'd0),.request_layer(5'd3),.request_tree(64'h0123456789abcdef),
  .request_leaf(20'd0),.request_a(8'd0),.request_b(32'd0),.request_left(256'd0),.request_right(256'd0),
  .list_index0(),.list_index1(),.list_next_index0(),.list_data0(256'd0),.list_data1(256'd0),
  .response_valid(),.response_ready(1'b0),.response_value(),.response_capture(),.error()
`ifndef SYNTHESIS
  ,.hash_count(),.permutation_count()
`endif
 );
`ifdef SYNTHESIS
`ifdef MHBS_SHA2
 longint unsigned observed_hashes=0,observed_permutations=0;
 assign hashes=observed_hashes;
 assign permutations=observed_permutations;
 always @(posedge clk)begin
  if(rst)begin observed_hashes=0;observed_permutations=0;end
  else begin
   if(dut.hash_complete_event)observed_hashes++;
   if(dut.compression_complete_event)observed_permutations++;
  end
 end
`else
 longint unsigned observed_permutations=0;
 assign hashes=observed_permutations;
 assign permutations=observed_permutations;
 always @(posedge clk)begin
  if(rst)observed_permutations=0;
  else if(dut.batch_perm_done)observed_permutations++;
 end
`endif
`endif

 integer family_arg=0;
 logic [19:0] leaf=20'd1024;
 integer cycles=0,accepted_at,latency;
 logic [255:0] expected;
 always @(posedge clk)if(!rst)cycles++;
 task automatic tick;@(posedge clk);#1;endtask
 task automatic check_zero(input integer f,input integer s,input integer c,input integer en);
  begin
   @(negedge clk);
   family_arg=f;family=2'(f);start=4'(s);capture_after=5'(c);capture_enable=1'(en);
   steps=0;no_seed=1;tag=0;read_tag=0;pair=0;fixed_shape=0;
   initial_value=256'hffeeddccbbaa99887766554433221100_123456789abcdef00123456789abcdef;
   expected=f==0 ? {128'd0,initial_value[127:0]} : initial_value;
   valid=1;
   if(!ready)$fatal(1,"request not ready");
   tick();accepted_at=cycles;valid=0;
   while(!response_valid)tick();
   latency=cycles-accepted_at;
   if(response_digest!==expected || response_capture!==(en && s==c ? expected : 256'd0))
    $fatal(1,"zero-step capture family=%0d start=%0d cap=%0d en=%0d got=%h",f,s,c,en,response_capture);
   if(hashes || permutations)$fatal(1,"zero-step hashed");
   $display("CAPTURE_ZERO_PASS family=%0d start=%0d capture=%0d enable=%0d cycles=%0d",f,s,c,en,latency);
   repeat(4)begin tick();if(!response_valid || response_capture!==(en && s==c ? expected : 256'd0))$fatal(1,"capture hold");end
   ready_response=1;tick();ready_response=0;tick();
  end
 endtask
 task automatic cancel_admission;
  begin
   @(negedge clk);family_arg=2;family=2;start=7;capture_after=7;capture_enable=1;
   steps=0;no_seed=1;tag=0;read_tag=0;pair=0;fixed_shape=0;
   initial_value=256'h123456789abcdef;valid=1;
   if(!ready)$fatal(1,"pending-reset request not ready");
   tick();valid=0;
   if(!dut.ingress_pending || !dut.busy_slot[0] || response_valid || ready)
    $fatal(1,"admission did not reserve tag or blocked readiness");
   rst=1;tick();rst=0;
   repeat(4)begin tick();if(dut.ingress_pending || dut.busy_slot || response_valid || hashes || permutations)
    $fatal(1,"reset pending admission produced stale work/response");end
   $display("ADMISSION_RESET_PASS reserved_tag=0 stale_responses=0 stale_hashes=0");
  end
 endtask
 initial begin
  secret_seed=0;public_seed=0;identifier=0;
  tick();tick();rst=0;tick();
  cancel_admission();
  for(integer f=0;f<3;f++)begin
   check_zero(f,0,0,1);check_zero(f,7,7,1);check_zero(f,15,15,1);
   check_zero(f,7,8,1);check_zero(f,7,7,0);
  end
  $display("ALL_CAPTURE_ZERO_PASS cases=15");$finish;
 end
endmodule
`default_nettype wire
