`timescale 1ns/1ps
`default_nettype none
// All P contexts live, 2P requests, complete-bank hold, response stalls and reuse.
module tb_generic_mgf #(parameter integer PIPELINE=12,UNROLL=1,
 localparam integer TAG_BITS=PIPELINE>1 ? $clog2(PIPELINE) : 1);
 logic clk=0;always #5 clk=~clk;
 logic rst=1,valid=0,ready_response=0;
 wire ready,response_valid;
 logic [TAG_BITS-1:0] tag=0,read_tag=0;
 logic [1:0] family;
 wire [TAG_BITS-1:0] response_tag;
 logic [4:0] steps=0,capture_after=0;
 logic no_seed=0,capture_enable=1,pair=0;
 logic [3:0] start=0,fixed_shape=0;
 logic [7:0] a=0,seed_domain=8'h83,step_domain=8'h83;
 logic [31:0] b=0;
 logic [255:0] initial_value=0,right_value=0,secret_seed,public_seed;
 logic [127:0] identifier;
 wire [5:0] node_bytes=
`ifdef MHBS_SHA2
  family_arg==0 ? 6'd16 :
`endif
  6'd32;
 wire [255:0] digest,capture,response_digest,response_capture;
 wire [63:0] hashes,permutations;
 recipe #(.N(32),.DIGEST_BYTES(49),.INDEX_BITS(8),.PIPELINE(PIPELINE),.UNROLL(UNROLL),.SHARED_STATE(1'b1)) dut(
  .clk,.rst,.batch_mode(batch_mode),.batch_request_valid(valid),.batch_request_ready(ready),
  .batch_request_tag(tag),.batch_steps(steps),.batch_capture_after(capture_after),.batch_capture_enable(capture_enable),
  .batch_leaf(leaf),.batch_a(a),.batch_b(b),.batch_family(family),.batch_no_seed(no_seed),
  .batch_start(start),.batch_initial_value(initial_value),.batch_fixed_shape(fixed_shape),.batch_pair(pair),.batch_right(right_value),
  .batch_seed_domain(seed_domain),.batch_step_domain(step_domain),.batch_response_valid(response_valid),.batch_response_ready(ready_response),
  .batch_response_tag(response_tag),.batch_response_digest(response_digest),.batch_response_capture(response_capture),.batch_read_tag(read_tag),
  .batch_read_digest(digest),.batch_read_capture(capture),
`ifndef SYNTHESIS
  .batch_hashes(),.batch_permutations(),
`endif
  .node_bytes(node_bytes),.request_valid(scalar_valid),.request_ready(scalar_ready),.request_recipe(scalar_recipe),.request_step_recipe(64'd0),
  .request_chain(1'b0),.request_steps(5'd0),.request_capture_after(5'd0),.request_capture(1'b0),
  .secret_seed,.secret_prf(256'd0),.public_seed,.root(256'd0),.randomizer(256'd0),.identifier,
  .message_buffer(696'd0),.message_length(7'd17),.request_layer(5'd3),.request_tree(64'h0123456789abcdef),
  .request_leaf(20'd0),.request_a(8'd0),.request_b(32'd0),.request_left(256'd0),.request_right(256'd0),
  .list_index0(),.list_index1(),.list_next_index0(),.list_data0(256'd0),.list_data1(256'd0),
  .response_valid(scalar_response_valid),.response_ready(scalar_response_ready),.response_value(scalar_value),.response_capture(),.error()
`ifndef SYNTHESIS
  ,.hash_count(),.permutation_count()
`endif
 );

 integer family_arg=0;
 logic [19:0] leaf=20'd1024;
 logic batch_mode=0,scalar_valid=0,scalar_response_ready=0;
 logic [63:0] scalar_recipe=0;
 wire scalar_ready,scalar_response_valid;
 wire [391:0] scalar_value;
 longint unsigned measured_hashes=0,measured_compressions=0;
 assign hashes=measured_hashes;
 assign permutations=measured_compressions;
 always @(posedge clk)begin
  if(rst)begin measured_hashes=0;measured_compressions=0;end
  else begin
   if(dut.hash_complete_event)measured_hashes++;
   if(dut.compression_complete_event)measured_compressions++;
  end
 end
 task automatic tick;@(posedge clk);#1;endtask
 integer timeout=0;
 initial begin
  family=0;secret_seed=0;identifier=0;
  for(integer k=0;k<32;k++)public_seed[k*8+:8]=8'(k+65);
  tick();tick();rst=0;tick();
  scalar_recipe[59:56]=4;scalar_recipe[47:40]=1;scalar_recipe[37:32]=49;
  @(negedge clk);scalar_valid=1;
  if(!scalar_ready)$fatal(1,"scalar ready");
  tick();scalar_valid=0;timeout=0;
  while(!scalar_response_valid)begin tick();timeout++;if(timeout>10000)$fatal(1,"scalar MGF timeout");end
  if(scalar_value!==392'h634d89be36864982ff2508099f5c79f6b736013407533e76773289685dc19188482e52d9eb493144df7872cd3c58556ae4)$fatal(1,"49-byte MGF1 low preservation got=%h",scalar_value);
  if(hashes!=3 || permutations!=6)$fatal(1,"49-byte MGF counts %0d/%0d",hashes,permutations);
  repeat(4)begin tick();if(scalar_value!==392'h634d89be36864982ff2508099f5c79f6b736013407533e76773289685dc19188482e52d9eb493144df7872cd3c58556ae4)$fatal(1,"MGF hold");end
  scalar_response_ready=1;tick();scalar_response_ready=0;tick();
  batch_mode=1;tag=TAG_BITS'(PIPELINE-1);read_tag=tag;fixed_shape=4;
  no_seed=1;capture_enable=0;steps=0;start=0;initial_value=0;pair=0;
  @(negedge clk);valid=1;if(!ready)$fatal(1,"batch ready");tick();valid=0;timeout=0;
  while(!response_valid)begin tick();timeout++;if(timeout>10000)$fatal(1,"batch MGF timeout");end
  if(response_tag!=TAG_BITS'(PIPELINE-1) || response_digest!==256'h36013407533e76773289685dc19188482e52d9eb493144df7872cd3c58556ae4 || response_capture!==0)
   $fatal(1,"generic nonzero-tag MGF batch result");
  if(scalar_value!==392'h0000000000000000000000000000000000000000000000000000000000000000002e52d9eb493144df7872cd3c58556ae4)$fatal(1,"nonzero batch MGF0 failed globalclear/lowwrite got=%h",scalar_value);
  if(hashes!=5 || permutations!=10)$fatal(1,"batch MGF counts %0d/%0d",hashes,permutations);
  repeat(4)begin tick();if(scalar_value!==392'h0000000000000000000000000000000000000000000000000000000000000000002e52d9eb493144df7872cd3c58556ae4)$fatal(1,"batch MGF scalar buffer hold");end
  $display("GENERIC_MGF_PASS scalar_output=49 batch_tag=%0d batch_output=16 hashes=%0d compressions=%0d",PIPELINE-1,hashes,permutations);
  $finish;
 end
endmodule
`default_nettype wire
