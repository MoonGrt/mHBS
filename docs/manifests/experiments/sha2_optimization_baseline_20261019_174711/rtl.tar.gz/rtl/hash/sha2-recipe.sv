`ifdef MHBS_SHA2
`timescale 1ns / 1ps
`default_nettype none
// SHA2 recipe execution: one compression lane, P independent contexts.
// Byte-vector ports use byte zero in the least significant bits.
// verilog_format: off
module recipe #(
    parameter integer N = 32,
    parameter integer DIGEST_BYTES = N==16 ? 34 : 32, INDEX_BITS = 7,
    parameter integer UNROLL = 2, PIPELINE = 1,
    parameter integer MAX_MESSAGE_BYTES = 87,
    parameter [15:0] RECIPE_MASK = 16'hffff,
    parameter bit SHARED_STATE=0,
    localparam integer TAG_BITS=PIPELINE>1 ? $clog2(PIPELINE) : 1
) (
`ifndef SYNTHESIS
    output wire [63:0] batch_hashes,batch_permutations,
    output logic [63:0] hash_count,permutation_count,
`endif
    input wire clk, rst, output logic error,
    input wire batch_mode,batch_request_valid, output wire batch_request_ready,
    input wire [TAG_BITS-1:0] batch_request_tag,
    input wire [4:0] batch_steps, batch_capture_after, input wire batch_capture_enable,
    input wire [19:0] batch_leaf, input wire [7:0] batch_a, input wire [31:0] batch_b,
    input wire [1:0] batch_family, input wire batch_no_seed,
    input wire [3:0] batch_start, input wire [255:0] batch_initial_value,
    input wire [3:0] batch_fixed_shape, input wire batch_pair, input wire [255:0] batch_right,
    input wire [7:0] batch_seed_domain, batch_step_domain,
    output wire batch_response_valid, input wire batch_response_ready,
    output wire [TAG_BITS-1:0] batch_response_tag,
    output wire [255:0] batch_response_digest, batch_response_capture,
    input wire [TAG_BITS-1:0] batch_read_tag,
    output wire [255:0] batch_read_digest,batch_read_capture,
    input wire [5:0] node_bytes, input wire [127:0] identifier,
    input wire request_valid, output wire request_ready,
    input wire [63:0] request_recipe, request_step_recipe, input wire request_chain,
    input wire [4:0] request_steps, request_capture_after, input wire request_capture,
    input wire [N*8-1:0] secret_seed, secret_prf, public_seed, root, randomizer,
    input wire [MAX_MESSAGE_BYTES*8-1:0] message_buffer, input wire [6:0] message_length,
    input wire [4:0] request_layer, input wire [63:0] request_tree, input wire [19:0] request_leaf,
    input wire [INDEX_BITS-1:0] request_a, input wire [31:0] request_b,
    input wire [N*8-1:0] request_left, request_right,
    output wire [INDEX_BITS-1:0] list_index0, list_index1, list_next_index0,
    input wire [N*8-1:0] list_data0, list_data1,
    output wire response_valid, input wire response_ready,
    output wire [DIGEST_BYTES*8-1:0] response_value, output wire [N*8-1:0] response_capture
);
// verilog_format: on
    localparam [255:0] IV = 256'h6a09e667bb67ae853c6ef372a54ff53a510e527f9b05688c1f83d9ab5be0cd19;
    typedef enum logic [3:0] { DIRECT, SEED, KEY, MASK0, MASK1, FINAL,
        HMAC_IN, HMAC_OUT, HMSG_IN, MGF0, MGF1 } phase_t;
    typedef enum logic [1:0] { SELECT, PREFETCH, BUILD, SEND } formatter_t;

    // Only requests own contexts; completed results stay live until consumed.
    // P=1 reduces these banks and selectors to a single scalar execution slot.
    logic [PIPELINE-1:0] busy_slot, complete, need_block, scalar_slot, capture_enable, paired;
    phase_t phase[0:PIPELINE-1];
    logic [3:0] shape[0:PIPELINE-1];
    logic [1:0] family[0:PIPELINE-1];
    logic [19:0] leaf[0:PIPELINE-1];
    logic [7:0] address_a[0:PIPELINE-1], seed_domain[0:PIPELINE-1], step_domain[0:PIPELINE-1];
    logic [31:0] address_b[0:PIPELINE-1];
    logic [4:0] iteration[0:PIPELINE-1], end_step[0:PIPELINE-1], capture_step[0:PIPELINE-1];
    logic [7:0] arity[0:PIPELINE-1];
    logic [5:0] output_bytes[0:PIPELINE-1];
    logic [12:0] block_offset[0:PIPELINE-1];
    logic [255:0] cv[0:PIPELINE-1], digest[0:PIPELINE-1], key_value[0:PIPELINE-1], captured[0:PIPELINE-1];
    logic [DIGEST_BYTES*8-1:0] scalar_result;

    function automatic [255:0] reverse_bytes(input [255:0] data);
        for (integer k=0;k<32;k=k+1) reverse_bytes[k*8+:8]=data[255-k*8-:8];
    endfunction
    function automatic [7:0] be_byte(input [31:0] number,input integer offset);
        be_byte = 8'(number >> (24-offset*8));
    endfunction
    function automatic [7:0] node_byte(input [255:0] data,input integer offset);
        node_byte = offset>=0 && offset<32 ? data[offset*8+:8] : 8'd0;
    endfunction
    function automatic [255:0] node_result(input [255:0] data,input [1:0] f);
        node_result = f==0 ? {128'd0,data[127:0]} : data;
    endfunction
    function automatic [12:0] input_length(input integer t);
        begin
            case (phase[t])
                KEY,MASK0,MASK1: input_length=96;
                FINAL: input_length=paired[t] ? 128 : 96;
                HMAC_IN: input_length=13'd80+13'(message_length);
                HMAC_OUT: input_length=96;
                HMSG_IN: input_length=13'd48+13'(message_length);
                MGF0,MGF1: input_length=68;
                default: begin
                    if (shape[t]==0 || phase[t]==SEED) begin
                        case(family[t])
                            0: input_length=102;
                            1: input_length=128;
                            default: input_length=55;
                        endcase
                    end else case(shape[t])
                        1: input_length=102;
                        2: input_length=paired[t] ? 118 : 102;
                        5: input_length=96;
                        6: input_length=13'd128+13'(message_length);
                        7: input_length=128;
                        9,10: input_length=55;
                        11: input_length=13'd54+13'(message_length);
                        12: input_length=13'd86+{1'b0,arity[t],4'd0};
                        13: input_length=13'd22+{arity[t],5'd0};
                        14: input_length=54;
                        15: input_length=86;
                        default: input_length=0;
                    endcase
                end
            endcase
        end
    endfunction
    function automatic [12:0] padded_length(input integer t);
        padded_length=(input_length(t)+13'd72)&13'h1fc0;
    endfunction
    function automatic [31:0] effective_b(input integer t);
        effective_b = shape[t]==0 && phase[t]!=SEED && step_domain[t]!=3 ?
            {27'd0,iteration[t]} : address_b[t];
    endfunction
    function automatic [7:0] domain(input integer t);
        domain = phase[t]==SEED || shape[t]==1 || shape[t]==7 || shape[t]==9 ? seed_domain[t] : step_domain[t];
    endfunction
    function automatic [7:0] compressed_address(input integer t,input integer p);
        begin
            compressed_address=0;
            if(p==0) compressed_address={3'd0,request_layer};
            else if(p<9) compressed_address=8'(request_tree >> ((8-p)*8));
            else if(p==9) compressed_address=domain(t);
            else if(p<14) compressed_address=be_byte({12'd0,leaf[t]},p-10);
            else if(p<18) compressed_address=be_byte({24'd0,address_a[t]},p-14);
            else if(p<22) compressed_address=be_byte(effective_b(t),p-18);
        end
    endfunction
    function automatic [7:0] masked_address(input integer t,input integer p);
        reg [31:0] compound;
        begin
            compound=phase[t]==MASK0 ? 1 : phase[t]==MASK1 ? 2 : 0;
            masked_address=0;
            if(p>=12 && p<16) masked_address=be_byte({24'd0,domain(t)},p-12);
            else if(p>=16 && p<20) masked_address=be_byte({12'd0,leaf[t]},p-16);
            else if(p>=20 && p<24) masked_address=be_byte({24'd0,address_a[t]},p-20);
            else if(p>=24 && p<28) masked_address=be_byte(effective_b(t),p-24);
            else if(p>=28) masked_address=be_byte(compound,p-28);
        end
    endfunction

    formatter_t formatter;
    logic [TAG_BITS-1:0] format_tag;
    logic [1:0] beat;
    logic [511:0] block_buffer;
    wire [12:0] position=block_offset[format_tag]+{7'd0,beat,4'd0};
    wire [12:0] list_prefix=shape[format_tag]==12 ? 13'd86 : 13'd22;
    wire is_list=shape[format_tag]==12 || shape[format_tag]==13;
    function automatic [INDEX_BITS-1:0] list_address(input [12:0] pos);
        reg [12:0] delta;
        begin
            delta=pos>list_prefix ? pos-list_prefix : 13'd0;
            list_address=shape[format_tag]==12 ? INDEX_BITS'(delta>>4) : INDEX_BITS'(delta>>5);
        end
    endfunction
    assign list_index0=is_list ? list_address(position) : 0;
    assign list_index1=list_index0+1'b1;
    // Executor registers this address before the following 128-bit beat. The
    // PREFETCH cycle also handles the discontinuity between two SHA blocks.
    assign list_next_index0=is_list ? list_address(formatter==BUILD && beat!=3 ? position+13'd16 : position) : 0;

    function automatic [7:0] payload_byte(input integer t,input integer p);
        integer q, index;
        reg [3:0] active_shape;
        reg [7:0] value, pad;
        begin
            value=0;
            active_shape=shape[t];
            if(active_shape==0) begin
                if(family[t]==0) active_shape=phase[t]==SEED ? 1 : 2;
                else if(family[t]==1) active_shape=7;
                else active_shape=phase[t]==SEED ? 9 : 10;
            end
            case(phase[t])
                KEY,MASK0,MASK1: begin
                    if(p==31) value=3;
                    else if(p>=32 && p<64) value=node_byte(public_seed,p-32);
                    else if(p>=64) value=masked_address(t,p-64);
                end
                FINAL: begin
                    if(p==31) value={7'd0,paired[t]};
                    else if(p>=32 && p<64) value=node_byte(key_value[t],p-32);
                    else if(p>=64 && p<96) value=node_byte(digest[t],p-64);
                    else if(p>=96) value=node_byte(captured[t],p-96);
                end
                HMAC_IN,HMAC_OUT: begin
                    pad=phase[t]==HMAC_IN ? 8'h36 : 8'h5c;
                    if(p<64) value=(p<16 ? node_byte(secret_prf,p) : 8'd0)^pad;
                    else if(phase[t]==HMAC_OUT) value=node_byte(digest[t],p-64);
                    else if(p<80) value=node_byte(randomizer,p-64);
                    else if(p-80<MAX_MESSAGE_BYTES) value=message_buffer[(p-80)*8+:8];
                end
                HMSG_IN: begin
                    if(p<16) value=node_byte(randomizer,p);
                    else if(p<32) value=node_byte(public_seed,p-16);
                    else if(p<48) value=node_byte(root,p-32);
                    else if(p-48<MAX_MESSAGE_BYTES) value=message_buffer[(p-48)*8+:8];
                end
                MGF0,MGF1: begin
                    if(p<16) value=node_byte(randomizer,p);
                    else if(p<32) value=node_byte(public_seed,p-16);
                    else if(p<64) value=node_byte(key_value[t],p-32);
                    else if(p==67) value=phase[t]==MGF1 ? 1 : 0;
                end
                default: case(active_shape)
                    1,2,12: begin
                        if(p<16) value=node_byte(public_seed,p);
                        else if(p>=64 && p<86) value=compressed_address(t,p-64);
                        else if(p>=86) begin
                            q=p-86;
                            if(active_shape==1) value=node_byte(secret_seed,q);
                            else if(active_shape==2) value=q<16 ? node_byte(digest[t],q) : node_byte(captured[t],q-16);
                            else begin
                                index=q-int'(list_index0)*16;
                                value=index<16 ? node_byte(list_data0,index) : node_byte(list_data1,index-16);
                            end
                        end
                    end
                    5: begin
                        if(p==31) value=3;
                        else if(p>=32 && p<64) value=node_byte(secret_prf,p-32);
                        else if(p>=92) value=be_byte({12'd0,leaf[t]},p-92);
                    end
                    6: begin
                        if(p==31) value=2;
                        else if(p>=32 && p<64) value=node_byte(randomizer,p-32);
                        else if(p>=64 && p<96) value=node_byte(root,p-64);
                        else if(p>=124 && p<128) value=be_byte({12'd0,leaf[t]},p-124);
                        else if(p>=128 && p-128<MAX_MESSAGE_BYTES) value=message_buffer[(p-128)*8+:8];
                    end
                    7: begin
                        if(p==31) value=4;
                        else if(p>=32 && p<64) value=node_byte(secret_seed,p-32);
                        else if(p>=64 && p<96) value=node_byte(public_seed,p-64);
                        else if(p>=96) value=masked_address(t,p-96);
                    end
                    9,10,11,13,14,15: begin
                        if(p<16) value=node_byte({128'd0,identifier},p);
                        else if(p<20) value=be_byte(active_shape>=14 ? address_b[t] : {12'd0,leaf[t]},p-16);
                        else if(active_shape==9 || active_shape==10) begin
                            if(p==20) value=0;
                            else if(p==21) value=address_a[t];
                            else if(p==22) value=active_shape==9 ? 8'hff :
                                shape[t]==0 ? {3'd0,iteration[t]} : address_b[t][7:0];
                            else value=active_shape==9 ? node_byte(secret_seed,p-23) : node_byte(digest[t],p-23);
                        end else begin
                            if(p==20 || p==21) value=active_shape==11 ? 8'h81 :
                                active_shape==13 ? 8'h80 : active_shape==14 ? 8'h82 : 8'h83;
                            else if(active_shape==11) begin
                                if(p<54) value=node_byte(randomizer,p-22);
                                else if(p-54<MAX_MESSAGE_BYTES) value=message_buffer[(p-54)*8+:8];
                            end else if(active_shape==13) begin
                                index=p-22-int'(list_index0)*32;
                                value=index<32 ? node_byte(list_data0,index) : node_byte(list_data1,index-32);
                            end else value=p<54 ? node_byte(digest[t],p-22) : node_byte(captured[t],p-54);
                        end
                    end
                    default: value=0;
                endcase
            endcase
            payload_byte=value;
        end
    endfunction
    logic [127:0] formatted_beat;
    integer absolute_byte;
    logic [63:0] bit_length;
    always_comb begin
        formatted_beat=0;
        bit_length=64'(input_length(int'(format_tag)))<<3;
        absolute_byte=0;
        for(integer k=0;k<16;k=k+1) begin
            absolute_byte=int'(position)+k;
            if(absolute_byte<int'(input_length(int'(format_tag))))
                formatted_beat[127-k*8-:8]=payload_byte(int'(format_tag),absolute_byte);
            else if(absolute_byte==int'(input_length(int'(format_tag))))
                formatted_beat[127-k*8-:8]=8'h80;
            else if(absolute_byte>=int'(padded_length(int'(format_tag)))-8)
                formatted_beat[127-k*8-:8]=8'(bit_length>>((int'(padded_length(int'(format_tag)))-1-absolute_byte)*8));
        end
    end

    logic candidate_valid;
    logic [TAG_BITS-1:0] candidate;
    logic [TAG_BITS-1:0] schedule_cursor;
    integer scan;
    always_comb begin
        candidate_valid=0; candidate=0; scan=0;
        for(integer k=0;k<PIPELINE;k=k+1) begin
            scan=int'(schedule_cursor)+k;
            if(scan>=PIPELINE) scan=scan-PIPELINE;
            if(!candidate_valid && need_block[scan]) begin candidate_valid=1; candidate=TAG_BITS'(scan); end
        end
    end
    wire compression_ready, compression_valid;
    wire [255:0] compression_cv;
    wire [TAG_BITS-1:0] compression_tag;
    sha256 #(.PIPELINE(PIPELINE),.UNROLL(UNROLL),.TAG_BITS(TAG_BITS)) compression (
        .clk,.rst,.input_valid(formatter==SEND),.input_ready(compression_ready),
        .input_cv(cv[format_tag]),.input_block(block_buffer),.input_tag(format_tag),
        .output_valid(compression_valid),.output_ready(1'b1),.output_cv(compression_cv),.output_tag(compression_tag)
    );
    wire compression_complete_event=compression_valid && !rst;
    wire hash_complete_event=compression_complete_event && block_offset[compression_tag]+13'd64==padded_length(int'(compression_tag));
    wire [255:0] returned=reverse_bytes(compression_cv);

    logic response_held;
    logic [TAG_BITS-1:0] held_tag, completed_tag;
    logic completed_valid;
    always_comb begin
        completed_tag=0; completed_valid=0;
        for(integer k=0;k<PIPELINE;k=k+1)
            if(!completed_valid && complete[k] && !scalar_slot[k] && (!response_held || held_tag!=TAG_BITS'(k))) begin
                completed_valid=1; completed_tag=TAG_BITS'(k);
            end
    end
    assign batch_response_valid=response_held;
    assign batch_response_tag=held_tag;
    assign batch_response_digest=digest[held_tag];
    assign batch_response_capture=captured[held_tag];
    assign batch_read_digest=digest[batch_read_tag];
    assign batch_read_capture=captured[batch_read_tag];
    assign response_valid=complete[0] && scalar_slot[0];
    assign response_value=scalar_result;
    assign response_capture=captured[0][N*8-1:0];
    assign request_ready=!rst && !batch_mode && busy_slot==0;
    assign batch_request_ready=!rst && batch_mode && int'(batch_request_tag)<PIPELINE &&
        (!busy_slot[batch_request_tag] || (batch_response_valid && batch_response_ready && held_tag==batch_request_tag));
    wire scalar_accept=request_valid && request_ready;
    wire batch_accept=batch_request_valid && batch_request_ready;
    wire accept=scalar_accept || batch_accept;
    wire [TAG_BITS-1:0] incoming_tag=scalar_accept ? TAG_BITS'(0) : batch_request_tag;
    wire [3:0] incoming_shape=scalar_accept ? (request_chain ? 4'd0 : request_recipe[59:56]) : batch_fixed_shape;
    wire [3:0] scalar_shape=request_recipe[59:56];
    wire [1:0] incoming_family=scalar_accept ?
        ((scalar_shape<=4 || scalar_shape==12) ? 2'd0 :
         (scalar_shape==5 || scalar_shape==6 || scalar_shape==7 || scalar_shape==8) ? 2'd1 : 2'd2) : batch_family;
    wire incoming_no_seed=scalar_accept ?
        !(request_chain && (scalar_shape==1 || scalar_shape==7 || scalar_shape==9)) : batch_no_seed;
    wire [4:0] incoming_start=scalar_accept ? 5'd0 : {1'b0,batch_start};
    wire [4:0] incoming_steps=scalar_accept ? (request_chain ? request_steps : 5'd0) : batch_steps;
    wire [4:0] incoming_capture_step=scalar_accept ? request_capture_after : batch_capture_after;
    wire incoming_capture=scalar_accept ? request_capture : batch_capture_enable;
    wire [255:0] incoming_value=scalar_accept ? 256'(request_left) : batch_initial_value;
    wire incoming_pair=scalar_accept ? request_recipe[47:40]==2 : batch_pair;
    function automatic phase_t initial_phase(input [3:0] s,input [1:0] f,input no_seed);
        case(s)
            0: initial_phase=!no_seed ? SEED : f==1 ? KEY : DIRECT;
            3: initial_phase=HMAC_IN;
            4: initial_phase=HMSG_IN;
            8: initial_phase=KEY;
            default: initial_phase=DIRECT;
        endcase
    endfunction

    // A full SHA256 call starts from IV. Intermediate compression returns only
    // update CV/offset; only a full call can change a recipe or chain phase.
    task automatic next_hash(input integer t,input phase_t next_phase);
        begin phase[t]<=next_phase; cv[t]<=IV; block_offset[t]<=0; need_block[t]<=1; end
    endtask
    task automatic finish_node(input integer t,input [255:0] value);
        reg [255:0] node;
        reg [4:0] reached;
        begin
            node=node_result(value,family[t]);
            reached=phase[t]==SEED ? 5'd0 : iteration[t]+1'b1;
            digest[t]<=node;
            if(capture_enable[t] && capture_step[t]==(shape[t]==7 ? 5'd0 : reached)) captured[t]<=node;
            if(shape[t]==0 && reached<end_step[t]) begin
                iteration[t]<=reached;
                next_hash(t,family[t]==1 ? KEY : DIRECT);
            end else begin
                complete[t]<=1;
                if(scalar_slot[t]) begin
                    scalar_result<=0;
                    for(integer k=0;k<DIGEST_BYTES;k=k+1)
                        if(k<32 && k<int'(output_bytes[t])) scalar_result[k*8+:8]<=value[k*8+:8];
                end
            end
        end
    endtask
    always_ff @(posedge clk) begin : execution
        integer t;
        if(rst) begin
            busy_slot<=0; complete<=0; need_block<=0; scalar_slot<=0;
            capture_enable<=0; paired<=0; formatter<=SELECT; format_tag<=0; beat<=0;
            response_held<=0; held_tag<=0; schedule_cursor<=0; error<=0;
            scalar_result<=0;
            for(integer k=0;k<PIPELINE;k=k+1) begin
                phase[k]<=DIRECT; shape[k]<=0; family[k]<=0; block_offset[k]<=0;
                arity[k]<=0; output_bytes[k]<=0;
            end
        end else begin
            // Match the common executor's idle-tag contract: after draining a
            // batch, tag zero selects the first retained signature capture.
            if(!response_held || batch_response_ready) begin
                response_held<=completed_valid; held_tag<=completed_tag;
            end
            if(batch_response_valid && batch_response_ready) begin
                complete[held_tag]<=0; busy_slot[held_tag]<=0;
            end
            if(response_valid && response_ready) begin complete[0]<=0; busy_slot[0]<=0; end
            case(formatter)
                SELECT: if(candidate_valid) begin
                    format_tag<=candidate; need_block[candidate]<=0; beat<=0; formatter<=PREFETCH;
                    schedule_cursor<=int'(candidate)==PIPELINE-1 ? TAG_BITS'(0) : candidate+1'b1;
                end
                PREFETCH: formatter<=BUILD;
                BUILD: begin
                    block_buffer[511-int'(beat)*128-:128]<=formatted_beat;
                    if(beat==3) formatter<=SEND;
                    else beat<=beat+1'b1;
                end
                SEND: if(compression_ready) formatter<=SELECT;
            endcase
            if(compression_complete_event) begin
                t=int'(compression_tag);
                if(!hash_complete_event) begin
                    cv[t]<=compression_cv; block_offset[t]<=block_offset[t]+13'd64; need_block[t]<=1;
                end else case(phase[t])
                    KEY: begin key_value[t]<=returned; next_hash(t,MASK0); end
                    MASK0: begin digest[t]<=digest[t]^returned; next_hash(t,paired[t] ? MASK1 : FINAL); end
                    MASK1: begin captured[t]<=captured[t]^returned; next_hash(t,FINAL); end
                    HMAC_IN: begin digest[t]<=returned; next_hash(t,HMAC_OUT); end
                    HMSG_IN: begin key_value[t]<=returned; next_hash(t,MGF0); end
                    MGF0: begin
                        scalar_result<=0;
                        for(integer k=0;k<DIGEST_BYTES;k=k+1)
                            if(k<32 && k<int'(output_bytes[t])) scalar_result[k*8+:8]<=returned[k*8+:8];
                        if(output_bytes[t]>32) next_hash(t,MGF1);
                        else begin digest[t]<=returned; complete[t]<=1; end
                    end
                    MGF1: begin
                        for(integer k=32;k<DIGEST_BYTES;k=k+1)
                            if(k<int'(output_bytes[t])) scalar_result[k*8+:8]<=returned[(k-32)*8+:8];
                        complete[t]<=1;
                    end
                    default: finish_node(t,returned);
                endcase
            end
            // Allocation is last so a retiring tag can be refilled on this edge.
            if(accept) begin
                t=int'(incoming_tag);
                busy_slot[t]<=1; complete[t]<=0; need_block[t]<=1; scalar_slot[t]<=scalar_accept;
                shape[t]<=incoming_shape; family[t]<=incoming_family; paired[t]<=incoming_pair;
                phase[t]<=initial_phase(incoming_shape,incoming_family,incoming_no_seed);
                cv[t]<=IV; block_offset[t]<=0; digest[t]<=node_result(incoming_value,incoming_family);
                captured[t]<=incoming_pair ? (scalar_accept ? 256'(request_right) : batch_right) : 256'd0;
                leaf[t]<=scalar_accept ? request_leaf : batch_leaf;
                address_a[t]<=scalar_accept ? 8'(request_a) : batch_a;
                address_b[t]<=scalar_accept ? request_b : batch_b;
                seed_domain[t]<=scalar_accept ? request_recipe[55:48] : batch_seed_domain;
                step_domain[t]<=scalar_accept ? (request_chain ? request_step_recipe[55:48] : request_recipe[55:48]) : batch_step_domain;
                iteration[t]<=incoming_start; end_step[t]<=incoming_start+incoming_steps;
                capture_step[t]<=scalar_accept && !request_chain ? (scalar_shape==7 ? 5'd0 : 5'd1) : incoming_capture_step;
                capture_enable[t]<=incoming_capture;
                arity[t]<=scalar_accept ? request_recipe[47:40] : 8'd1;
                output_bytes[t]<=scalar_accept ? request_recipe[37:32] : incoming_family==0 ? 6'd16 : 6'd32;
                if(incoming_shape==0 && incoming_no_seed) begin
                    if(incoming_capture && incoming_capture_step==incoming_start)
                        captured[t]<=node_result(incoming_value,incoming_family);
                    if(incoming_steps==0) begin
                        need_block[t]<=0; complete[t]<=1;
                        if(scalar_accept) scalar_result<=(DIGEST_BYTES*8)'(node_result(incoming_value,incoming_family));
                    end
                end
                if(scalar_accept && (!RECIPE_MASK[scalar_shape] || scalar_shape==0)) begin
                    error<=1; need_block[t]<=0; complete[t]<=1; scalar_result<=0;
                end
            end
        end
    end

`ifndef SYNTHESIS
    logic [63:0] counted_batch_hashes,counted_batch_permutations;
    assign batch_hashes=counted_batch_hashes;
    assign batch_permutations=counted_batch_permutations;
    always_ff @(posedge clk) begin
        if(rst) begin
            hash_count<=0; permutation_count<=0; counted_batch_hashes<=0; counted_batch_permutations<=0;
        end else if(compression_complete_event) begin
            if(scalar_slot[compression_tag]) begin
                permutation_count<=permutation_count+64'd1;
                if(hash_complete_event) hash_count<=hash_count+64'd1;
            end else begin
                counted_batch_permutations<=counted_batch_permutations+64'd1;
                if(hash_complete_event) counted_batch_hashes<=counted_batch_hashes+64'd1;
            end
        end
    end
`endif
endmodule
`default_nettype wire
`endif
