from pathlib import Path
p=Path('build/sha2_p1_audit/cycles')
s=Path('tb/tb_fast.sv').read_text()
s=s.replace('output wire [31:0] configuration_pipeline,configuration_unroll','output wire [31:0] configuration_pipeline,configuration_unroll,\n output wire audit_accept,audit_return,audit_round,\n output wire [4:0] audit_kind, output wire [6:0] audit_block,\n output wire [2:0] audit_formatter')
s=s.replace(' wire [63:0] boot_cycles,keygen_cycles,sign_cycles;', ''' assign audit_accept=dut.core.lane.block_ready && dut.core.lane.compression_ready;
 assign audit_return=dut.core.lane.compression_complete_event;
 assign audit_round=dut.core.lane.compression.valid[0];
 assign audit_kind=dut.core.lane.format_kind;
 assign audit_block=dut.core.lane.format_block;
 assign audit_formatter=dut.core.lane.formatter;
 wire [63:0] boot_cycles,keygen_cycles,sign_cycles;''')
(p/'tb_fast_audit.sv').write_text(s)
s=Path('tb/fast_main.cpp').read_text().replace('#include <vector>','#include <vector>\n#include <map>\n#include <limits>')
s=s.replace('unsigned sent=0,accepted=0;', '''unsigned sent=0,accepted=0;
    uint64_t audit_accepts=0,audit_returns=0,audit_rounds=0,last_accept=0,last_return=0;
    uint64_t latency_min=UINT64_MAX,latency_max=0,latency_sum=0;
    uint64_t turn_min=UINT64_MAX,turn_max=0,turn_sum=0,turn_count=0;
    std::map<unsigned,uint64_t> audit_blocks,audit_formatter;''')
s=s.replace('if(observe) {','''if(observe) {
            if(dut.execution_active && !dut.execution_reset) {
                audit_rounds+=dut.audit_round;
                audit_formatter[dut.audit_formatter]++;
                if(dut.audit_accept) {
                    audit_accepts++;last_accept=ticks;
                    audit_blocks[(unsigned(dut.audit_kind)<<8)|unsigned(dut.audit_block)]++;
                    if(last_return) {uint64_t n=ticks-last_return;turn_min=std::min(turn_min,n);turn_max=std::max(turn_max,n);turn_sum+=n;turn_count++;}
                }
                if(dut.audit_return) {
                    audit_returns++;last_return=ticks;
                    uint64_t n=ticks-last_accept;latency_min=std::min(latency_min,n);latency_max=std::max(latency_max,n);latency_sum+=n;
                }
            }''')
s=s.replace('dut.final();return 0;', '''std::cout << "AUDIT_COUNTS accepts="<<audit_accepts<<" returns="<<audit_returns<<" round_cycles="<<audit_rounds<<" latency_min="<<latency_min<<" latency_max="<<latency_max<<" latency_sum="<<latency_sum<<" turn_count="<<turn_count<<" turn_min="<<turn_min<<" turn_max="<<turn_max<<" turn_sum="<<turn_sum<<std::endl;
    for(auto x:audit_blocks)std::cout<<"AUDIT_BLOCK kind="<<(x.first>>8)<<" block="<<(x.first&255)<<" count="<<x.second<<std::endl;
    for(auto x:audit_formatter)std::cout<<"AUDIT_FORMATTER state="<<x.first<<" cycles="<<x.second<<std::endl;
    dut.final();return 0;''')
(p/'fast_audit.cpp').write_text(s)
