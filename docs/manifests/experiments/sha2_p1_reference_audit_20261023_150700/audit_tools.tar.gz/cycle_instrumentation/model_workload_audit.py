from pathlib import Path
import sys,json,collections,hashlib
sys.path.insert(0,str(Path.cwd()))
from model.executor import Job,Machine,compile_image
from model.hashes import block_count
folder=Path('tb/vectors/sha2/slh_128f/sign')
cfg=[int(x,16) for x in (folder/'job.mem').read_text().split()]
job=Job(*(x.to_bytes(32,'little')[:16] for x in cfg[:4]),identifier=cfg[5].to_bytes(16,'little'),q=cfg[6])
msg=bytes(int(x,16) for x in (folder/'message.mem').read_text().split())[:cfg[8]]
expected=bytes(int(x,16) for x in (folder/'expected.mem').read_text().split())
image=compile_image('slh_128f',hash_backend='sha2')
counts=collections.Counter()
shared_prefix=job.public+bytes(48)
prefix_hashes=0
prefix_blocks=0
def observe(rid,data,result):
 global prefix_hashes,prefix_blocks
 r=image.descriptors[rid]
 shape=(r>>56)&15;domain=(r>>48)&255
 counts[(rid,shape,domain,len(data),block_count(len(data),'sha2'))]+=1
 if data[:64]==shared_prefix:
  prefix_hashes+=1;prefix_blocks+=1
machine=Machine(image,job,observe,index_policy='fixed_q_no_guard')
machine.values[3]=cfg[4].to_bytes(32,'little')[:16]
sig=machine.run(True,msg)
assert sig==expected
rows=[dict(recipe_id=rid,shape=shape,domain=domain,input_length=length,compressions_per_hash=blocks,hashes=count,compressions=count*blocks) for (rid,shape,domain,length,blocks),count in sorted(counts.items())]
result=dict(hash_backend='sha2',configuration='P1U1',profile='slh_128f',operation='sign',rtl_measured_cycles=15192941,hashes=machine.hashes,compressions=machine.permutations,signature_bytes=len(sig),signature_sha256=hashlib.sha256(sig).hexdigest(),matches_archived_expected=True,common_public_seed_prefix_hashes=prefix_hashes,common_public_seed_prefix_compressions=prefix_blocks,round_cycles_without_overhead=machine.permutations*64,round_cycles_after_one_prefix_cache=(machine.permutations-prefix_blocks+1)*64,remaining_cycles=15192941-machine.permutations*64,rows=rows)
Path('build/sha2_p1_audit/cycles/workload.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
