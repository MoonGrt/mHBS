from pathlib import Path
import difflib
import hashlib
import json
import shutil
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
RUNS = ROOT / 'build/pu_sign_matrix'
WORK = Path(__file__).resolve().parent
OUT = ROOT / 'docs/manifests/experiments/recipe_redundancy_20261014'


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


candidate = sys.argv[1]
experiments = json.loads((WORK / 'experiments.json').read_text())
baseline = experiments['baseline']
OUT.mkdir(parents=True, exist_ok=True)
for run, name in ((baseline, 'BASELINE_SOURCE.json'), (candidate, 'SOURCE.json')):
    shutil.copyfile(RUNS / run / 'SOURCE.json', OUT / name)
validation = RUNS / candidate / 'source/validation'
shutil.copyfile(validation / 'FINAL_VALIDATION.json', OUT / 'VALIDATION.json')
if (validation / 'source_audit.json').exists():
    shutil.copyfile(validation / 'source_audit.json', OUT / 'SOURCE_AUDIT.json')
dump('EXPERIMENTS.json', dict(**experiments, candidate=candidate))
states = {e['run_id']: json.loads((RUNS / e['run_id'] / 'status.json').read_text())
          for e in experiments['experiments']}
states[baseline] = json.loads((RUNS / baseline / 'status.json').read_text())
dump('MEASUREMENTS.json', states)
rtl = (RUNS / candidate / 'source/sources.txt').read_text().splitlines()
names = rtl + ['scripts/check_recipes.py', 'tb/tb_recipe.sv']
patch = []
for name in names:
    old = (RUNS / baseline / 'source' / name).read_text().splitlines(True)
    new = (RUNS / candidate / 'source' / name).read_text().splitlines(True)
    patch.extend(difflib.unified_diff(old, new, fromfile='a/' + name, tofile='b/' + name))
(OUT / 'candidate.patch').write_text(''.join(patch))
checkpoints = []
for run in (baseline, candidate):
    for path in sorted((RUNS / run / 'synth').glob('*/common/synthesized.dcp')):
        checkpoints.append(dict(run_id=run, path=str(path), sha256=sha(path), bytes=path.stat().st_size))
dump('CHECKPOINTS.json', checkpoints)
with tarfile.open(OUT / 'evidence.tar.gz', 'w:gz') as archive:
    def add(path, target):
        archive.add(path, arcname=target, recursive=False)
    for run in states:
        folder = RUNS / run
        metadata = json.loads((folder / 'SOURCE.json').read_text())
        for name in ('SOURCE.json', 'status.json', 'runner.log'):
            add(folder / name, f'{run}/{name}')
        selected = metadata['sha256'] if run in (baseline, candidate) else names + ['sources.txt']
        for name in selected:
            add(folder / 'source' / name, f'{run}/source/{name}')
        for path in sorted((folder / 'synth').rglob('*')):
            if path.is_file() and path.suffix in ('.log', '.rpt', '.txt', '.json'):
                add(path, f'{run}/{path.relative_to(folder)}')
        for path in sorted((folder / 'sim').rglob('*.log')):
            add(path, f'{run}/{path.relative_to(folder)}')
    for path in sorted(validation.rglob('*')):
        if path.is_file() and 'obj' not in path.parts and path.suffix in ('.log', '.json', '.py'):
            add(path, f'{candidate}/source/validation/{path.relative_to(validation)}')
    for path in sorted((RUNS / candidate / 'source/build/recipe_check').rglob('*')):
        if path.is_file() and path.name in ('coverage.json', 'run.log', 'recipes.mem'):
            add(path, f'{candidate}/source/{path.relative_to(RUNS / candidate / "source")}')
    for path in sorted((WORK / 'recipe_validation').rglob('*')):
        if path.is_file():
            add(path, f'mask_regression/{path.relative_to(WORK / "recipe_validation")}')
    add(Path(__file__), 'archive.py')
    add(ROOT / 'scripts/report_atp_focus.py', 'report_atp_focus.py')
    add(WORK / 'watch_report.py', 'watch_report.py')
    for suffix in ('.md', '.csv', '.json', '_Notes.md'):
        path = ROOT / 'docs/report' / ('Recipe_Redundancy_ATP_20261014' + suffix)
        add(path, 'report_snapshot/' + path.name)
(OUT / 'README.md').write_text(
    '# Recipe redundancy optimization evidence\n\n'
    f'Baseline: `{baseline}`; selected candidate: `{candidate}`.\n\n'
    'Areas are complete common OOC cores, generic Keccak, 6.666667 ns synthesis constraints, '
    'two Vivado threads. ATP uses assumed 150 MHz; no new routed STA is claimed.\n\n'
    '`evidence.tar.gz` contains baseline/selected source and vectors, every candidate RTL, '
    'measured synthesis/simulation reports, exact selected-source validation and mask failure/pass evidence. '
    'The rejected candidates are retained. DCP files remain in build with paths and SHA256 in CHECKPOINTS.json.\n\n'
    'XMSS/LMS h20 Keygen and Sign stayed stopped. Historical reports are unchanged.\n\n'
    'Unfinished rejected-candidate syntheses are delivery-time snapshots and continue in the background. '
    'The live report may backfill their measurements; this evidence archive remains the delivery snapshot.\n')
dump('SHA256.json', {p.name: sha(p) for p in sorted(OUT.iterdir())
                     if p.is_file() and p.name != 'SHA256.json'})
print(OUT)
