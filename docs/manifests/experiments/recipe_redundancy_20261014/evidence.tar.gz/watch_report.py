from pathlib import Path
import json
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
metadata = json.loads((WORK / 'experiments.json').read_text())
candidate = sys.argv[1]
command = [sys.executable, str(ROOT / 'scripts/report_atp_focus.py'),
           '--baseline', metadata['baseline'], '--candidate', candidate,
           '--output', str(ROOT / 'docs/report/Recipe_Redundancy_ATP_20261014')]
for experiment in metadata['experiments']:
    command += ['--experiment', experiment['label'] + '=' + experiment['run_id']]
previous = None
while True:
    paths = [ROOT / 'build/pu_sign_matrix' / e['run_id'] / 'status.json'
             for e in metadata['experiments']]
    signature = tuple(path.stat().st_mtime_ns for path in paths)
    if signature != previous:
        subprocess.run(command, cwd=ROOT, check=True)
        previous = signature
    if all(json.loads(path.read_text())['complete'] for path in paths):
        break
    time.sleep(15)
