from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse
import hashlib
import json
import shutil
import tarfile

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
PREVIOUS = ROOT / 'build/sha2_prefix_cache/20261023_152208'
LABEL = 'sha2_remaining_optimization_' + WORK.name
ARCHIVE = ROOT / 'docs/manifests/experiments' / LABEL
REPORT_NAME = 'SHA2_Remaining_Optimization_' + WORK.name


def read(path):
    return json.loads(path.read_text())


def put(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def copy(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--selected', choices=['C', 'D'], required=True)
    args = parser.parse_args()
    selected = args.selected.lower()
    source = WORK / ('candidate_' + selected)
    identity = read(source / 'SOURCE.json')
    assert all(digest(source / name) == value == digest(ROOT / name) for name, value in identity.items())
    old_identity = read(PREVIOUS / 'FINAL_SOURCE.json')['sha256']
    original_identity = read(WORK / 'BASELINE_SOURCE.json')
    assert all(old_identity[name] == value for name, value in original_identity.items())

    regression = read(WORK / ('regression_' + selected) / 'SUMMARY.json')
    focus = read(WORK / ('validation_' + selected) / 'RESULTS.json')
    profile = read(WORK / ('validation_' + selected + '_profile') / 'RESULTS.json')
    synth = read(WORK / ('SYNTH_' + args.selected + '_RESULTS.json'))
    independent = read(WORK / 'independent_reference/result/SUMMARY.json')
    assert regression['complete'] and regression['passed']
    assert focus['complete'] and focus['passed'] and focus['completed'] == 12
    assert profile['complete'] and profile['passed']
    assert synth['complete'] and synth['passed'] == 3
    assert independent['passed'] and independent['signature_sha256'] == profile['results'][0]['signature_sha256']
    baseline_focus = read(PREVIOUS / 'FOCUS_SIGN_RESULTS.json')['results']
    baseline_synth = read(PREVIOUS / 'FINAL_SYNTH_RESULTS.json')['results']
    baseline_profile = next(row for row in read(ROOT / 'tmp/sloth_cycle_comparison/MEASUREMENTS.json')['results'] if row['backend'] == 'sha2')
    measured = profile['results'][0]
    measured_profile = measured['cycle_breakdown']
    area = {row['configuration']: row for row in synth['results']}
    old_area = {row['configuration']: row for row in baseline_synth}

    comparisons = []
    for row in focus['results']:
        before = next(item for item in baseline_focus if (item['configuration'], item['profile']) == (row['configuration'], row['profile']))
        assert (before['hashes'], before['compressions'], before['logical_compressions']) == (row['hashes'], row['compressions'], row['logical_compressions'])
        result = dict(configuration=row['configuration'], profile=row['profile'], before_cycles=before['cycles'], cycles=row['cycles'],
                      cycle_delta_percent=(row['cycles'] / before['cycles'] - 1) * 100,
                      hashes=row['hashes'], actual_compressions=row['compressions'],
                      logical_compressions=row['logical_compressions'], signature_sha256=row['signature_sha256'])
        if row['configuration'] in area:
            frequency = 150e6
            result.update(assumed_frequency_mhz=150, frequency_verified=False,
                          before_atp=old_area[row['configuration']]['area']['equivalent_slice'] * before['cycles'] / frequency,
                          atp=area[row['configuration']]['area']['equivalent_slice'] * row['cycles'] / frequency)
            result['atp_delta_percent'] = (result['atp'] / result['before_atp'] - 1) * 100
        comparisons.append(result)

    stages = []
    for stage in ['A', 'B', 'C', 'D']:
        folder = WORK / ('validation_' + stage.lower() + ('_profile' if stage != 'A' else ''))
        stage_profile = read(folder / 'RESULTS.json')['results'][0]
        stage_synth = read(WORK / ('SYNTH_' + stage + '_RESULTS.json'))
        assert stage_synth['complete']
        stages.append(dict(stage=stage, selected=stage == args.selected, profile=stage_profile['cycle_breakdown'],
                           source=read(WORK / ('candidate_' + stage.lower()) / 'SOURCE.json'), synthesis=stage_synth))

    now = datetime.now(ZoneInfo('Asia/Singapore')).isoformat(timespec='seconds')
    summary = dict(complete=True, created_at=now, selected_stage=args.selected, source_sha256=identity,
                   source_changes=[name for name in original_identity if digest(source / name) != original_identity[name]],
                   baseline_source_matches_previous_synthesis=True, baseline_profile=baseline_profile,
                   profile=measured, remaining_delta_percent=(measured_profile['remaining'] / baseline_profile['remaining'] - 1) * 100,
                   total_delta_percent=(measured_profile['total'] / baseline_profile['total'] - 1) * 100,
                   comparisons=comparisons, synthesis=synth, stages=stages,
                   validation=dict(focus=focus, regression=regression, profile=profile, independent_c=independent),
                   selection_reason='Prioritize P1 Remaining/area and retain one generic design; D improves all nine measured same-frequency ATP comparisons. C remains a smaller P4/P12 alternative.',
                   routing='not_requested_not_run', final_frequency_verified=False,
                   runtime_directory=str(WORK.relative_to(ROOT)), detailed_simulation_logs_archived=False,
                   no_h20_full_trees_run=True)
    reports = ARCHIVE / 'reports'
    reports.mkdir(parents=True, exist_ok=True)
    put(reports / (REPORT_NAME + '.json'), summary)

    text = [f'# SHA2 Remaining 优化（{WORK.name}）', '',
            f'最终保留候选 {args.selected}，已覆盖工作区 RTL。生产改动仅位于 `rtl/hash/sha2-recipe.sv`，对所有合法 P/U 通用，单 Hash lane、接口、标准配方、签名顺序及完整树重算保持原规则。', '',
            '## 同输入实测 Remaining', '',
            '采用与上一张 SLOTH 比较图完全相同的33字节KAT、P1U1、SLH-DSA-SHA2-128f Sign。两个版本均逐字节核对17,088字节签名及signature缓存。Hash分类为实际64轮和feed-forward；Remaining包括其他控制、装配与内部搬移。Transfer仍按Hash MMIO定义为0。', '',
            '| 版本 | 总周期 | Hash | Remaining | Remaining占比 |', '|---|---:|---:|---:|---:|']
    for name, row in [('修改前', baseline_profile), ('最终候选', measured_profile)]:
        text.append(f"| {name} | {row['total']:,} | {row['hash']:,} | {row['remaining']:,} | {row['remaining']/row['total']:.2%} |")
    text += ['', f"Remaining降低{-summary['remaining_delta_percent']:.2f}%，总周期降低{-summary['total_delta_percent']:.2f}%；Hash104,925次、实际压缩106,514块均保持不变。该KAT与默认1字节向量不同，下面的整核周期不混用输入。", '',
             '| 状态 | 修改前非Hash周期 | 最终非Hash周期 |', '|---|---:|---:|']
    previous_states = read(ROOT / 'tmp/sloth_cycle_comparison/remaining_profile/sha2/result.json')['format_state_totals']
    for i, name in enumerate(['SELECT', 'DESCRIBE', 'PREPARE', 'BUILD', 'DRAIN']):
        text.append(f"| {name} | {previous_states[name]:,} | {measured['remaining_formatter_totals'].get(str(i), 0):,} |")
    text += ['', '## 实现与阶段取舍', '',
             '固定布局在描述符阶段直接译码；PREPARE用已登记的地址字段和节点银行一次拼出512位输入，写入原有四个128位块银行，替代四拍BUILD与DRAIN。覆盖SLH的seed/unary/binary、HMAC外层、MGF尾块，XMSS的PRF/seed/final及纯填充块，LMS的seed/chain/leaf/parent。列表和变长消息继续使用128位流式装配。', '',
             '无其他候选且块寄存器空闲时，在压缩结果返回的同一沿预约该上下文的下一描述符。digest/phase更新后再进入DESCRIBE，不组合旁路压缩输出到下一次SHA256输入；普通排队请求优先。四个已有上下文银行和捕获消费规则保持一致。', '',
             '固定格式译码直接使用pair/chain字段，避免完整长度加法与比较串入控制路径。SHA256末轮和feed-forward寄存边界保留。', '',
             '| 阶段 | 变化 | 同KAT总周期 | Remaining | 是否采用 |', '|---|---|---:|---:|---|']
    descriptions = {'A': '固定块在单拍BUILD写入', 'B': '提前到PREPARE，并在返回沿预约；仍经长度译码',
                    'C': 'pair/chain直接译码，另移除四类流式源', 'D': 'pair/chain直接译码，保留原流式源映射作面积对照'}
    for row in stages:
        text.append(f"| {row['stage']} | {descriptions[row['stage']]} | {row['profile']['total']:,} | {row['profile']['remaining']:,} | {'是' if row['selected'] else '保留对照'} |")
    text += ['', 'A的速度收益较小；B在P12增加了phase→input_length→fixed_format串行控制路径。C/D周期一致，未引入P/U专用开关。D优先控制本轮重点P1的面积，三点九项同频ATP均下降；C在P4/P12面积及诊断时序更好，保留为该方向的对照，两者没有全面支配关系。各阶段面积和路径保存在JSON及`synth/`。', '',
             '## 同口径 common 综合面积与诊断路径', '',
             'Vivado2025.2、xc7a200tffg1156-3、OOC、统计关闭、默认时序驱动、每进程2线程、100MHz诊断约束。修改前源码逐文件核对与上一轮最终综合完全一致，直接引用其同设置证据。等效Slice=LUT/4+FF/8；本轮不运行布局布线，以下路径为综合网表估计，不能证明150MHz实际闭合。', '',
             '| 配置 | 原等效Slice | 新LUT | 新FF | BRAM36 | DSP | 新等效Slice | 面积变化 | 原/新诊断路径ns |', '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for config in ['P1U1', 'P4U1', 'P12U1']:
        row, before = area[config], old_area[config]
        a = row['area']
        text.append(f"| {config} | {before['area']['equivalent_slice']:,.3f} | {a['lut']:,.0f} | {a['ff']:,.0f} | {a['bram36']:g} | {a['dsp']:g} | {a['equivalent_slice']:,.3f} | {row['area_delta_percent']:+.2f}% | {before['data_path_delay_ns']:.3f}/{row['data_path_delay_ns']:.3f} |")
    text += ['', '## 完整 Sign 周期与辅助 ATP', '',
             '本节采用仓库默认1字节向量。ATP单位为等效Slice·s，按同配置common综合面积、U1假定150MHz计算，只用于同频比较，不代表当前候选已通过该频率布线。P4U2仅补充周期验证，本轮未测其同源面积，ATP留空。']
    for name in ['slh_128f', 'xmss_h10', 'lms_h10']:
        text += ['', f'### {name}', '', '| 配置 | 原周期 | 新周期 | 周期变化 | 原辅助ATP | 新辅助ATP | ATP变化 |', '|---|---:|---:|---:|---:|---:|---:|']
        for config in ['P1U1', 'P4U1', 'P4U2', 'P12U1']:
            row = next(item for item in comparisons if (item['configuration'], item['profile']) == (config, name))
            values = f"{row['before_atp']:,.4f} | {row['atp']:,.4f} | {row['atp_delta_percent']:+.2f}%" if 'atp' in row else '— | — | —'
            text.append(f"| {config} | {row['before_cycles']:,} | {row['cycles']:,} | {row['cycle_delta_percent']:+.2f}% | {values} |")
    text += ['', '## 验证、范围与归档', '',
             f"最终同一冻结源码的12项完整Sign、同33字节KAT周期采样及{regression['required']}组补充回归全部通过。补充回归包括四配置各345配方、前缀缓存复位/种子切换与满槽波次、P24U1/P12U2兼容、乱序/同拍补发/未消费捕获、四种top统计/签名缓存宏视图、SLH128f/128s及XMSS/LMS h10 Keygen/Verify、Verify停顿/中断重放/篡改。Hash和实际压缩次数逐项核对；旧SHAKE配方未改。", '',
             '重新使用../../source/slhdsa-c独立C路径生成公钥/签名并验证最终RTL导出的完整签名，33字节KAT与RTL输出逐字节一致，源码及适配程序身份已记录。', '',
             'h20完整Keygen/Sign继续停止；本次没有重做h16/h15完整树测试，没有生成性能外推数据。实际布线频率及布线ATP待用户明确指定后验收。', '',
             '后续主要空拍是DESCRIBE/PREPARE与结果返回/上层控制。进一步压缩应继续避免把标签选择、长度加法、宽节点选择和压缩反馈串接成一条长路径。', '',
             f"原始运行目录：`{WORK.relative_to(ROOT)}`。详细仿真/验证日志保留于运行目录；归档仅保留验证摘要、冻结RTL、源码身份、综合分层/时序/日志和本报告。实验报告只生成Markdown/JSON，不生成CSV或README。", '',
             f"复现单候选测量：`python3 scripts/run_sha2_remaining_validation.py --source {source.relative_to(ROOT)} --work <新目录>`；该入口不会启动综合或布线。"]
    (reports / (REPORT_NAME + '.md')).write_text('\n'.join(text) + '\n')

    put(ARCHIVE / 'SOURCE.json', identity)
    put(ARCHIVE / 'BASELINE_SOURCE.json', original_identity)
    put(ARCHIVE / 'BASELINE_PROVENANCE.json', dict(frozen_source=str((PREVIOUS / 'source_final').relative_to(ROOT)),
         source_sha256=old_identity, matches_all_baseline_files=True, synthesis=str((PREVIOUS / 'FINAL_SYNTH_RESULTS.json').relative_to(ROOT))))
    put(ARCHIVE / 'validation_summary' / 'FINAL.json', summary['validation'])
    copy(WORK / 'independent_reference/source/REFERENCE_SOURCE.json', ARCHIVE / 'REFERENCE_SOURCE.json')
    copy(WORK / 'independent_reference/source/reference_source.tar.gz', ARCHIVE / 'reference_source.tar.gz')
    for stage in ['baseline', 'candidate_a', 'candidate_b', 'candidate_c', 'candidate_d']:
        with tarfile.open(ARCHIVE / ('rtl.tar.gz' if stage == 'candidate_' + selected else stage + '_rtl.tar.gz'), 'w:gz') as tar:
            for path in sorted((WORK / stage).rglob('*')):
                if path.is_file() and (path.suffix in ('.sv', '.svh') or path.name == 'sources.txt'):
                    tar.add(path, arcname=str(path.relative_to(WORK / stage)), recursive=False)
    for stage in ['a', 'b', 'c', 'd']:
        copy(WORK / ('SYNTH_' + stage.upper() + '_RESULTS.json'), ARCHIVE / ('SYNTH_' + stage.upper() + '_RESULTS.json'))
        for config in ['P1U1', 'P4U1', 'P12U1']:
            for path in (WORK / ('synth_' + stage) / config).iterdir():
                if path.is_file() and path.suffix in ('.rpt', '.log', '.txt', '.xdc', '.json'):
                    copy(path, ARCHIVE / 'synth' / stage.upper() / config / path.name)
    for config in ['P1U1', 'P4U1', 'P12U1']:
        for path in (PREVIOUS / 'diagnostics/final' / config).iterdir():
            if path.is_file() and path.suffix in ('.rpt', '.log', '.txt', '.xdc', '.json'):
                copy(path, ARCHIVE / 'synth' / 'baseline' / config / path.name)
    control = [Path(__file__), ROOT / 'scripts/run_sha2_remaining_validation.py',
               ROOT / 'scripts/diagnose_timing.tcl', WORK / ('run_regression_' + selected + '.py')]
    with tarfile.open(ARCHIVE / 'support.tar.gz', 'w:gz') as tar:
        for path in control:
            tar.add(path, arcname='control/' + path.name, recursive=False)
        for path in sorted((source / 'tb').glob('*')):
            if path.is_file():
                tar.add(path, arcname='tb/' + path.name, recursive=False)
    files = {str(path.relative_to(ARCHIVE)): digest(path) for path in ARCHIVE.rglob('*') if path.is_file() and path.name != 'ARTIFACTS.json'}
    put(ARCHIVE / 'ARTIFACTS.json', dict(complete=True, selected=args.selected, created_at=now, files_sha256=files,
         runtime_directory=str(WORK.relative_to(ROOT)), detailed_simulation_logs='runtime_only', layout_and_routing='not_run'))
    index = ROOT / 'docs/manifests/experiments/INDEX.md'
    content = index.read_text()
    line = f'| {LABEL} | [{REPORT_NAME}]({LABEL}/reports/{REPORT_NAME}.md) | [证据]({LABEL}/ARTIFACTS.json) |'
    if line not in content:
        insertion = content.rfind('\n|')
        insertion = content.find('\n', insertion + 1)
        content = content[:insertion] + '\n' + line + content[insertion:]
        index.write_text(content)
    print(json.dumps(dict(report=str(reports / (REPORT_NAME + '.md')), selected=args.selected,
         remaining=measured_profile['remaining'], area={key: val['area']['equivalent_slice'] for key, val in area.items()}), ensure_ascii=False))


if __name__ == '__main__':
    main()
