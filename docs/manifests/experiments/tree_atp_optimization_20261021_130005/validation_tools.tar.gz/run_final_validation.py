import sys,json,concurrent.futures,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.run_hash_backends import build_binary,simulate,source_identity,write,SLH_NAMES,ALL_NAMES,image_variants,stateful_boundary_signs
root=Path.cwd();old=root/'build/image-chain-tree/stateful_final_20261021_v2';run=root/'build/image-chain-tree/tree_atp_final_full_gate'
run.mkdir(parents=True,exist_ok=True);identity=source_identity();key=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()[:16];exe=build_binary(root/'build/image-chain-tree'/('tree_atp_candidate_'+key))
tasks=[(n,o) for n in ALL_NAMES for o in ('keygen','sign','verify') if (old/'vectors'/n/o/'result.json').exists()]
rows={}
with concurrent.futures.ThreadPoolExecutor(6) as pool:
 pending={(n,o):pool.submit(simulate,run,n,o,exe,image_folder=old/'images',vector_folder=old/'vectors') for n,o in tasks}
 for (n,o),r in pending.items():
  rows[n+'/'+o]=r.result();write(run/'progress.json',dict(cases=rows,source_sha256=identity))
for label,o,options,trace in [('stall','verify',('+STALL=1',),True),('reset','verify',('+INTERRUPT=1',),True),('replay','verify',('+REPLAY=1',),True),('truncated','verify',('+CUT=5',),True),('sign_reset','sign',('+INTERRUPT=1',),True),('macro_sign_reset','sign',('+CHAIN_INTERRUPT=1',),True),('tree_sign_reset','sign',('+TREE_INTERRUPT=1',),True),('tree_snapshot','sign',('+TREE_SNAPSHOT=1',),True),('tree_fault','sign',('+FAULT=16',),False)]:
 rows[label]=simulate(run,'slh_128f',o,exe,suffix='_'+label,options=options,trace=trace,image_folder=old/'images',vector_folder=old/'vectors')
for name in ('slh_128f','xmss_h10','lms_h10'):
 rows[name+'_reserved_profile']=simulate(run,name,'verify',exe,suffix='_reserved_profile',options=('+FAULT=17',),trace=False,image_folder=old/'images',vector_folder=old/'vectors')
rows['lms_job_snapshot']=simulate(run,'lms_h10','verify',exe,suffix='_job_snapshot',options=('+LMS_SNAPSHOT=1',),image_folder=old/'images',vector_folder=old/'vectors')
write(run/'rtl.json',dict(passed=True,cases=rows,source_sha256=identity,fixture_root=str(old),note='Independent VM vectors and ordered Hash traces reused only; RTL freshly compiled.'))
print('FULL_GATE_PASS',len(rows),flush=True)
