#!/usr/bin/env python3
"""Frozen P4U2 specialization: Verilator equivalence and OOC synthesis only."""
import argparse, concurrent.futures, hashlib, json, re, shutil, subprocess, tarfile
from pathlib import Path
from experiment_support import snapshot, area, PART
from v42_common_partition import partition
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'manifests/experiments/fixed_p4u2_20261009'
BUILD=ROOT/'build/fixed_p4u2_20261009'
BASE=BUILD/'baseline'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def tool(cmd,log,cwd=ROOT):
 log.parent.mkdir(parents=True,exist_ok=True)
 with log.open('w') as stream:r=subprocess.run(list(map(str,cmd)),cwd=cwd,stdout=stream,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError(f'{log}: exit {r.returncode}\n'+log.read_text()[-2500:])
def freeze(label):
 if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*',label):raise ValueError('invalid label')
 d=OUT/label;d.mkdir(parents=True,exist_ok=True);snapshot(d)
 meta=json.loads((d/'inputs.json').read_text());meta['frequency_mhz_assumed']=110;meta['scope']='fixed P4U2 common core';write(d/'inputs.json',meta)
 (d/'source.patch').write_bytes(subprocess.check_output(['git','diff','HEAD'],cwd=ROOT))
 source=BUILD/label/'source';source.mkdir(parents=True,exist_ok=True)
 with tarfile.open(d/'source_snapshot.tar.gz') as t:t.extractall(source,filter='data')
 return source

def frozen_partition(source):
 ns={};exec((source/'scripts/v42_common_partition.py').read_text(),ns)
 return ns['partition']((source/'rtl/top/mhbs_top.sv').read_text())

def source_for(label):
 source=BUILD/label/'source';meta=json.loads((OUT/label/'inputs.json').read_text())
 assert sha(OUT/label/'source_snapshot.tar.gz')==meta['snapshot_sha256']
 if not source.exists():
  with tarfile.open(OUT/label/'source_snapshot.tar.gz') as archive:archive.extractall(source,filter='data')
 for f,h in meta['source_sha256'].items():assert sha(source/f)==h,f
 return source

def references(d):
 """Rename every frozen module, so the comparison shares no live logic."""
 if not (BASE/'rtl/top/mhbs_top.sv').exists():
  with tarfile.open(OUT/'baseline/source_snapshot.tar.gz') as archive:archive.extractall(BASE,filter='data')
 paths=(BASE/'manifests/v42_sources.txt').read_text().split();names=[Path(f).stem for f in paths]+['mhbs_common']
 def rename(s):return re.sub(r'\b('+'|'.join(names)+r')\b',lambda m:'frozen_'+m[0],s)
 refs=[]
 for f in paths:
  if f.endswith('mhbs_top.sv'):continue
  dest=d/('frozen_'+Path(f).name);dest.write_text(rename((BASE/f).read_text()));refs.append(dest)
 ns={};exec((BASE/'scripts/v42_common_partition.py').read_text(),ns)
 common,_=ns['partition']((BASE/'rtl/top/mhbs_top.sv').read_text())
 dest=d/'frozen_common.sv';dest.write_text(rename(common));refs.append(dest)
 return refs

def compile_tb(label,top,params=(),equiv=False,stats=1):
 source=source_for(label);name=top+'_'+str(stats)+'_'+hashlib.sha256(str(params).encode()).hexdigest()[:8]
 d=BUILD/label/name;d.mkdir(parents=True,exist_ok=True);refs=references(d)
 # Unit oracles use the exact pre-specialization recipe and context modules.
 tb=(source/('tb/integration' if top=='tb_mhbs_stateful' else 'tb/unit')/(top+'.sv')).read_text()
 tb=tb.replace('mhbs_recipe_pre_direct_ref','frozen_mhbs_recipe_lane').replace('mhbs_chain_pipeline_lane_ref','frozen_mhbs_chain_pipeline_lane')
 (d/(top+'.sv')).write_text(tb)
 common,_=frozen_partition(source);(d/'common.sv').write_text(common)
 files=[source/f for f in (source/'manifests/v42_sources.txt').read_text().split() if not f.endswith('mhbs_top.sv')]+[d/'common.sv',*refs,d/(top+'.sv')]
 identity={str(f):sha(f) for f in files}
 identity.update({str(f):sha(f) for f in (source/'tb').rglob('*.svh')})
 exe=d/'obj'/('V'+top)
 if not exe.exists() or not (d/'identity.json').exists() or json.loads((d/'identity.json').read_text())!=identity:
  tool(['verilator','--binary','--timing','-O3','-j','2','-Wno-fatal','--top-module',top,*(['-DSINGLE_LANE_EQUIV',f'-GPROFILE_ENABLE={stats}'] if equiv else []),*params,'--Mdir',exe.parent,*files],OUT/label/'logs'/(name+'_compile.log'),source)
  write(d/'identity.json',identity)
 return exe

def unit(label):
 source=source_for(label);v=OUT/'vectors';v.mkdir(exist_ok=True)
 # Execute only the independent hashlib vector generator, never its historical Icarus runner.
 text=(BASE/'scripts/verify_lup_pipeline.py').read_text();start=text.index('rng=random.Random');end=text.index('sources=')
 import random
 exec(text[start:end],{'random':random,'hashlib':hashlib,'OUT':v})
 old=ROOT/'manifests/experiments/stateful_20261008/unit_evidence/macro_hash'
 for name in ['recipe_padding.mem',*[f'chain_capture_{i}.mem' for i in range(3)]]:shutil.copy2(old/name,v/name)
 cases=[('rounds','tb_mhbs_round_decode',[],[]),('overlap','tb_mhbs_chain_overlap',[],[f'+VECTORS={v}']),('padding','tb_mhbs_recipe_padding',[],[f'+VECTORS={v}/recipe_padding.mem']),('format','tb_mhbs_chain_format_equiv',[],[])]
 for i in range(3):
  cases += [(f'recipe_{i}','tb_mhbs_v42_recipe_lane',[f'-GPROFILE={i}'],[]),(f'capture_{i}','tb_mhbs_v42_recipe_lane',[f'-GPROFILE={i}','-GMASK=6','-GCASES=12'],[f'+VECTORS={v}/chain_capture_{i}.mem'])]
 def one(c):
  name,top,params,opts=c;exe=compile_tb(label,top,params);log=OUT/label/'logs'/(name+'.log');tool([exe,*opts],log,source)
  assert 'PASS' in log.read_text(),name
  print('UNIT_PASS',label,name,flush=True);return name,dict(passed=True,log_sha256=sha(log),binary_sha256=sha(exe))
 with concurrent.futures.ThreadPoolExecutor(3) as pool:rows=dict(pool.map(one,cases))
 write(OUT/label/'unit.json',rows)

def vector(name,op):
 return OUT/'vectors/jobs'/name/str(op)

def regression(label,quick=False,stats=1):
 exe=compile_tb(label,'tb_mhbs_stateful',equiv=True,stats=stats);source=source_for(label)
 names=['slh_128f','slh_192f','slh_256f','slh_128s','slh_192s','slh_256s','xmss_omega2','xmss_omega4','lms_omega2','lms_omega4']
 cases=[(n+'_'+str(op),vector(n,op),[]) for n in names for op in range(3)]
 if quick:cases=[('slh_128f_1',vector('slh_128f',1),[])]
 else:
  cases += [('sign_stall_reset',vector('slh_128f',1),['+STALL=1','+INTERRUPT=1','+REPLAYS=2']),('fault',vector('slh_128f',1),['+FAULT=1']),('verify_stall_reset',vector('slh_128f',2),['+STALL=1','+INTERRUPT=1','+REPLAYS=2'])]
  for n in ['slh_128f','xmss_omega4','lms_omega4']:
   cases += [(n+'_tamper_'+str(t),vector(n,2),[f'+TAMPER={t}']) for t in range(1,6)]
 def one(c):
  name,v,opts=c;log=OUT/label/'logs'/(name+f'_stats{stats}.log');tool([exe,f'+VECTOR={v}',*opts],log,source)
  t=log.read_text();m=re.findall(r'STATEFUL_PASS \w+ op=(\d+) cycles=(\d+) total=(\d+) hashes=(\d+) permutations=(\d+)',t)
  if m:
   r=dict(zip(('operation','compute_cycles','total_cycles','hashes','permutations'),map(int,m[-1])))
   if name=='slh_128f_1':assert (r['compute_cycles'],r['hashes'],r['permutations'])==(412170,104937,105641),r
  else:assert 'STATEFUL_FAULT_PASS' in t;r={}
  r.update(passed=True,cycle_equivalence=True,log_sha256=sha(log),binary_sha256=sha(exe),vectors_sha256={f.name:sha(f) for f in v.iterdir() if f.is_file()})
  print('EQUIV_PASS',label,name,r.get('compute_cycles'),flush=True);return name,r
 with concurrent.futures.ThreadPoolExecutor(6) as pool:rows=dict(pool.map(one,cases))
 write(OUT/label/(('quick' if quick else 'regression')+f'_stats{stats}.json'),rows)

def synth(label):
 source=source_for(label);d=OUT/label/'synthesis';d.mkdir(exist_ok=True);work=BUILD/label/'synthesis';work.mkdir(exist_ok=True)
 common,_=frozen_partition(source);(d/'common.sv').write_text(common)
 (d/'clock.xdc').write_text('create_clock -name clk -period 6.666667 [get_ports clk]\n')
 lines=['set_param general.maxThreads 2',f'create_project -in_memory -part {PART}']
 lines += [f'read_verilog -sv {{{source/f}}}' for f in (source/'manifests/v42_sources.txt').read_text().split() if not f.endswith('mhbs_top.sv')]
 lines += [f'read_verilog -sv {{{d/"common.sv"}}}',f'read_xdc {{{d/"clock.xdc"}}}',f'synth_design -top mhbs_common -part {PART} -mode out_of_context -flatten_hierarchy rebuilt -max_dsp 0 -generic PROFILE_ENABLE=0',f'report_utilization -file {{{d/"core_utilization.rpt"}}}',f'report_utilization -hierarchical -file {{{d/"core_hierarchical.rpt"}}}',f'report_timing_summary -file {{{d/"core_timing.rpt"}}}',
 'set bad {}','foreach c [get_cells -hier -filter {IS_PRIMITIVE == 1}] {if {[string match FD* [get_property REF_NAME $c]] && [regexp {(cycles|hash_count|permutation_count|hash_base|permutation_base)_reg} $c]} {lappend bad $c}}','if {[llength $bad]} {error "statistics remain: $bad"}',f'write_checkpoint -force {{{work/"post_synth.dcp"}}}','puts "FIXED_P4U2_SYNTH_PASS"','exit']
 (d/'synth.tcl').write_text('\n'.join(lines)+'\n');tool(['vivado','-mode','batch','-nolog','-nojournal','-source',d/'synth.tcl'],d/'vivado.log',work)
 assert 'FIXED_P4U2_SYNTH_PASS' in (d/'vivado.log').read_text()
 r=dict(area=area(d/'core_utilization.rpt'),statistics_pruned=True,routed=False,clock_period_ns=6.666667,assumed_mhz=110,source_snapshot_sha256=sha(OUT/label/'source_snapshot.tar.gz'),evidence_sha256={f.name:sha(f) for f in d.iterdir() if f.is_file()})
 write(OUT/label/'synthesis.json',r);print('SYNTH_PASS',label,r['area'],flush=True)

def external(label):
 import v42_external_flow as flow
 source=source_for(label);folder=BUILD/label/'external'
 flow.ROOT=source;flow.BASE=source/'manifests/experiments/unified_hbs_v4.2/external_job_message'
 def run(cmd,log,cwd=source):
  cmd=list(cmd)
  if cmd[0]=='verilator':cmd[cmd.index('-j')+1]='2'
  tool(cmd,log,source)
 flow.run=run
 rows={}
 for partitioned,stats in ((False,True),(True,True),(True,False)):
  name=f'partition{int(partitioned)}_stats{int(stats)}'
  _,r=flow.simulate_case(folder,name,flow.BASE/'vectors/slh_128f/sign',partitioned=partitioned,profile_enable=stats)
  assert (r['sign_cycles'],r['hashes'],r['permutations'])==(412170,104937,105641)
  rows[name]=r
 assert len({r['output_sha256'] for r in rows.values()})==1
 shutil.copytree(folder/'logs',OUT/label/'external_logs',dirs_exist_ok=True)
 write(OUT/label/'external.json',rows)

def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('action',choices=['freeze','unit','quick','regression','synth','external']);a.add_argument('label');a.add_argument('--stats',type=int,choices=[0,1],default=1);args=a.parse_args()
 if args.action=='freeze':freeze(args.label)
 elif args.action in ('quick','regression'):regression(args.label,args.action=='quick',args.stats)
 else:globals()[args.action](args.label)
if __name__=='__main__':main()
