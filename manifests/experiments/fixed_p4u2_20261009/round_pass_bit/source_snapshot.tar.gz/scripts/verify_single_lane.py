#!/usr/bin/env python3
"""Verify the fixed P4U2 executor against its frozen pre-specialization core."""
from fixed_p4u2 import main
if __name__ == '__main__':
    main()
