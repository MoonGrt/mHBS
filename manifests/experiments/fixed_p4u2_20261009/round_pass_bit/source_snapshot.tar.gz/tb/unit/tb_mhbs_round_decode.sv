`timescale 1ns/1ps
// Fixed P4U2 round positions, checked against the frozen full round function.
module tb_mhbs_round_decode;
 logic [1599:0] state_in,pattern_state;
 logic [1:0] pass_index;
 wire [1599:0] result[0:7];
 `include "tb/reference/keccak_round_frozen.svh"
 for(genvar stage=0;stage<4;stage=stage+1)begin: stages
  for(genvar round_id=0;round_id<2;round_id=round_id+1)begin: rounds
   mhbs_keccak dut(.state_in,
    .round_index({pass_index,2'(stage),1'(round_id)}),.state_out(result[stage*2+round_id]));
  end
 end
 integer checks=0;
 initial begin
  for(integer pattern=0;pattern<34;pattern=pattern+1)begin
   for(integer w=0;w<50;w=w+1)pattern_state[32*w +:32]=pattern==0 ? 0 : pattern==1 ? '1 : $random;
   state_in=pattern_state;#1;
   for(integer pass=0;pass<3;pass=pass+1)begin
    pass_index=2'(pass);#1;
    for(integer position=0;position<8;position=position+1)begin
     if(result[position]!==keccak_round(state_in,5'(pass*8+position)))
      $fatal(1,"round mismatch pass=%0d position=%0d",pass,position);
     checks++;
    end
   end
  end
  if(checks!=816)$fatal(1,"round coverage");
  $display("ROUND_DECODE_PASS checks=%0d",checks);$finish;
 end
endmodule
