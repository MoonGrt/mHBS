# mHBS v4.2

固定单 lane、P4U2 共同核，支持 SLH-DSA SHAKE **128f、192f、256f、128s、192s、256s** 的 Keygen、Sign 和外部节点 Verify。新增实验 SHAKE256 XMSS/LMS（n=32、h=10、omega=2/4）的三种操作，见 [扩展报告](docs/v4.2/Stateful_XMSS_LMS.md)。唯一顶层为 `rtl/top/mhbs_top.sv`，每次同步复位后执行一次操作。

`LANES` 与 `SWAP_PHYSICAL_LANES` 已删除，不能通过参数恢复多 lane。`PIPELINE/UNROLL`（P/U）也已删除：普通哈希和四上下文链共用四级、每级两轮的 Keccak 数据通路。十种算法参数和三种操作均保留。

固定 P4U2 的结构、回归与综合对比见 [固定 P4U2 优化报告](docs/report/Fixed_P4U2_Optimization.md)。历史 P/U 报告和快照保持原样，不代表当前可配置性。

## 构建与验证

```bash
make contract-test lint
make fixed-p4u2-test TAG=my_fixed  # 冻结源码、Verilator 单元和十参数三操作逐周期对照
make fixed-p4u2-synth TAG=my_fixed # 同一快照共同核综合，无布线
python3 scripts/fixed_p4u2.py external my_fixed # 顶层/共同核及统计关闭对照
make rtl-profile-test TAG=probe PROFILE=slh_192f OPERATION=sign
make reproduce-v42 reproduce-ku   # 只读历史封存证据
```

当前固定配置流程使用 Python、Verilator、GNU Make 和 C++ 编译器，不运行 Icarus；综合使用 Vivado。修改源码或测试后使用新的 TAG。旧 P/U 矩阵须从对应冻结源码运行。完整流程见[验证指南](docs/Verification.md)。

## 接口与镜像

- Stateful Job 另有 KEY_INDEX 与 IDENTIFIER，索引由外部持久化管理。五个节点 Job 参数：SECRET_SEED、SECRET_PRF、PUBLIC_SEED、RANDOMIZER、PUBLIC_ROOT；`OPERATION=0/1/2` 选择 Keygen/Sign/Verify。
- 消息：64 位 valid/ready 输入；Sign/Verify 长度 1–87 字节，Keygen 长度为零。
- 输出：256 位节点拍，`out_bytes` 指明有效低位字节，无输出背压。
- Verify：256 位外部节点 valid/ready 输入，完成后读取 `verify_pass`。
- 镜像保持文件加载：program 16×64、template 16×64、descriptor 32×64；SLH 有效条目分别为 14、11、30；新 XMSS/LMS 为 10、8、26/29，含填充容量为 512 B。

[架构](docs/Architecture.md) · [端口协议](docs/Job_Interface.md) · [物理 ABI](docs/ABI.md) · [宏语义](docs/Unified_HBS_ABI.md)

## 文件与证据

- `rtl/`：源清单中的生产模块；FORS 根和 WOTS 端点共用 `mhbs_value_store`。
- `model/`、`tests/`、`tb/`：当前镜像生成、软件参考、协议和密码运算回归；旧命名的模型仍属于编译依赖。
- `scripts/`、`experiments/v4.2/external_job_message/`：当前验证、综合、布线及 ROM 映射工具。
- 本轮源码快照、原始分层报告和验证日志在 `manifests/experiments/single_lane_20261008/`；`current_core.json` 仍指向历史封存版本。
- [最新 K/U 报告](docs/v4.2/KU_Sign_ATP_150_110_67_48.md)和[原始 K/U 归档](manifests/experiments/ku_sign_latest/README.md)独立保留；`make report-ku`、`make reproduce-ku` 不依赖 build。
- 旧候选、重复报告和实验驱动已删除，可从 Git 恢复。清理清单：`manifests/cleanup_20261002.json`。
- `source/`、`tmp/` 是本地研究资料和工作笔记，不属于生产源码或已提交备份。

历史 K1P1U1～K1P4U1 的统一 Keccak 实现及当时共同核综合结果见 [第二轮 ATP 报告](docs/v4.2/KPU_ATP_Unified_Optimization.md)。150 MHz 为假定频率，未布线。
