#!/usr/bin/env python3
"""Report fixed P4U2 candidates using measured common-core synthesis evidence."""
import csv,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'manifests/experiments/fixed_p4u2_20261009'
DOC=ROOT/'docs/report/Fixed_P4U2_Optimization'
def main():
 decisions=json.loads((OUT/'decisions.json').read_text())
 assert decisions['status']=='complete', 'Candidate decisions are not final'
 def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
 def check_synthesis(label,record):
  for name,value in record['evidence_sha256'].items():
   assert digest(OUT/label/'synthesis'/name)==value,(label,name)
  assert record['statistics_pruned'] and not record['routed']
  assert record['clock_period_ns']==6.666667

 old=ROOT/'manifests/experiments/single_lane_13_20261009_v4/P4U2'
 area=json.loads((old/'synthesis.json').read_text())['area']
 rows=[dict(candidate='113648d7 P4U2',parent='',retained=True,reason='original baseline',**area,compute_cycles=412170,total_cycles=412175,hashes=104937,permutations=105641,evidence=str(old.relative_to(ROOT)))]
 for label in decisions['order']:
  if not (OUT/label/'synthesis.json').exists():continue
  syn=json.loads((OUT/label/'synthesis.json').read_text())
  check_synthesis(label,syn)
  sim=json.loads((OUT/label/'quick_stats1.json').read_text())['slh_128f_1']
  assert sim['passed'] and sim['cycle_equivalence']
  assert (sim['hashes'],sim['permutations'])==(104937,105641)
  rows.append(dict(candidate=label,**decisions[label],**syn['area'],**{k:sim[k] for k in ('compute_cycles','total_cycles','hashes','permutations')},evidence=str((OUT/label).relative_to(ROOT))))
 for r in rows:
  r.update(assumed_mhz=110,routed=False,time_ms=r['compute_cycles']/110000,atp_slice_ms=r['equivalent_slice']*r['compute_cycles']/110000,keccak_effective_round_utilization_percent=100*r['permutations']*24/(8*r['compute_cycles']))
 final=decisions['final'];live={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in (ROOT/'manifests/v42_sources.txt').read_text().split()}
 source=json.loads((OUT/final/'inputs.json').read_text())['source_sha256']
 assert all(source[p]==h for p,h in live.items()),'Current RTL differs from accepted measured candidate'
 gate=json.loads((OUT/'final_validation.json').read_text())
 assert gate['passed'] and gate['candidate']==final and gate['rtl_sha256']==live
 data=dict(validation=gate,unmeasured_candidates={k:decisions[k] for k in ['round_pass',*decisions['order']] if not (OUT/k/'synthesis.json').exists()},baseline_commit='113648d7',final=final,frequency_note='110 MHz assumed; not routed',device='xc7a200tffg1156-3',synthesis_clock_ns=6.666667,rows=rows,current_rtl_sha256=live)
 DOC.with_suffix('.json').write_text(json.dumps(data,indent=2)+'\n')
 keys=list(rows[0]);keys += [k for r in rows for k in r if k not in keys]
 keys=list(dict.fromkeys(keys))
 with DOC.with_suffix('.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
  for label,item in data['unmeasured_candidates'].items():
   w.writerow(dict(candidate=label,parent=item['parent'],retained=False,reason=item['reason'],assumed_mhz=110,routed=False,evidence=str((OUT/label).relative_to(ROOT))))
 lines=['# 固定 P4U2 优化','','固定单 lane、四级流水、每级两轮；十参数三操作保留。共同核综合、PROFILE_ENABLE=0、xc7a200tffg1156-3、6.666667 ns，不布线。**110 MHz 为假定频率，未经布线验证。**','','| 候选 | LUT | FF | LUTRAM | BRAM / DSP | 等效 Slice | 128f sign 周期 | ATP（Slice·ms） | 结论 |','|---|---:|---:|---:|---|---:|---:|---:|---|']
 for r in rows:lines.append(f"| {r['candidate']} | {r['lut']:,.0f} | {r['ff']:,.0f} | {r['lutram']:,.0f} | {r['bram36']:g} / {r['dsp']:g} | {r['equivalent_slice']:,.3f} | {r['compute_cycles']:,} | {r['atp_slice_ms']:,.3f} | {r['reason']} |")
 last=next(r for r in rows if r['candidate']==final)
 lines += ['',f"最终保留 **{final}**；相对原始 P4U2，LUT 变化 {last['lut']-area['lut']:+,.0f}，FF 变化 {last['ff']-area['ff']:+,.0f}，等效 Slice 变化 {last['equivalent_slice']-area['equivalent_slice']:+,.3f}。",
 '', '## 未完成测量的候选', '', *[f"- `{name}`：{row['reason']}。未获得面积结果，不计入上表，也不保留其 RTL 改动。" for name,row in data['unmeasured_candidates'].items()], '', '## 实现与验收', '', '- 固定结构：移除生产 P/U 参数、P1 串行路径和独立 sponge 状态；tag 两位、槽位计数三位、掩码四位。仅固定参数的综合资源与基线完全一致。', '- 轮控制候选：每级两位遍次编号，轮号按遍次/固定位置拼接，第三遍结束返回。', '- 原双位相等终止判断候选 `round_pass` 通过功能回归，但综合超过 13 分钟仍在时序优化，后改用只检查最高位的 `round_pass_bit`；原任务主动停止，没有面积结果，不参与面积比较。', '- 四槽存储候选 `four_slots` 将部分 LUTRAM 转成 FF，等效 Slice 增加，撤回。修订候选 `four_control` 保留原数组写端口，仅简化固定优先级、无效范围判断及尾批后缀检查。总 LUT 不增加、等效 Slice 严格下降、功能通过且周期不增加才保留。', '- 外部数据接口、输出次序、Keccak 轮函数、端点存储和批次调度保持原行为。', '', '## 验证', '', f"- 最终验证证据：`{gate['evidence_label']}`；测试与被接受候选的全部生产 RTL 哈希一致。", '- Verilator 对冻结 `113648d7` P4U2 整核逐周期对照，检查握手、输出、完成、错误和统计；十参数三操作以及停顿、复位重放、故障、消息/节点/根篡改。', '- 全 24 轮另以零值、全一和随机状态完成 816 次冻结轮函数比对。', '- 单元覆盖三节点宽度、普通/compact chain、交错上下文、capture 禁用/未命中/槽位复用、反馈冲突、背压和共享状态写入隔离；独立 hashlib 向量和冻结轮函数为参考。', '- 完整顶层/提取共同核及统计关闭均对照软件签名；128f sign 为 412,170 计算周期、412,175 总周期、104937 Hash / 105641 次置换。', '- 历史链格式测试的 pending 记分板有多进程更新竞争，本轮改为单 posedge 更新；修正后覆盖 354 次接受和 252 次同拍完成/新请求。初始失败日志保留，属于测试问题，不作为通过证据。', '', '## 面积和证据口径', '', '等效 Slice = LUT/4 + FF/8 + 232.4×BRAM36 + 102.4×DSP；LUT 已含 LUTRAM，不重复计数。时间(ms)=计算周期/110000；ATP=等效 Slice×时间。有效轮利用率=置换次数×24/(8×计算周期)，已完成仿真的候选均为约 76.89%。', '', f"[最终分层报告](../../{(OUT/final/'synthesis/core_hierarchical.rpt').relative_to(ROOT)})", '', '所有独立候选的源码快照、补丁、输入哈希、仿真日志和综合报告位于 `manifests/experiments/fixed_p4u2_20261009/`。旧 13 点报告保持原样。本轮不提交、不推送。']
 # docs/report -> repository root needs two parent components.
 DOC.with_suffix('.md').write_text('\n'.join(lines)+'\n')
 print('REPORT_PASS',final)
if __name__=='__main__':main()
