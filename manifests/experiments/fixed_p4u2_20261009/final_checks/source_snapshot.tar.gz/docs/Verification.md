# 当前项目的构建与验证

## 固定单 lane、P4U2

生产 RTL 只有 `core.lane` 一个实例，P/U 参数也已删除。当前拓扑固定为四个流水级、每级两轮、四个交错上下文；共同核和顶层均不可覆盖此配置。

本轮对照 `113648d7` 的冻结 P4U2 实现，逐周期比较 Job/消息/Verify 握手、输出、完成、错误、周期和 Hash/置换计数。冻结模块仅参与验证；各候选读取独立源码快照。

```bash
make contract-test lint
make fixed-p4u2-test TAG=my_fixed
make fixed-p4u2-synth TAG=my_fixed
python3 scripts/fixed_p4u2.py external my_fixed
```

固定配置入口仅使用 Verilator。单元检查交错链、三种节点宽度、普通/compact chain、capture、末级共享状态、padding 和冻结轮函数逐级对照；整核检查十参数三操作，并补充停顿、复位重放、故障和消息/节点/根篡改。`external` 对比完整顶层与提取共同核的输出、周期，以及关闭统计后的行为。

输出位于 `manifests/experiments/fixed_p4u2_20261009/<标签>/`，编译缓存位于 `build/fixed_p4u2_20261009/`。历史 P/U 矩阵脚本在当前源码上明确报错；其原始快照不改写。旧流程与历史证据说明保留如下，不是本轮固定配置的执行入口。

## 工具与入口

在仓库根目录运行，依赖 Python、Verilator、GNU Make 和 C++ 编译器；综合使用 Vivado 2025.2、xc7a200tffg1156-3。本轮不运行 Icarus。

| 入口 | 内容 |
|---|---|
| `make contract-test lint` | 接口、不存在 lane/P/U 参数、源闭包、快照合同、RTL lint |
| `make smoke TAG=<新标签>` | 冻结源码、单元、128f sign 逐周期对照 |
| `make verify TAG=<新标签>` | 单元、十参数三操作、边界回归、统计关闭、共同核提取 |
| `make fixed-p4u2-test TAG=<新标签>` | 同上，但不含额外顶层/共同核对照 |
| `python3 scripts/fixed_p4u2.py external <已有标签>` | 顶层与共同核、统计开启/关闭的签名比较 |
| `make rtl-profile-test TAG=probe PROFILE=slh_192f OPERATION=sign` | 固定 P4U2 单点 SLH 仿真 |
| `python3 scripts/run_stateful.py` | 固定 P4U2 的 XMSS/LMS 软件向量检查 |
| `make reproduce-v42 reproduce-ku` | 只读核验历史封存证据 |

旧 `verify_v42_units.py`、P/U 扫描和历史综合脚本不用于当前固定配置，入口会提示使用新流程或原始源码快照。每次源码或测试发生变化后使用新的标签，禁止将旧测量覆盖成新版本结果。

## 共同核测量

```bash
make fixed-p4u2-test TAG=my_fixed
make fixed-p4u2-synth TAG=my_fixed
```

综合读取同标签冻结源码。约束 6.666667 ns，PROFILE_ENABLE=0，不布线；检查统计寄存器裁剪。LUT 包含 LUTRAM，不重复计数。时间和 ATP 采用假定 110 MHz，不代表实测频率。

历史 `synth-core`、`synth-common` 和 `route-common` 流程使用不同约束或外壳，不能混入本轮同约束比较。当前资源及候选验收见 [P4U2 优化报告](report/Fixed_P4U2_Optimization.md)；旧 K/U、P/U 和 XMSS/LMS 报告保持原数据。

## XMSS/LMS 软件参考

`stateful_vectors.py` 对照冻结 `67a1cd75` 模型和独立 hashlib 签名验证器；当前冷启动模型包含完整认证路径重算。原始向量保留于 `manifests/experiments/stateful_20261008/vectors/`，当前单 lane 测试结果写入独立目录。索引由外部持久化管理，复位不表示允许重复使用索引。
