#!/usr/bin/env python3
"""Frozen single-lane XMSS/LMS pipeline experiments; Verilator and OOC synthesis."""
from pathlib import Path
import argparse
import concurrent.futures
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import tarfile
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
OUT=ROOT/'manifests/experiments/stateful_pipeline_20261012'
BUILD=ROOT/'build/stateful_pipeline_20261012'
POINTS=[(p,u) for p in (1,4,12) for u in (1,2)]
PROFILES=('xmss_omega2','xmss_omega4','lms_omega2','lms_omega4')
VECTORS=ROOT/'manifests/experiments/fixed_p4u2_20261009/vectors/jobs'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    temporary=p.with_suffix(p.suffix+'.tmp');temporary.write_text(json.dumps(x,indent=2)+'\n');temporary.replace(p)
def freeze(label):
    d=OUT/label;d.mkdir(parents=True,exist_ok=True)
    if (d/'inputs.json').exists():return d
    names=(ROOT/'manifests/v42_sources.txt').read_text().split()
    names+=['manifests/v42_sources.txt','scripts/v42_common_partition.py','scripts/stateful_pipeline_experiment.py','scripts/run_stateful_keygen_pu13.py','tb/integration/tb_mhbs_stateful.sv']
    names+=list(str(f.relative_to(ROOT)) for f in (ROOT/'tb/unit').glob('*'))
    with tarfile.open(d/'source_snapshot.tar.gz','w:gz') as t:
        for name in sorted(set(names)):t.add(ROOT/name,arcname=name)
    (d/'source.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--','rtl','tb','scripts']))
    write(d/'inputs.json',dict(git_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_sha256={n:sha(ROOT/n) for n in names},archive_sha256=sha(d/'source_snapshot.tar.gz'),points=POINTS))
    return d
def source(label):
    d=OUT/label;info=json.loads((d/'inputs.json').read_text());assert sha(d/'source_snapshot.tar.gz')==info['archive_sha256']
    s=BUILD/label/'source'
    if not s.exists():
        s.mkdir(parents=True)
        with tarfile.open(d/'source_snapshot.tar.gz') as t:t.extractall(s,filter='data')
    for n,h in info['source_sha256'].items():assert sha(s/n)==h,n
    return s
def tool(cmd,log,cwd):
    log.parent.mkdir(parents=True,exist_ok=True)
    with log.open('w') as f:subprocess.run(list(map(str,cmd)),cwd=cwd,stdout=f,stderr=subprocess.STDOUT,check=True)
def build(label,p,u,stats=1):
    s=source(label);d=OUT/label/f'P{p}U{u}_stats{stats}';d.mkdir(parents=True,exist_ok=True)
    work=BUILD/label/d.name;binary=work/'obj/Vtb_mhbs_stateful'
    if binary.exists():return binary
    spec=importlib.util.spec_from_file_location('partition_'+label,s/'scripts/v42_common_partition.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    common,_=mod.partition((s/'rtl/top/mhbs_top.sv').read_text(),stub=True)
    (d/'mhbs_common.sv').write_text(common)
    files=[s/n for n in (s/'manifests/v42_sources.txt').read_text().split() if n!='rtl/top/mhbs_top.sv']
    tool(['verilator','--binary','--timing','-O3','-j','2','-Wno-fatal','--top-module','tb_mhbs_stateful',f'-GPIPELINE={p}',f'-GUNROLL={u}',f'-GPROFILE_ENABLE={stats}','--Mdir',work/'obj',*files,d/'mhbs_common.sv',s/'tb/integration/tb_mhbs_stateful.sv'],d/'compile.log',s)
    return binary
def run(label,p,u,name,op,stats=1,options=(),suffix=''):
    binary=build(label,p,u,stats);d=OUT/label/f'P{p}U{u}_stats{stats}'
    v=VECTORS/name/str(op);log=d/f'{name}_{op}{suffix}.log';result=log.with_suffix('.json')
    if result.exists():return json.loads(result.read_text())
    tool([binary,f'+VECTOR={v}',*options],log,ROOT)
    match=re.search(r'STATEFUL_PASS .*?op=(\d+) cycles=(\d+) total=(\d+) hashes=(\d+) permutations=(\d+)',log.read_text())
    if not match:raise RuntimeError(log)
    row=dict(profile=name,p=p,u=u,stats=stats,operation=int(match[1]),compute_cycles=int(match[2]),total_cycles=int(match[3]),hashes=int(match[4]),permutations=int(match[5]),log_sha256=sha(log))
    write(result,row);print('PASS',label,d.name,name,op,row['compute_cycles'],flush=True);return row
def matrix(label):
    def point(pu):
        p,u=pu
        return [run(label,p,u,n,op) for n in PROFILES for op in (0,1,2)]
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        rows=sum(list(pool.map(point,POINTS)),[])
    write(OUT/label/'matrix.json',rows)
def main():
    a=argparse.ArgumentParser();a.add_argument('action',choices=['freeze','run','matrix']);a.add_argument('label');a.add_argument('--p',type=int,default=4);a.add_argument('--u',type=int,default=1);a.add_argument('--name',default='lms_omega4');a.add_argument('--op',type=int,default=2);a.add_argument('--stats',type=int,default=1);args=a.parse_args()
    if args.action=='freeze':freeze(args.label)
    elif args.action=='matrix':matrix(args.label)
    else:run(args.label,args.p,args.u,args.name,args.op,args.stats)
if __name__=='__main__':main()
