from pathlib import Path
import subprocess
root=Path.cwd();out=root/'build/kpu_atp_opt/slots';out.mkdir(parents=True,exist_ok=True)
sources=(root/'manifests/v42_sources.txt').read_text().splitlines()
for u,p in ((1,1),(1,2),(1,3),(1,4),(2,2)):
 d=out/f'P{p}U{u}';d.mkdir(exist_ok=True)
 with (d/'run.log').open('w') as f:
  subprocess.run(['verilator','--binary','--timing','-O3','-j','8','-Wno-fatal','-Wno-WIDTH','--top-module','tb_mhbs_slot_release',f'-GUNROLL={u}',f'-GPIPELINE={p}','--Mdir',str(d/'obj'),*sources,'tb/unit/tb_mhbs_slot_release.sv'],stdout=f,stderr=subprocess.STDOUT,check=True)
  subprocess.run([str(d/'obj/Vtb_mhbs_slot_release'),'+VECTORS='+str(root/'build/lup_shared_units')],stdout=f,stderr=subprocess.STDOUT,check=True)
 assert 'SLOT_RELEASE_PASS' in (d/'run.log').read_text();print('SLOT_RELEASE_PASS',p,u,flush=True)
