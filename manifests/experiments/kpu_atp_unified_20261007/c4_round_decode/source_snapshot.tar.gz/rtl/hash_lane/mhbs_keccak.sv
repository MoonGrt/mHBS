`timescale 1ns/1ps
`default_nettype none

// Structurally explicit Keccak-f[1600] round used to compare Vivado mapping
// against the function-inlined implementation.
module mhbs_keccak #(
    parameter integer ROUND_STRIDE=1, ROUND_OFFSET=0
) (
    input  wire [1599:0] state_in,
    input  wire [4:0]    round_index,
    output wire [1599:0] state_out
);
    wire [63:0] a [0:24];
    wire [63:0] c [0:4];
    wire [63:0] d [0:4];
    wire [63:0] theta [0:24];
    wire [63:0] b [0:24];
    logic [63:0] rc;
    genvar x, y;

    function automatic [63:0] rotl64;
        input [63:0] value;
        input integer amount;
        begin
            rotl64 = amount == 0 ? value
                : (value << amount) | (value >> (64-amount));
        end
    endfunction

    function automatic integer rho_offset;
        input integer lane;
        begin
            case (lane)
                 0: rho_offset=0;   1: rho_offset=1;   2: rho_offset=62;
                 3: rho_offset=28;  4: rho_offset=27;  5: rho_offset=36;
                 6: rho_offset=44;  7: rho_offset=6;   8: rho_offset=55;
                 9: rho_offset=20; 10: rho_offset=3;  11: rho_offset=10;
                12: rho_offset=43; 13: rho_offset=25; 14: rho_offset=39;
                15: rho_offset=41; 16: rho_offset=45; 17: rho_offset=15;
                18: rho_offset=21; 19: rho_offset=8;  20: rho_offset=18;
                21: rho_offset=2;  22: rho_offset=61; 23: rho_offset=56;
                24: rho_offset=14;
                default: rho_offset=0;
            endcase
        end
    endfunction

    function automatic [63:0] round_constant;
        input [4:0] index;
        begin
            case (index)
                 0: round_constant=64'h0000000000000001;
                 1: round_constant=64'h0000000000008082;
                 2: round_constant=64'h800000000000808a;
                 3: round_constant=64'h8000000080008000;
                 4: round_constant=64'h000000000000808b;
                 5: round_constant=64'h0000000080000001;
                 6: round_constant=64'h8000000080008081;
                 7: round_constant=64'h8000000000008009;
                 8: round_constant=64'h000000000000008a;
                 9: round_constant=64'h0000000000000088;
                10: round_constant=64'h0000000080008009;
                11: round_constant=64'h000000008000000a;
                12: round_constant=64'h000000008000808b;
                13: round_constant=64'h800000000000008b;
                14: round_constant=64'h8000000000008089;
                15: round_constant=64'h8000000000008003;
                16: round_constant=64'h8000000000008002;
                17: round_constant=64'h8000000000000080;
                18: round_constant=64'h000000000000800a;
                19: round_constant=64'h800000008000000a;
                20: round_constant=64'h8000000080008081;
                21: round_constant=64'h8000000000008080;
                22: round_constant=64'h0000000080000001;
                23: round_constant=64'h8000000080008008;
                default: round_constant=0;
            endcase
        end
    endfunction

    // The default port is the absolute round index. A fixed pipeline stage
    // instead receives the pass index and decodes only its own constants.
    // All products below are elaboration constants, not runtime arithmetic.
    initial if(ROUND_STRIDE<1 || 24%ROUND_STRIDE!=0 || ROUND_OFFSET<0 || ROUND_OFFSET>=ROUND_STRIDE)
        $fatal(1,"invalid fixed round mapping");
    always_comb begin
        rc=0;
        if(ROUND_STRIDE==1 && ROUND_OFFSET==0)rc=round_constant(round_index);
        else for(integer pass=0;pass<24/ROUND_STRIDE;pass=pass+1)
            if(round_index==5'(pass))rc=round_constant(5'(pass*ROUND_STRIDE+ROUND_OFFSET));
    end
    generate
        for (y=0; y<5; y=y+1) begin : map_y
            for (x=0; x<5; x=x+1) begin : map_x
                localparam integer I = x + 5*y;
                localparam integer DEST = y + 5*((2*x + 3*y) % 5);
                assign a[I] = state_in[64*I +: 64];
                assign theta[I] = a[I] ^ d[x];
                assign b[DEST] = rotl64(theta[I], rho_offset(I));
                assign state_out[64*I +: 64] = b[I]
                    ^ ((~b[((x+1)%5)+5*y]) & b[((x+2)%5)+5*y])
                    ^ (I == 0 ? rc : 64'd0);
            end
        end
        for (x=0; x<5; x=x+1) begin : columns
            assign c[x] = a[x] ^ a[x+5] ^ a[x+10] ^ a[x+15] ^ a[x+20];
            assign d[x] = c[(x+4)%5] ^ rotl64(c[(x+1)%5], 1);
        end
    endgenerate
endmodule

`default_nettype wire
