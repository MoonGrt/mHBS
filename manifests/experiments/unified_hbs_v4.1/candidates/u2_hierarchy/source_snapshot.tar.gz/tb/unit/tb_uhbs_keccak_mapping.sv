`timescale 1ns/1ps
module tb_uhbs_keccak_mapping;
    reg [1599:0] state_in=0;
    reg [4:0] round_index=0;
    wire [1599:0] actual,expected;
    uhbs_keccak dut(.state_in,.round_index,.state_out(actual));
    uhbs_keccak_reference reference(.state_in,.round_index,.state_out(expected));
    reg [31:0] rng=32'h19ab4027;
    initial begin
        // Every state bit, all round constants, and dense deterministic data.
        for(integer i=0;i<1600;i=i+1) begin
            state_in=0;state_in[i]=1;round_index=i%24;#1;
            if(actual!==expected) $fatal(1,"mapping walking bit %0d",i);
        end
        for(integer i=0;i<192;i=i+1) begin
            for(integer w=0;w<50;w=w+1) begin
                rng=rng^(rng<<13);rng=rng^(rng>>17);rng=rng^(rng<<5);
                state_in[w*32 +:32]=rng;
            end
            round_index=i%24;#1;
            if(actual!==expected) $fatal(1,"mapping random %0d",i);
        end
        $display("KECCAK_PHYSICAL_MAPPING_PASS vectors=1792");$finish;
    end
endmodule
