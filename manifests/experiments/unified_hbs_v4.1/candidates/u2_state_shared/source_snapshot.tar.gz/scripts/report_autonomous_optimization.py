#!/usr/bin/env python3
"""Generate v4.1 comparison tables exclusively from measured manifests."""
import argparse,json
from autonomous_flow import ROOT,BASE

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--tag',required=True);args=parser.parse_args()
    candidate=BASE/'candidates'/args.tag
    ppa=json.loads((candidate/'ppa.json').read_text())
    rows=[]
    for path in sorted((BASE/'candidates').glob('*/ppa.json')):
        p=json.loads(path.read_text())
        rows.append(f'| {p["tag"]} | {p["stage"]} | {p["frequency_mhz"]:.3f} | {p.get("index_policy","guarded")} | {p["lut"]:,} | {p["ff"]:,} | {p["lutram"]:,} | {p["equivalent_slice"]:,.3f} | {p.get("wns_ns","—")} | {p["worst_ratio"]:.4f} |')
    lines=['# μHBS v4.1：U2 优化与论文对比','',
        '**状态：功能验证与性能验收分别记录；没有 final.json 就不表示性能完成。**','',
        '本轮固定 U2、双 lane、三个独立分布式 ROM、ABI 4。当前执行策略为 `fixed_q_no_guard`：',
        'XMSS/LMS 使用固定 q 和选定认证路径，不提供索引消耗、防复用或提交确认。历史带 guard 数据保留。','',
        '## 已完成的共同硬件候选','',
        '下表面积包含 ROM、Boot、执行器和计数逻辑。post-synth 使用 100 MHz 归一化；post-route 使用该行实测频率。',
        '最差比例为七点签名 ATP 与有效门槛之比的最大值；有效门槛取论文门槛与适用的 V3 上限较小值。','',
        '| 候选 | 阶段 | MHz | 索引策略 | LUT | FF | LUTRAM（已包含于 LUT） | 等效 Slice | WNS/ns | 最差 ATP 比例 |',
        '|---|---|---:|---|---:|---:|---:|---:|---:|---:|',*rows,'',
        '等效面积 = LUT/4 + FF/8 + BRAM36 等效数×232.4 + DSP×102.4。','',
        f'## 比较候选：{args.tag}','',
        f'阶段：`{ppa["stage"]}`。以下面积、周期来自该候选同一源码快照；不代表之后工作树版本。',
        f'共同面积 **{ppa["equivalent_slice"]:,.3f} Slice**；计算频率 **{ppa["frequency_mhz"]:.3f} MHz**，依据 `{ppa.get("frequency_basis","normalized_only")}`。','',
        '| Profile | Boot | Keygen 周期 | Sign 周期 | Keygen ATP | Sign ATP | 论文门槛 | V3 上限 | 数值达标 |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---|']
    for name,p in ppa['profiles'].items():
        old='—' if p['v3_ceiling'] is None else f'{p["v3_ceiling"]:,.6f}'
        lines.append(f'| {name} | {p["boot_cycles"]} | {p["keygen_cycles"]:,} | {p["sign_cycles"]:,} | {p["keygen_atp"]:,.3f} | {p["sign_atp"]:,.3f} | {p["paper_threshold"]:,.3f} | {old} | {"是" if p["paper_pass"] and p["v3_pass"] else "否"} |')
    lines += ['', 'ATP 单位：Slice·ms。论文门槛采用论文报告毫秒值；历史论文周期与 108 MHz 重算表见保留的历史对比报告。','',
        '## 移除 guard 的单独增量','',
        '同一 U2 基线移除 guard 后，LUT 42,190→42,162，FF 14,124→14,052，等效面积 12,313→12,297 Slice。',
        '四个 XMSS/LMS 参数点 Sign 均减少 4 周期；Boot、Keygen 和 SLH Sign 周期不变。',
        '这是整机重新综合后的净变化。其余面积下降来自另外的候选结构，不能归因于移除 guard。','',
        '## 比较限制与来源','',
        '- NON_STRICT：SLH-DSA 与论文 SPHINCS+ 版本不同；LMS 使用 SHAKE256/256 研究 profile。',
        '- 本设计使用固定输入、一次启动仅一次签名；XMSS/LMS Keygen 生成选定 q 的认证路径，Sign 复用缓存。',
        '- V3/V4 分别静态综合；v4.1 要求七点共用硬件和频率。当前无 guard，不能据此声称状态保护开销相同。',
        '- 最终验收还须具备 post-route 时序、完整布线、覆盖检查，以及七份仅 ROM INIT 不同的结构证据。',
        f'- 候选来源：`manifests/experiments/unified_hbs_v4.1/candidates/{args.tag}/`，包含源码快照、SHA-256、原始报告及仿真引用。','',
        '```bash',f'python3 scripts/report_autonomous_optimization.py --tag {args.tag}',
        'python3 scripts/reproduce_paper_comparison.py',
        'python3 scripts/reproduce_seven_profiles.py',
        'python3 scripts/reproduce_autonomous.py --allow-incomplete','```','']
    out=ROOT/'docs/v4.1/Unified_HBS_Paper_Comparison.md';out.write_text('\n'.join(lines));print(out)

if __name__=='__main__':main()
