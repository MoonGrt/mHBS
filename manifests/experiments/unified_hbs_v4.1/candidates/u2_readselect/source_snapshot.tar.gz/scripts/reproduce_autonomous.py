#!/usr/bin/env python3
"""Audit v4.1 archived evidence; refuse to turn partial PPA into acceptance."""
from pathlib import Path
import argparse,hashlib,json,math,re,sys,tarfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from model.profiles import PROFILES
from model.autonomous_hbs import ProgramImage
from rom_initialization import mapping
BASE=ROOT/'manifests/experiments/unified_hbs_v4.1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check(ok,message):
    if not ok:raise AssertionError(message)
def eq(a,b):return math.isclose(float(a),float(b),rel_tol=1e-11,abs_tol=1e-9)
def resource(text,label):
    match=re.search(r'\|\s*'+re.escape(label)+r'\*?\s*\|\s*([\d,.]+)\s*\|',text)
    check(match is not None,'missing resource '+label)
    return float(match[1].replace(',',''))
def audit_architecture():
    for folder in sorted((BASE/'architecture').glob('*')):
        if not (folder/'results.json').exists():continue
        data=json.loads((folder/'results.json').read_text())
        gate=json.loads((folder/'model_gate.json').read_text())
        identity=hashlib.sha256(json.dumps(data['logic_sha256'],sort_keys=True).encode()).hexdigest()[:16]
        check(identity==folder.name and data['passed'] and gate['passed'],'architecture identity/gate')
        probes=data['probes']
        check(set(probes)=={'base','program','template','recipe','route','loop','run'},'architecture coverage')
        for name,probe in probes.items():
            check(probe['model_pass'] and probe['rtl_pass'],'architecture pass '+name)
            log=folder/(name+'.log');check(sha(log)==probe['log_sha256'],'architecture log '+name)
            for file,digest in probe['image_sha256'].items():
                check(sha(folder/'images'/name/file)==digest,'architecture image '+name+'/'+file)
            text=log.read_text()
            trace=[[int(phase),int(cmd,16)] for phase,cmd in re.findall(r'MACRO_TRACE phase=(\d+) command=([0-9a-f]+)',text)]
            check('AUTONOMOUS_PASS' in text and trace==probe['macro_trace'],'architecture trace '+name)
            check(all(probe[k]==v for k,v in gate['probes'][name].items()),'architecture software/RTL evidence '+name)
        check(probes['program']['macro_trace']!=probes['base']['macro_trace'],'program changes execution')
        check(probes['template']['macro_trace']!=probes['base']['macro_trace'],'template changes execution')
        check(probes['loop']['macro_trace']==probes['run']['macro_trace'],'loop/run expansion')
        for name in ('recipe','route'):
            check(probes[name]['oracle_sha256']!=probes['base']['oracle_sha256'],name+' changes output')
        print('V4.1 image-driven architecture: PASS',identity)

def audit_candidates():
    ceilings_raw=json.loads((ROOT/'manifests/experiments/unified_hbs_final.json').read_text())['profiles']
    ceilings={a:ceilings_raw[b]['sign_atp'] for a,b in [('slh_128f','slh'),('xmss_omega4','xmss'),('lms_omega4','lms')]}
    for folder in sorted((BASE/'candidates').glob('*')):
        if not (folder/'evidence.json').exists():continue
        evidence=json.loads((folder/'evidence.json').read_text())
        for name,digest in evidence['evidence_sha256'].items():
            check(sha(folder/name)==digest,'candidate evidence '+folder.name+'/'+name)
        inputs=json.loads((folder/'inputs.json').read_text())
        ppa=json.loads((folder/'ppa.json').read_text())
        check(sha(folder/'inputs.json')==ppa['inputs_sha256'],'candidate inputs '+folder.name)
        check(sha(folder/'source_snapshot.tar.gz')==inputs['snapshot_sha256'],'candidate snapshot '+folder.name)
        with tarfile.open(folder/'source_snapshot.tar.gz') as tar:
            for name,digest in inputs['source_sha256'].items():
                check(hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest,'candidate source '+name)
        check(all(inputs['source_sha256'][name]==digest for name,digest in inputs['logic_sha256'].items()),'candidate logic closure')
        util=(folder/'utilization.rpt').read_text()
        area=resource(util,'Slice LUTs')/4+resource(util,'Slice Registers')/8+resource(util,'Block RAM Tile')*232.4+resource(util,'DSPs')*102.4
        check(eq(area,ppa['equivalent_slice']),'candidate area '+folder.name)
        period=10 if ppa['stage']=='post_synth' else json.loads((folder/'final_clock.json').read_text())['period_ns']
        check(eq(period,ppa['period_ns']) and eq(1000/period,ppa['frequency_mhz']),'candidate frequency')
        ratios=[]
        for name,p in PROFILES.items():
            row=ppa['profiles'][name];path=ROOT/row['simulation'];sim=json.loads(path.read_text())
            check(sha(path)==row['simulation_sha256'] and sha(path.with_suffix('.log'))==sim['log_sha256'],'candidate simulation '+name)
            check(sim['passed'] and sim['logic_sha256']==inputs['logic_sha256'],'candidate cycle/source mismatch '+name)
            for kind in ('boot','keygen','sign'):
                check(row[kind+'_cycles']==sim[kind+'_cycles'],'candidate cycles '+name)
            atp=area*sim['sign_cycles']*period/1e6
            ratio=atp/min(p.target,ceilings.get(name,float('inf')))
            check(eq(atp,row['sign_atp']) and eq(ratio,row['ratio']),'candidate ATP '+name)
            check(eq(row['keygen_atp'],area*sim['keygen_cycles']*period/1e6),'candidate Keygen ATP '+name)
            check(row['paper_pass']==(atp<p.target) and row['v3_pass']==(name not in ceilings or atp<=ceilings[name]),'candidate pass flags '+name)
            ratios.append(ratio)
        check(eq(max(ratios),ppa['worst_ratio']),'candidate ranking '+folder.name)
        print('V4.1 candidate audit: PASS',folder.name,ppa['stage'])

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--allow-incomplete',action='store_true');args=parser.parse_args()
    gate=json.loads((BASE/'software_gate.json').read_text());check(gate['pass'],'software gate')
    for path,digest in gate['sources'].items():check(sha(ROOT/path)==digest,'software source '+path)
    images=json.loads((BASE/'images.json').read_text())['profiles']
    for name,data in images.items():
        folder=BASE/'images'/name;ProgramImage.read(folder).decode()
        for path,digest in data['image_sha256'].items():check(sha(folder/path)==digest,'ROM image '+name+'/'+path)
    print('V4.1 software gate / images: PASS')
    update=json.loads((BASE/'author_update.json').read_text())
    check(update['updated_sign_cycles']==815706 and update['changes_acceptance_threshold'] is False,'author update/unchanged acceptance')
    audit_architecture()
    audit_candidates()
    final_path=BASE/'final.json'
    if not final_path.exists():
        print('V4.1 performance acceptance: INCOMPLETE (no final manifest)')
        return 0 if args.allow_incomplete else 2
    final=json.loads(final_path.read_text());check(final['version']=='v4.1' and final['abi_version']==4,'version/ABI')
    folder=BASE/final['archive'];inputs=json.loads((folder/'inputs.json').read_text());ppa=json.loads((folder/'ppa.json').read_text())
    check(sha(folder/'source_snapshot.tar.gz')==inputs['snapshot_sha256'],'snapshot digest')
    with tarfile.open(folder/'source_snapshot.tar.gz','r:gz') as tar:
        for path,digest in inputs['source_sha256'].items():check(hashlib.sha256(tar.extractfile(path).read()).hexdigest()==digest,'snapshot source '+path)
    for path,digest in final['evidence_sha256'].items():check(sha(BASE/path)==digest,'evidence '+path)
    util=(folder/'utilization.rpt').read_text()
    lut,ff,bram,dsp=[resource(util,s) for s in ('Slice LUTs','Slice Registers','Block RAM Tile','DSPs')]
    area=lut/4+ff/8+bram*232.4+dsp*102.4
    check(eq(area,ppa['equivalent_slice']),'area formula')
    clock=json.loads((folder/'final_clock.json').read_text());period=clock['period_ns']
    check(eq(period*10,round(period*10)) and clock['wns_ns']>=.0999 and clock['whs_ns']>=0,'clock margin')
    check(eq(period,ppa['period_ns']),'common clock')
    timing=(folder/'timing_summary.rpt').read_text();row=re.search(r'WNS\(ns\).*?\n\s*[- ]+\n([^\n]+)',timing).group(1).split()
    check(all(float(row[i])>=0 for i in (0,4,8)) and all(float(row[i])==0 for i in (1,5,9)),'setup/hold/pulse')
    route=(folder/'route_status.rpt').read_text()
    for label in ('Number of nets with routing errors','Number of unrouted nets'):
        m=re.search(re.escape(label)+r'\s*:\s*(\d+)',route);check(m and int(m[1])==0,label)
    coverage=(folder/'check_timing.rpt').read_text()
    for label in ('no_clock','constant_clock','multiple_clock','unconstrained_internal_endpoints','loops','latch_loops'):
        m=re.search(r'checking '+label+r' \((\d+)\)',coverage);check(m and int(m[1])==0,'coverage '+label)
    old=json.loads((ROOT/'manifests/experiments/unified_hbs_final.json').read_text())['profiles']
    ceilings={a:old[b]['sign_atp'] for a,b in [('slh_128f','slh'),('xmss_omega4','xmss'),('lms_omega4','lms')]}
    structural=set();binaries=set()
    for name,p in PROFILES.items():
        data=ppa['profiles'][name];sim_path=ROOT/data['simulation'];sim=json.loads(sim_path.read_text())
        check(sha(sim_path)==data['simulation_sha256'] and sha(sim_path.with_suffix('.log'))==sim['log_sha256'],'simulation digest '+name)
        check(sim['passed'] and sim['logic_sha256']==inputs['logic_sha256'],'simulation hardware '+name)
        binaries.add(sim['binary_sha256'])
        for kind in ('keygen','sign'):check(sim[kind+'_hashes']==images[name][kind+'_hashes'] and sim[kind+'_permutations']==images[name][kind+'_permutations'],'hash counts '+name)
        atp=area*sim['sign_cycles']*period/1e6
        check(eq(atp,data['sign_atp']) and atp<p.target,'paper ATP '+name)
        check(name not in ceilings or atp<=ceilings[name],'V3 regression '+name)
        futil=(folder/'frozen'/(name+'_utilization.rpt')).read_text()
        check(all(resource(util,k)==resource(futil,k) for k in ('Slice LUTs','Slice Registers','LUT as Memory','Block RAM Tile','DSPs')),'identical area '+name)
        expected=mapping(name)
        rows=dict(line.split('\t') for line in (folder/'frozen'/(name+'_init.tsv')).read_text().splitlines())
        check(set(rows)==set(expected),'ROM cells '+name)
        check(all(int(rows[k].split("'h")[1],16)==int(v.split("'h")[1],16) for k,v in expected.items()),'physical INIT '+name)
        structural.add(final['hardware_sha256'][name])
        print(f'{name:14s} common_area={area:.3f} MHz={1000/period:.3f} KG={sim["keygen_cycles"]:,} Sign={sim["sign_cycles"]:,} ATP={atp:,.3f} PASS')
    check(len(structural)==1 and len(binaries)==1,'same hardware/netlist/simulation binary')
    check(next(iter(structural))==sha(folder/'frozen/hardware.txt'),'frozen structure digest')
    check(final['functional_pass'] and final['performance_pass'],'final acceptance flags')
    print('V4.1 seven-profile common-hardware acceptance: PASS')
    return 0
if __name__=='__main__':sys.exit(main())
