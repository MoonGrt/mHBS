#!/usr/bin/env python3
"""Compare final-cycle rows against the frozen structural implementation."""
import sys,json
import run_lu_p1 as m
label=sys.argv[1];records=[]
for l,u in m.POINTS:
 f=m.OUT/label/f'L{l}U{u}_simulation_s1_x0.json'
 rows=json.loads(f.read_text())
 for r in rows:
  baseline=m.OUT/'structure_initial'/f'L{l}U{u}_simulation_s1_x0.json'
  if (l,u) not in m.REPS:baseline=m.OUT/'structure'/f'L{l}U{u}_simulation_s1_x0.json'
  refs=json.loads(baseline.read_text());ref=next((x for x in refs if (x['profile'],x['op'])==(r['profile'],r['op'])),None)
  if ref is None:continue
  for k in ('cycles','total','hashes','permutations'):assert r[k]==ref[k],(l,u,r['profile'],r['op'],k,r[k],ref[k])
  records.append(dict(lanes=l,unroll=u,profile=r['profile'],op=r['op'],cycles=r['cycles'],passed=True))
m.write(m.OUT/label/'cycle_comparison.json',dict(passed=True,cases=len(records),rows=records));print('CYCLE_COMPARISON_PASS',len(records))
