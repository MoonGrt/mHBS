#!/usr/bin/env python3
"""Report frozen measured L/U runs; never fill missing measurements from history."""
import argparse,csv,json
import run_lu_p1 as m

def rows(label):
 data=[]
 for l,u in m.POINTS:
  p=m.OUT/label/f'L{l}U{u}'/'synthesis.json';q=m.OUT/label/f'L{l}U{u}_simulation_s1_x0.json'
  if not p.exists() or not q.exists():continue
  sim=next(x for x in json.loads(q.read_text()) if x['profile']=='slh_128f' and x['op']==1)
  area=json.loads(p.read_text())['area'];freq=150 if u==1 else 110
  data.append(dict(configuration=f'L{l}U{u}',lanes=l,unroll=u,**area,cycles=sim['cycles'],total_cycles=sim['total'],hashes=sim['hashes'],permutations=sim['permutations'],utilization=sim['permutations']*24/(l*u*sim['cycles']),assumed_mhz=freq,time_ms=sim['cycles']/(freq*1000),atp=area['equivalent_slice']*sim['cycles']/(freq*1000),fits_device=area['lut']<=133800 and area['ff']<=267600,evidence=str(p.parent.relative_to(m.ROOT))))
 return data

def compare(base,candidate):
 b={x['configuration']:x for x in rows(base)};c={x['configuration']:x for x in rows(candidate)}
 failures=[];strict=False
 if len(b)!=14 or len(c)!=14:failures.append('incomplete 14-point measurements')
 for key in b.keys()&c.keys():
  for field in ('lut','equivalent_slice','cycles'):
   if c[key][field]>b[key][field]:failures.append(f'{key}: {field} {b[key][field]} -> {c[key][field]}')
  strict|=c[key]['equivalent_slice']<b[key]['equivalent_slice']
 if not strict:failures.append('no strict equivalent-Slice improvement')
 result=dict(baseline=base,candidate=candidate,area_cycle_gate=not failures,failures=failures,full_verification_required=True)
 m.write(m.OUT/candidate/'comparison.json',result);return result

def report(label):
 data=rows(label);dest=m.ROOT/'docs/report/LU_P1_Optimization';dest.parent.mkdir(exist_ok=True)
 with dest.with_suffix('.csv').open('w') as f:
  if data:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
 m.write(dest.with_suffix('.json'),dict(label=label,clock_ns=10,part='xc7a200tffg1156-3',routing=False,frequency_assumed=True,rows=data))
 text=['# L/U：删除 P 流水支持与面积优化','','P 固定为 1，默认 L2U2；保留十参数及 Keygen/Sign/Verify。性能数据仅为 128f Sign。','',f'当前测量快照：`{label}`，已完成 {len(data)}/14 组。', '', '共同核 OOC 综合：xc7a200tffg1156-3、10 ns、统计关闭。等效 Slice = LUT/4 + FF/8 + BRAM×232.4 + DSP×102.4；LUT 包含 LUTRAM，后者不重复计数。','', '**U1 的 150 MHz、U2 的 110 MHz 均为假定值，未经布线验证。** ATP 仅供参考，不替代逐配置面积与周期验收。','', '有效轮利用率 = 置换数×24 / (L×U×计算周期)。','', '|配置|LUT|FF|LUTRAM|BRAM|DSP|等效 Slice|计算周期|总周期|Hash|置换|利用率|假定 MHz|时间 ms|ATP|器件容量|','|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|']
 for r in data:
  text.append('|'+ '|'.join([r['configuration'],*[str(int(r[x])) for x in ('lut','ff','lutram')],str(r['bram']),str(r['dsp']),f"{r['equivalent_slice']:.3f}",*[str(r[x]) for x in ('cycles','total_cycles','hashes','permutations')],f"{r['utilization']:.2%}",str(r['assumed_mhz']),f"{r['time_ms']:.4f}",f"{r['atp']:.3f}",'可容纳' if r['fits_device'] else '超资源'])+'|')
 text+=['','分层报告：`manifests/experiments/lu_p1_20261012/<候选>/LxUy/core_hierarchical.rpt`。','', '原始基线、结构基线、独立候选的源码快照、补丁、完整日志及比较 JSON 保存在同一实验目录。']
 dest.with_suffix('.md').write_text('\n'.join(text)+'\n')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('--base');a=p.parse_args()
 if a.base:print(json.dumps(compare(a.base,a.label),indent=2))
 report(a.label)
