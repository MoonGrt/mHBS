# mHBS 当前 Job 与流接口

唯一生产顶层为 `rtl/top/mhbs_top.sv`。支持 SLH-DSA SHAKE 128f、192f、256f、128s、192s、256s，以及实验 `xmss_omega2/4`、`lms_omega2/4`；每次复位执行一次 Keygen、Sign 或 Verify。

## 配置

`OPERATION=0/1/2` 分别选择 Keygen/Sign/Verify。`SECRET_SEED`、`SECRET_PRF`、`PUBLIC_SEED`、`RANDOMIZER`、`PUBLIC_ROOT` 为五个 256 位综合参数，分别使用低 128/192/256 位；首字节位于低 8 位。默认值来自 128f 测试向量。切换参数集须同时使用对应镜像和 Job 参数。Sign/Verify 的公钥根由调用方提供。Verify 只使用 PUBLIC_SEED、PUBLIC_ROOT，并沿用对应参数集的 sign 镜像。

ROM 路径使用 `PROGRAM_INIT_FILE`、`TEMPLATE_INIT_FILE`、`DESCRIPTOR_INIT_FILE` 参数指定。顶层没有运行时 Job 写入、start 或输出背压端口。

## 端口协议

| 端口 | 语义 |
|---|---|
| `clk` / `rst` | 时钟；高有效同步复位，至少覆盖一个上升沿 |
| `message_length[6:0]` | Keygen 为 0；Sign/Verify 为 1–87，在内部 Job 接受时锁存 |
| `message_data[63:0]` | 低字节先传，尾拍多余字节忽略 |
| `message_valid` / `message_ready` | 上升沿两者同时为 1 时接收一拍；等待 ready 时保持 valid 和 data |
| `out_valid` / `out_data[255:0]` | 每个有效拍直接输出一个完整节点，无 out_ready；接收方必须及时接收 |
| `out_bytes[5:0]` | 有效低位字节数（4/16/24/32），按低字节到高字节拼接；未用高位忽略 |
| `result_kind[1:0]` | 0 为 Keygen 的 SK\|\|PK；1 为签名；2 为 Verify |
| `busy` | 复位时置 1，完成或错误时清零 |
| `done` | 整项结果输出结束后保持为 1，直到复位；不再提供 out_last/out_keep |
| `keygen_done` | Keygen 完成单周期脉冲 |
| `error` / `error_code[15:0]` | 错误状态保持到复位，错误操作不产生 done |
| `boot_cycles` | header/profile 读取计数，正常为 2 |
| `keygen_cycles` / `sign_cycles` | 完成时锁存对应操作周期，未执行的操作为 0；包含消息等待 |
| `hash_count` / `permutation_count` | 当前操作的 Hash / Keccak 置换次数 |

在复位释放前设置好 message_length。Sign 可将长度保持到首次 message_ready，再开始发送消息；Keygen 保持 0 即可。消息没有 last/keep 输入，接收长度只由锁存的 message_length 决定。Keygen、消息接收结束、完成和错误停机阶段，message_ready 均为 0。

同步复位可以中断运行；重新释放复位后从头执行。顶层不自动将 Keygen 根接入随后一次 Sign，也不在完成后自动接受下一项任务。

错误码 `0x3002` 表示消息长度非法，`0x3006` 表示宏操作错误，`0x3007` 表示 Hash lane 错误。镜像的全面合法性检查由软件生成阶段完成。

验证命令及验收边界见 [Verification.md](Verification.md)。

## 完整签名缓存与读回

`SIGNATURE_STORE_ENABLE=1`（默认）且 `OPERATION=1` 时，顶层自动保存全部签名输出。
缓存位于共同核之外，不改变原输出流、计算周期或微码。Keygen、Verify 或显式关闭该参数时，
缓存不实例化，下面所有输出恒为零。新增输入不用时接零。

| 端口 | 语义 |
|---|---|
| `signature_valid` | `done=1` 且签名缓存无错误时为 1；保持至复位 |
| `signature_length[15:0]` | 已保存的有效字节总数；签名完成后使用 |
| `signature_nodes[10:0]` | 已保存节点数；签名完成后使用 |
| `signature_node_bytes[5:0]` | 常规节点宽度，16/24/32；混合字段读回使用 signature_read_bytes |
| `signature_read_enable` / `signature_read_address[10:0]` | 同步读请求，地址为节点索引，从 0 开始 |
| `signature_read_valid` / `signature_read_data[255:0]` | 请求采样上升沿之后返回数据及有效标志；可每拍请求一个节点，无响应背压 |
| `signature_read_bytes[5:0]` | 与 read_valid/data 同拍返回本项有效字节数，4/16/24/32 |
| `signature_error` | 缓存溢出、节点宽度非法/不一致或执行错误；保持至复位 |

只有 `signature_valid=1` 且地址小于 `signature_nodes` 的请求产生读响应；其余请求的
`signature_read_valid=0`。读数据仅在 valid 为 1 时有意义，未使用高位忽略。
按地址递增，将每节点的低 `signature_read_bytes` 字节按低字节在先拼接，即为完整签名。
缓存可重复随机读取，读操作不影响 `done` 或原输出。缓存错误不改变原核心 `error`，调用方
须检查 `signature_valid` 和 `signature_error` 后再使用缓存。

存储为 1558 × 256 bit，同一存储覆盖全部六参数，最长签名为 256f 的 49,856 字节。
128/192 位节点在 256 位槽中留空高位，以省去打包逻辑。存储拆为 1024 项 BRAM、512 项 BRAM
和 22 项 LUTRAM 尾区，统一为同步读接口，不复位 RAM 内容；
同步复位清除计数与有效状态，因此运行中复位会丢弃本次签名，旧 RAM 内容不可读回。
本模块用于功能性保存，不提供物理存储擦除。历史共同核的 0 BRAM 面积不包含此顶层缓存。

## 仿真统计与综合裁剪

`PROFILE_ENABLE` 在仿真默认开启，在定义 `SYNTHESIS` 时默认关闭；生产共同核综合也显式设置为 0。关闭后 `boot_cycles`、`keygen_cycles`、`sign_cycles`、`hash_count` 和 `permutation_count` 保留端口但恒为零，内部计数寄存器、基准寄存器及统计加减逻辑裁除。此开关不影响签名/公钥输出、握手、错误处理和完成周期。仿真 testbench 另从实际完成的 permutation 和 hash 事件观察统计，用于检查两种配置行为一致。

## Verify 节点接口

新增 `verify_valid`、`verify_ready`、`verify_data[255:0]` 和 `verify_pass`。仅 `OPERATION=2` 使用。每拍在上升沿 valid 和 ready 同时为 1 时接受一个 n 字节节点，放在 data 低位、低字节在先；高位忽略。等待 ready 时必须保持 valid/data。Keygen/Sign 将新增输入接零即可。

调用方负责将签名拆成节点并检查原始签名长度，依次提供：R；每棵 FORS 树的签名秘密节点和 a 个认证节点；每层 XMSS 的 len 个 WOTS 签名节点和 h′ 个认证节点。认证节点按从叶到根顺序提供。内核根据原 sign 微码发出 ready，不接收类型标签、字节流帧或中间计算结果。消息继续使用原消息接口，可以先完成消息传输再供应节点。

Verify 不输出 out 数据流。done=1、error=0 时读取 verify_pass：1 为根匹配，0 为签名不匹配；不匹配不是协议或执行故障。done/verify_pass 保持到复位。节点供应不足时等待输入，不把停顿判成无效签名；完成后的额外节点不被接受。完整签名字节流的长度及分帧检查由外部负责。

Verify 的 keygen_cycles、sign_cycles 保持零；仿真可观察共同核 cycles，hash/permutation 统计沿用 PROFILE_ENABLE。生产统计仍关闭。消息范围和每次复位一项操作的约束不变。

## XMSS/LMS 的 q 与标识符

`KEY_INDEX[31:0]`、`IDENTIFIER[127:0]` 是新增顶层参数，默认零；共同核分别通过 `job_index`、`job_identifier` 接收。q 为数值 0–1023，超界在执行前报 `0x3008`；标识符按低字节在先表示 16 字节 LMS I。XMSS 忽略 identifier。Keygen 的根与 q 无关，输出的私钥索引字段使用所给 q。

签名前调用方必须持久化占用 q，禁止同一私钥重复使用；复位仅重启硬件，不恢复可用索引。Verify 不消耗索引。核不实现索引分配或持久化。

所有新参数使用 32 字节节点、h=10 和实验 SHAKE256 配方。Sign 格式：

- XMSS：`q[4] || R[32] || WOTS 签名[133/67 × 32] || auth[10 × 32]`，共 4612/2500 字节。
- LMS：`q[4] || OTS_type[4] || R[32] || LMOTS 签名[133/67 × 32] || tree_type[4] || auth[10 × 32]`，共 4620/2508 字节。

四字节字段按大端字节串输出，线上仍从 out_data 低字节开始读取。LMS 私有类型为 omega2 `0x80000002`、omega4 `0x80000003`、树 `0x80000006`；不是标准 RFC 类型号。

Verify 的外部适配器先用 `model.reference.stateful_shake.parse_signature` 校验精确长度、q 和 LMS 类型，再把 q 放入 KEY_INDEX、I 放入 IDENTIFIER。节点接口只输入 R、133/67 个链节点和 10 个认证节点；q、类型字段不作为节点发送。消息继续使用原接口，根通过 PUBLIC_ROOT 输入。核恢复实际根并比较，不接收预计算叶或中间根。不足节点会等待，额外节点不被接收。

Sign 输出的 4 字节字段各占一个缓存槽，容量仍为 1558 项。以每项 signature_read_bytes 拼接可还原完整签名；SLH 每项长度仍等于 signature_node_bytes。Sign 包含完整认证树重算，不可按旧模型缓存命中的 Sign 周期估算。


## L/U 配置

当前版本固定 P=1，删除 `PIPELINE` 参数。仅保留 `LANES/UNROLL`：默认 L2U2；U1 支持 L1/2/3/4/6/8/12/24，U2 支持 L1/2/3/4/6/12。外部 Job、消息、签名缓存和 Verify 节点接口不变。物理 lane 交换仍可用于验证，逻辑 lane0 始终承担消息、列表和父节点计算。
