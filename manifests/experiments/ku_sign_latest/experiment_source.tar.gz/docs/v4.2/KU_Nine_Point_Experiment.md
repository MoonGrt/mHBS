# K/U 九点实验

设备 `xc7a200tffg1156-3`；Vivado 2025.2。九点使用同一参数化源码、Program16 镜像和六组软件向量。
参数化 RTL 位于独立 worktree，生产 RTL 未替换。

## 共同核综合与计算周期

等效 Slice = LUT/4 + FF/8 + BRAM36×232.4 + DSP×102.4。周期列顺序为 128f Keygen、128f Sign、192f Keygen、192f Sign、256f Keygen、256f Sign。

| K/U | LUT | FF | LUTRAM | 等效 Slice | 六组周期 | Pareto | 综合状态 |
|---|---:|---:|---:|---:|---|---|---|
| K1U1 | 12645 | 6565 | 1112 | 3981.875 | 111114 / 2619719 / 162634 / 4289907 / 429578 / 8818804 | 是 | 通过 |
| K1U2 | 14970 | 6565 | 1112 | 4563.125 | 56790 / 1352027 / 83254 / 2244363 / 220310 / 4621708 | 是 | 通过 |
| K1U4 | 19423 | 6559 | 1112 | 5675.625 | 29628 / 718181 / 43564 / 1221591 / 115676 / 2523160 | 是 | 通过 |
| K2U1 | 17548 | 8789 | 1112 | 5485.625 | 58074 / 1399919 / 84634 / 2351907 / 223658 / 4841476 | 否 | 通过 |
| K2U2 | 21879 | 8787 | 1112 | 6568.125 | 29862 / 729983 / 43654 / 1249491 / 115766 / 2579236 | 否 | 通过 |
| K2U4 | 30610 | 8795 | 1112 | 8751.875 | 15756 / 395015 / 23164 / 698283 / 61820 / 1448116 | 是 | 通过 |
| K4U1 | 25873 | 13195 | 1116 | 8117.625 | 29994 / 755063 / 44074 / 1347579 / 117578 / 2798116 | 否 | 通过 |
| K4U2 | 34527 | 13191 | 1116 | 10280.625 | 15606 / 401219 / 23062 / 734127 / 61910 / 1530244 | 是 | 通过 |
| K4U4 | 51794 | 13182 | 1116 | 14596.250 | 8412 / 224297 / 12556 / 427401 / 34076 / 896308 | 是 | 通过 |

Pareto 判定使用等效 Slice 与全部六组周期；各指标均不差且至少一项更优才构成支配。
进入布线：K1U1, K1U2, K1U4, K2U2, K2U4, K4U2, K4U4。

## Program16 K2U2 对照

封存基线共同核：20857 LUT、8786 FF、1112 LUTRAM、6312.500 等效 Slice。
参数化 K2U2 改造本身增加 1022 LUT、1 FF、255.625 等效 Slice；六组输出、周期、Hash 次数和置换次数一致。

## 六组外壳布线

全部入选点采用统一 20 ns 初始周期，外部接口路径从布局布线开始排除；完成后在 0.1 ns 网格上按至少 0.1 ns 建立裕量重新分析核内频率。外部接口未签核。面积时间积采用各外壳布线后等效 Slice × 计算延迟（ms）。
先前 10 ns 作业的有效结果及被中断的拥塞日志保留在 `initial10ns_route/`，不混入本表。

| K/U | 外壳 | 核内 MHz | 等效 Slice | 周期 | 面积时间积 (Slice·ms) | 状态 |
|---|---|---:|---:|---:|---:|---|
| K1U1 | slh_128f_keygen | — | — | — | — | INFO: [Place 46-56] BUFG insertion identified 0 candidate nets. Inserted BUFG: 0, Replicated BUFG Driver: 0, Skipped due to Placement/Routing Conflicts: 0, Skipped due to Timing Degradation: 0, Skipped due to netlist editing failed: 0. |
| K1U1 | slh_128f_sign | — | — | — | — | INFO: [Place 46-56] BUFG insertion identified 0 candidate nets. Inserted BUFG: 0, Replicated BUFG Driver: 0, Skipped due to Placement/Routing Conflicts: 0, Skipped due to Timing Degradation: 0, Skipped due to netlist editing failed: 0. |
| K1U1 | slh_192f_keygen | — | — | — | — | INFO: [Place 46-56] BUFG insertion identified 0 candidate nets. Inserted BUFG: 0, Replicated BUFG Driver: 0, Skipped due to Placement/Routing Conflicts: 0, Skipped due to Timing Degradation: 0, Skipped due to netlist editing failed: 0. |
| K1U1 | slh_192f_sign | — | — | — | — | INFO: [Place 46-56] BUFG insertion identified 0 candidate nets. Inserted BUFG: 0, Replicated BUFG Driver: 0, Skipped due to Placement/Routing Conflicts: 0, Skipped due to Timing Degradation: 0, Skipped due to netlist editing failed: 0. |
| K1U1 | slh_256f_keygen | — | — | — | — | INFO: [Place 46-56] BUFG insertion identified 0 candidate nets. Inserted BUFG: 0, Replicated BUFG Driver: 0, Skipped due to Placement/Routing Conflicts: 0, Skipped due to Timing Degradation: 0, Skipped due to netlist editing failed: 0. |
| K1U1 | slh_256f_sign | — | — | — | — | INFO: [Place 46-56] BUFG insertion identified 0 candidate nets. Inserted BUFG: 0, Replicated BUFG Driver: 0, Skipped due to Placement/Routing Conflicts: 0, Skipped due to Timing Degradation: 0, Skipped due to netlist editing failed: 0. |
| K1U2 | slh_128f_keygen | — | — | — | — | required result file is absent |
| K1U2 | slh_128f_sign | — | — | — | — | required result file is absent |
| K1U2 | slh_192f_keygen | — | — | — | — | required result file is absent |
| K1U2 | slh_192f_sign | — | — | — | — | required result file is absent |
| K1U2 | slh_256f_keygen | — | — | — | — | required result file is absent |
| K1U2 | slh_256f_sign | — | — | — | — | required result file is absent |
| K1U4 | slh_128f_keygen | — | — | — | — | required result file is absent |
| K1U4 | slh_128f_sign | — | — | — | — | required result file is absent |
| K1U4 | slh_192f_keygen | — | — | — | — | required result file is absent |
| K1U4 | slh_192f_sign | — | — | — | — | required result file is absent |
| K1U4 | slh_256f_keygen | — | — | — | — | required result file is absent |
| K1U4 | slh_256f_sign | — | — | — | — | required result file is absent |
| K2U2 | slh_128f_keygen | — | — | — | — | required result file is absent |
| K2U2 | slh_128f_sign | — | — | — | — | required result file is absent |
| K2U2 | slh_192f_keygen | — | — | — | — | required result file is absent |
| K2U2 | slh_192f_sign | — | — | — | — | required result file is absent |
| K2U2 | slh_256f_keygen | — | — | — | — | required result file is absent |
| K2U2 | slh_256f_sign | — | — | — | — | required result file is absent |
| K2U4 | slh_128f_keygen | — | — | — | — | required result file is absent |
| K2U4 | slh_128f_sign | — | — | — | — | required result file is absent |
| K2U4 | slh_192f_keygen | — | — | — | — | required result file is absent |
| K2U4 | slh_192f_sign | — | — | — | — | required result file is absent |
| K2U4 | slh_256f_keygen | — | — | — | — | required result file is absent |
| K2U4 | slh_256f_sign | — | — | — | — | required result file is absent |
| K4U2 | slh_128f_keygen | — | — | — | — | required result file is absent |
| K4U2 | slh_128f_sign | — | — | — | — | required result file is absent |
| K4U2 | slh_192f_keygen | — | — | — | — | required result file is absent |
| K4U2 | slh_192f_sign | — | — | — | — | required result file is absent |
| K4U2 | slh_256f_keygen | — | — | — | — | required result file is absent |
| K4U2 | slh_256f_sign | — | — | — | — | required result file is absent |
| K4U4 | slh_128f_keygen | — | — | — | — | required result file is absent |
| K4U4 | slh_128f_sign | — | — | — | — | required result file is absent |
| K4U4 | slh_192f_keygen | — | — | — | — | required result file is absent |
| K4U4 | slh_192f_sign | — | — | — | — | required result file is absent |
| K4U4 | slh_256f_keygen | — | — | — | — | required result file is absent |
| K4U4 | slh_256f_sign | — | — | — | — | required result file is absent |

## 验证与证据

U1/U2/U4 的 Keccak 单元向量通过。九点的六组输出哈希、Hash 次数和置换次数一致；每点三组 Verify 正常路径通过。K2U2 还通过 65 个 Verify、33 个扩展、统计关闭、复位与故障回归；K1U2/K4U2 的 Verify 复位、停顿、填充、坏消息和统计关闭检查通过。四路端点存储同拍写入与两路读取单元检查通过。
每点的源码快照、参数、仿真日志、综合资源、布线报告和 SHA-256 清单见 `manifests/experiments/ku_matrix_20260927_v1/candidates/`。DCP 保留在该独立 worktree 的 `build/v4.2/external_job_message/`，哈希列入结果文件。

## 失败原因

- K1U1 slh_128f_keygen: INFO: [Place 46-56] BUFG insertion identified 0 candidate nets. Inserted BUFG: 0, Replicated BUFG Driver: 0, Skipped due to Placement/Routing Conflicts: 0, Skipped due to Timing Degradation: 0, Skipped due to netlist editing failed: 0.
- K1U1 slh_128f_sign: INFO: [Place 46-56] BUFG insertion identified 0 candidate nets. Inserted BUFG: 0, Replicated BUFG Driver: 0, Skipped due to Placement/Routing Conflicts: 0, Skipped due to Timing Degradation: 0, Skipped due to netlist editing failed: 0.
- K1U1 slh_192f_keygen: INFO: [Place 46-56] BUFG insertion identified 0 candidate nets. Inserted BUFG: 0, Replicated BUFG Driver: 0, Skipped due to Placement/Routing Conflicts: 0, Skipped due to Timing Degradation: 0, Skipped due to netlist editing failed: 0.
- K1U1 slh_192f_sign: INFO: [Place 46-56] BUFG insertion identified 0 candidate nets. Inserted BUFG: 0, Replicated BUFG Driver: 0, Skipped due to Placement/Routing Conflicts: 0, Skipped due to Timing Degradation: 0, Skipped due to netlist editing failed: 0.
- K1U1 slh_256f_keygen: INFO: [Place 46-56] BUFG insertion identified 0 candidate nets. Inserted BUFG: 0, Replicated BUFG Driver: 0, Skipped due to Placement/Routing Conflicts: 0, Skipped due to Timing Degradation: 0, Skipped due to netlist editing failed: 0.
- K1U1 slh_256f_sign: INFO: [Place 46-56] BUFG insertion identified 0 candidate nets. Inserted BUFG: 0, Replicated BUFG Driver: 0, Skipped due to Placement/Routing Conflicts: 0, Skipped due to Timing Degradation: 0, Skipped due to netlist editing failed: 0.
- K1U2 slh_128f_keygen: required result file is absent
- K1U2 slh_128f_sign: required result file is absent
- K1U2 slh_192f_keygen: required result file is absent
- K1U2 slh_192f_sign: required result file is absent
- K1U2 slh_256f_keygen: required result file is absent
- K1U2 slh_256f_sign: required result file is absent
- K1U4 slh_128f_keygen: required result file is absent
- K1U4 slh_128f_sign: required result file is absent
- K1U4 slh_192f_keygen: required result file is absent
- K1U4 slh_192f_sign: required result file is absent
- K1U4 slh_256f_keygen: required result file is absent
- K1U4 slh_256f_sign: required result file is absent
- K2U2 slh_128f_keygen: required result file is absent
- K2U2 slh_128f_sign: required result file is absent
- K2U2 slh_192f_keygen: required result file is absent
- K2U2 slh_192f_sign: required result file is absent
- K2U2 slh_256f_keygen: required result file is absent
- K2U2 slh_256f_sign: required result file is absent
- K2U4 slh_128f_keygen: required result file is absent
- K2U4 slh_128f_sign: required result file is absent
- K2U4 slh_192f_keygen: required result file is absent
- K2U4 slh_192f_sign: required result file is absent
- K2U4 slh_256f_keygen: required result file is absent
- K2U4 slh_256f_sign: required result file is absent
- K4U2 slh_128f_keygen: required result file is absent
- K4U2 slh_128f_sign: required result file is absent
- K4U2 slh_192f_keygen: required result file is absent
- K4U2 slh_192f_sign: required result file is absent
- K4U2 slh_256f_keygen: required result file is absent
- K4U2 slh_256f_sign: required result file is absent
- K4U4 slh_128f_keygen: required result file is absent
- K4U4 slh_128f_sign: required result file is absent
- K4U4 slh_192f_keygen: required result file is absent
- K4U4 slh_192f_sign: required result file is absent
- K4U4 slh_256f_keygen: required result file is absent
- K4U4 slh_256f_sign: required result file is absent
