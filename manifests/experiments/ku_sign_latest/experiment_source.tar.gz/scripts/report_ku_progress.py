#!/usr/bin/env python3
"""Render a timestamped K/U progress report from completed measurements only."""
import argparse
import csv
import hashlib
import json
import re
import subprocess
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from v42_external_flow import BASE, BUILD, NAMES, ROOT
from v42_external_route import resources

POINTS = [(k, u) for k in (1, 2, 4) for u in (1, 2, 4)]
SHELLS = [f'{name}_{op}' for name in NAMES for op in ('keygen', 'sign')]
ROUTE_DIR = 'route_internal20_v1'
PREFIX = 'KU_Nine_Point_Progress'


def read(path):
    return json.loads(path.read_text())


def fmt(value, precision=3):
    if value is None:
        return '-'
    return f'{value:.{precision}f}' if isinstance(value, float) else str(value)


def resource_cell(area):
    return ' / '.join(fmt(area.get(key), 0) for key in ('lut', 'ff', 'lutram'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'docs/v4.2')
    args = parser.parse_args()
    generated = datetime.now(ZoneInfo('Asia/Singapore')).isoformat(timespec='seconds')
    processes = []
    for line in subprocess.check_output(['ps', '-eo', 'stat,args'], text=True).splitlines():
        parts = line.split(None, 1)
        if len(parts) == 2 and '/unwrapped/lnx64.o/vivado -mode batch' in parts[1]:
            processes.append(parts)
    baseline = BASE / 'candidates/program16_20260927_v1'
    baseline_sim = read(baseline / 'simulation.json')['cases']
    baseline_area = resources(baseline / 'synthesis/core_utilization.rpt')
    points = {}
    measured_sources = None
    evidence = {}

    def remember(path):
        evidence[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()

    for k, u in POINTS:
        label = f'K{k}U{u}'
        folder = BUILD / f'ku_k{k}u{u}_v2'
        inputs = read(folder / 'inputs.json')
        simulation = read(folder / 'simulation.json')
        assert simulation['passed'] and (inputs['lanes'], inputs['unroll']) == (k, u)
        if measured_sources is None:
            measured_sources = inputs['source_sha256']
        assert inputs['source_sha256'] == measured_sources
        core_path = folder / 'synthesis/core_utilization.rpt'
        area = resources(core_path)
        remember(core_path)
        remember(folder / 'inputs.json')
        remember(folder / 'simulation.json')
        points[label] = dict(lanes=k, unroll=u, area=area, inputs=inputs, simulation=simulation,
                             build_folder=str(folder), shells={})
    metrics = {label: [point['area']['equivalent_slice'], *[
        point['simulation']['cases'][shell][shell.rsplit('_', 1)[1] + '_cycles']
        for shell in SHELLS]] for label, point in points.items()}
    for label, metric in metrics.items():
        dominators = [other for other, value in metrics.items() if other != label
                      and all(a <= b for a, b in zip(value, metric))
                      and any(a < b for a, b in zip(value, metric))]
        points[label].update(pareto=not dominators, dominated_by=dominators,
                             route_selected=not dominators or label == 'K2U2')
    rows = []
    for label, point in points.items():
        folder = Path(point['build_folder'])
        for shell in SHELLS:
            profile, operation = shell.rsplit('_', 1)
            sim = point['simulation']['cases'][shell]
            ref = baseline_sim[shell]
            assert sim['passed'] and sim['output_sha256'] == ref['output_sha256']
            assert (sim['hashes'], sim['permutations']) == (ref['hashes'], ref['permutations'])
            synth_path = folder / 'synthesis' / shell / 'utilization.rpt'
            synthesis = resources(synth_path)
            remember(synth_path)
            rd = folder / ROUTE_DIR / shell
            route_path = rd / 'result.json'
            route = read(route_path) if route_path.exists() else {}
            failure = ''
            if not point['route_selected']:
                status = '未入选'
            elif route.get('passed'):
                assert route['core_timing_pass'] and route['wns_ns'] >= .0999 and route['whs_ns'] >= 0
                assert route['operation_cycles'] == sim[operation + '_cycles']
                status = '通过'
            elif route:
                status = '失败'
                log = (rd / 'route.log').read_text(errors='replace') if (rd / 'route.log').exists() else ''
                matches = re.findall(r'^ERROR: \[Route[^\n]+', log, re.M)
                failure = matches[0] if matches else route.get('failure', '未记录原因')
            elif any(str(rd) in command and not stat.startswith('T') for stat, command in processes):
                status = '运行中'
            elif any(str(rd) in command for stat, command in processes):
                status = '暂停'
            else:
                status = '待运行'
            if route_path.exists():
                remember(route_path)
            valid_route = route if status == '通过' else {}
            record = dict(point=label, profile=profile, operation=operation,
                          pareto=point['pareto'], route_selected=point['route_selected'],
                          simulation_pass=sim['passed'], synthesis_pass=True,
                          route_status=status, failure=failure,
                          compute_cycles=sim[operation + '_cycles'],
                          boot_cycles=sim['boot_cycles'], wait_cycles=sim['wait_cycles'],
                          total_cycles=sim['total_cycles'], hashes=sim['hashes'],
                          permutations=sim['permutations'], output_sha256=sim['output_sha256'])
            for prefix, values in [('core', point['area']), ('synth_shell', synthesis), ('route', valid_route)]:
                record.update({prefix + '_' + key: values.get(key) for key in
                               ('lut', 'ff', 'lutram', 'bram36', 'dsp', 'equivalent_slice')})
            record.update({key: valid_route.get(key) for key in
                           ('route_period_ns', 'route_wns_ns', 'period_ns', 'frequency_mhz',
                            'latency_ms', 'area_time_product', 'wns_ns', 'whs_ns', 'seconds')})
            record['source_snapshot_sha256'] = point['inputs']['snapshot_sha256']
            record['route_result_path'] = str(route_path.relative_to(ROOT)) if route_path.exists() else None
            point['shells'][shell] = dict(synthesis=synthesis, route=route, status=status, failure=failure)
            rows.append(record)
    rows.sort(key=lambda row: (NAMES.index(row['profile']), row['operation'] != 'keygen'))
    counts = {status: sum(row['route_status'] == status for row in rows)
              for status in ('通过', '失败', '运行中', '暂停', '待运行', '未入选')}
    delta = {key: points['K2U2']['area'][key] - baseline_area[key]
             for key in ('lut', 'ff', 'lutram', 'equivalent_slice')}
    for shell in SHELLS:
        op = shell.rsplit('_', 1)[1]
        assert points['K2U2']['simulation']['cases'][shell][op + '_cycles'] == baseline_sim[shell][op + '_cycles']
    result = dict(generated_at=generated, device='xc7a200tffg1156-3', vivado='2025.2',
                  phase='interim', worktree=str(ROOT), route_directory=ROUTE_DIR,
                  counts=counts, pareto=[label for label, point in points.items() if point['pareto']],
                  baseline_area=baseline_area, k2u2_delta=delta, points=points, rows=rows,
                  source_evidence_sha256=evidence)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    output_json = args.output_dir / (PREFIX + '.json')
    output_json.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    with (args.output_dir / (PREFIX + '.csv')).open('w', newline='', encoding='utf-8-sig') as stream:
        fields = ['profile_operation', *[key for key in rows[0] if key not in ('profile', 'operation')]]
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            csv_row = {key: row[key] for key in fields if key != 'profile_operation'}
            csv_row['profile_operation'] = row['profile'].replace('slh_', '') + (' KG' if row['operation'] == 'keygen' else ' SG')
            writer.writerow({key: '-' if value is None or value == '' else value
                             for key, value in csv_row.items()})
    lines = ['# K/U 九点实验阶段报告', '', f'统计时间：{generated}。本报告为当前结果快照。', '',
             '## 实验目的', '',
             '测量 Hash lane 数 K∈{1,2,4} 与 Keccak 每拍轮数 U∈{1,2,4} 的九种组合，'
             '比较共同核面积、六组计算周期以及布线后的核内频率和面积时间积，确定面积与计算周期的 Pareto 前沿。'
             '以参数化 K2U2 对照封存 Program16 K2U2，单列参数化改造引入的变化。', '',
             '## 实验口径', '',
             '- 器件：`xc7a200tffg1156-3`；Vivado：2025.2。九点使用同一参数化源码、Program16 镜像和软件参考向量。',
             '- 六组任务：SLH-DSA SHAKE 128f、192f、256f 的 Keygen 与 Sign。所有输出与软件参考值比对。',
             '- 等效 Slice = LUT/4 + FF/8 + BRAM36×232.4 + DSP×102.4；LUTRAM 已包含在 LUT 内。',
             '- 布线采用统一 20 ns 初始时钟，核内路径受约束；外部输入／输出路径设为 false path，未签核。',
             '- 布线后按 0.1 ns 网格重新设置时钟周期，要求 Setup 余量 ≥ 0.1 ns、Hold ≥ 0；所列频率为该网表的重新分析结果。'
             '最终周期没有用于重新布局优化，且可以大于 20 ns，因此不表示固定 50 MHz 达标或全局最高频率。',
             '- 计算延迟（ms）= 计算周期 × 最终周期（ns）/10⁶；面积时间积 = 该外壳布线后等效 Slice × 计算延迟（ms）。',
             '- 布线仅针对六个 Pareto 点和 K2U2 对照，共 42 组。未完成、失败或未入选的布线数据均填 `-`，状态另列。',
             '- 实验位于独立工作区，生产 RTL 未替换；未改写历史，未推送。', '',
             '## 当前进度', '',
             f'九点共同核综合、54 组外壳综合和 54 组正常仿真均通过。统一布线：'
             f"{counts['通过']}/42 通过，{counts['失败']} 失败，{counts['运行中']} 运行中，"
             f"{counts['暂停']} 暂停，{counts['待运行']} 待运行。", '',
             '## 九点概览', '',
             '周期列按 Keygen / Sign 排列；面积来自共同核综合，频率与面积时间积见下方总表。', '',
             '| K/U | LUT | FF | LUTRAM | BRAM36 | DSP | 等效 Slice | 128f 周期 | 192f 周期 | 256f 周期 | Pareto | 布线通过/入选 |',
             '|---|---:|---:|---:|---:|---:|---:|---|---|---|---|---|']
    for label, point in points.items():
        area = point['area']
        cycles = [' / '.join(str(point['simulation']['cases'][name + '_' + op][op + '_cycles'])
                             for op in ('keygen', 'sign')) for name in NAMES]
        passed = sum(row['status'] == '通过' for row in point['shells'].values())
        lines.append('| ' + ' | '.join([label, *[fmt(area[key], 0) for key in ('lut', 'ff', 'lutram', 'bram36', 'dsp')],
                                        fmt(area['equivalent_slice']), *cycles,
                                        '是' if point['pareto'] else '否', f'{passed}/6' if point['route_selected'] else '未入选']) + ' |')
    lines += ['', '## 全部数据总表', '',
              '每行对应一个 K/U、参数集和操作，共 54 行；按 128f KG、128f SG、192f KG、192f SG、256f KG、256f SG 分组排列。资源列中的三个值为 **LUT / FF / LUTRAM**；'
              '所有已综合及有效布线结果的 BRAM36、DSP 均为 0。KG=Keygen，SG=Sign。',
              '周期为计算周期；启动、等待、总周期及全部独立资源列见同名 CSV；输出 SHA-256 和源文件证据见同名 JSON。', '',
              '| 参数集/操作 | K/U | 外壳综合 LUT/FF/LUTRAM | 综合等效 Slice | 周期 | Hash 次数 | 置换次数 | 布线 LUT/FF/LUTRAM | 布线等效 Slice | 最终周期 ns | 核内 MHz | 延迟 ms | 面积时间积 Slice·ms | Setup ns | Hold ns | 布线状态 |',
              '|---|---|---|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|---|']
    for row in rows:
        cells = [row['profile'].replace('slh_', '') + (' KG' if row['operation'] == 'keygen' else ' SG'), row['point'],
                 resource_cell({key: row['synth_shell_' + key] for key in ('lut', 'ff', 'lutram')}),
                 fmt(row['synth_shell_equivalent_slice']), str(row['compute_cycles']), str(row['hashes']), str(row['permutations']),
                 resource_cell({key: row['route_' + key] for key in ('lut', 'ff', 'lutram')}) if row['route_status'] == '通过' else '-',
                 *[fmt(row[key]) for key in ('route_equivalent_slice', 'period_ns', 'frequency_mhz', 'latency_ms',
                                             'area_time_product', 'wns_ns', 'whs_ns')], row['route_status']]
        lines.append('| ' + ' | '.join(cells) + ' |')
    lines += ['', '## Pareto 与基线对照', '',
              '支配规则：共同核等效面积及六组计算周期全部不差，且至少一项更优。', '',
              '- Pareto 点：' + '、'.join(result['pareto']) + '。',
              '- 布线点：Pareto 点及 K2U2 对照。',
              f"- Program16 K2U2：LUT {baseline_area['lut']:.0f}、FF {baseline_area['ff']:.0f}、"
              f"LUTRAM {baseline_area['lutram']:.0f}、等效 Slice {baseline_area['equivalent_slice']:.3f}。",
              f"- 参数化 K2U2 增加 LUT {delta['lut']:.0f}、FF {delta['ff']:.0f}、LUTRAM {delta['lutram']:.0f}、"
              f"等效 Slice {delta['equivalent_slice']:.3f}（{100 * delta['equivalent_slice'] / baseline_area['equivalent_slice']:.2f}%）。",
              '- 参数化 K2U2 的六组输出、计算周期、Hash 次数和置换次数与 Program16 基线一致。', '',
              '## 验证记录', '',
              '- Keccak U1/U2/U4 单元检查和四路端点并行写入／双路读取检查通过。',
              '- 九点六组输出与软件参考值一致；每点三组 Verify 正常路径通过。',
              '- K2U2 的 65 个 Verify、33 个扩展及统计关闭、复位、故障回归通过。',
              '- K1U2/K4U2 的 Verify 复位、停顿、填充、坏消息与统计关闭检查通过。', '',
              '## 失败与未完成项', '']
    for row in rows:
        if row['route_selected'] and row['route_status'] != '通过':
            lines.append(f"- {row['point']} {row['profile']} {row['operation']}：{row['route_status']}"
                         + (f"；{row['failure']}" if row['failure'] else '') + '。')
    if not any(row['route_selected'] and row['route_status'] != '通过' for row in rows):
        lines.append('全部入选任务已通过。')
    lines += ['', '## 数据与复现', '',
              f'- [完整总表 CSV]({PREFIX}.csv)：54 行，包含资源、启动／等待／总周期、计算次数、'
              '初始时钟余量、最终时序、延迟、面积时间积和已完成布线耗时；缺失值为 `-`。',
              f'- [结果与证据 JSON]({PREFIX}.json)：当前快照、原始测量记录、输出／源码哈希及读取文件的 SHA-256。',
              f'- 工作区：`{ROOT}`。',
              f'- 布线证据：`build/v4.2/external_job_message/ku_k<K>u<U>_v2/{ROUTE_DIR}/`。',
              '- 原始 10 ns 作业及布置策略试跑属于其他流程，本报告使用统一 20 ns 流程结果。',
              f'- 更新：在该工作区运行 `python3 scripts/report_ku_progress.py --output-dir "{args.output_dir.resolve()}"`。', '']
    report = args.output_dir / (PREFIX + '.md')
    report.write_text('\n'.join(lines))
    assert len(rows) == 54 and sum(counts[key] for key in counts if key != '未入选') == 42
    print(json.dumps(dict(report=str(report.resolve()), generated_at=generated, counts=counts), ensure_ascii=False))


if __name__ == '__main__':
    main()
