"""Exercise durable search/resume and child cancellation without FPGA tool runs."""
import copy
import json
from pathlib import Path
import sys
import subprocess
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import sign_timing_scan as scan


class SearchTests(unittest.TestCase):
    def test_scaled_grid_and_nonmonotonic_recovery(self):
        self.assertEqual(scan.coarse(2), [200, 150, 125, 100, 80, 64])
        self.assertEqual(scan.coarse(3), [300, 225, 188, 150, 120, 96])
        search = scan.new_search()
        scan.advance(search, 2, 200, 'coarse', True)
        scan.advance(search, 2, 150, 'coarse', False)
        self.assertEqual(scan.request(search, 2), (150, 'repeat'))
        scan.advance(search, 2, 150, 'repeat', True)
        self.assertEqual(scan.request(search, 2), (120, 'probe'))
        scan.advance(search, 2, 120, 'probe', False)
        scan.advance(search, 2, 120, 'repeat', False)
        self.assertEqual(scan.request(search, 2), (135, 'refine'))

    def test_no_pass_relaxation_limit(self):
        search = scan.new_search()
        scan.advance(search, 4, 400, 'coarse', False)
        self.assertEqual(scan.request(search, 4), (600, 'loosen'))
        scan.advance(search, 4, 600, 'loosen', False)
        scan.advance(search, 4, 900, 'loosen', False)
        self.assertIsNone(scan.request(search, 4))

    def test_checkpoint_hash_and_target_are_required(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)
            p = folder / 'post_place.dcp'
            p.write_bytes(b'checkpoint')
            scan.atomic(folder / 'stage.json', dict(stage='post_place', period_ns=10,
                                                   checkpoint_sha256=scan.sha(p)))
            self.assertEqual(scan.checkpoint(folder, 10), 'post_place')
            self.assertEqual(scan.checkpoint(folder, 20), 'fresh')
            p.write_bytes(b'torn checkpoint')
            self.assertEqual(scan.checkpoint(folder, 10), 'fresh')


class DriverTests(unittest.TestCase):
    def state(self):
        return dict(status='ready', updated_at='test', units={}, config=dict(max_attempts=10),
                    points={'K2U2': dict(k=2, u=2, tag='fixture', snapshot_sha256='fixture',
                        status='pending', attempts=[], search=scan.new_search())})

    def driver(self, folder, state=None):
        scan.atomic(folder / 'state.json', state or self.state())
        return scan.Driver(folder)

    @staticmethod
    def prepare(driver, label):
        driver.state['points'][label]['status'] = 'running'
        return Path('/fixed/source.dcp')

    @staticmethod
    def result(attempt):
        return dict(index=attempt['index'], ticks=attempt['ticks'], kind=attempt['kind'],
                    status='passed' if attempt['ticks'] >= 130 else 'timing_failed',
                    elapsed_seconds=1)

    def test_interruption_resumes_same_attempt_and_search(self):
        with tempfile.TemporaryDirectory() as temp:
            run = Path(temp)
            driver = self.driver(run)
            calls = []

            def attempt(label, source, record):
                calls.append(record['index'])
                if record['index'] == 3:
                    record['elapsed_seconds'] = .5
                    raise scan.Interrupted()
                return self.result(record)

            with patch.object(driver, 'prepare', lambda label: self.prepare(driver, label)), \
                    patch.object(driver, 'attempt', attempt), patch.object(driver, 'report'):
                with self.assertRaises(scan.Interrupted):
                    driver.point('K2U2')
            state = json.loads((run / 'state.json').read_text())
            self.assertEqual(state['points']['K2U2']['attempts'][2]['elapsed_seconds'], .5)
            resumed = scan.Driver(run)
            resumed_calls = []

            def complete(label, source, record):
                resumed_calls.append(record['index'])
                return self.result(record)

            with patch.object(resumed, 'prepare', lambda label: self.prepare(resumed, label)), \
                    patch.object(resumed, 'attempt', complete), patch.object(resumed, 'report'):
                resumed.point('K2U2')
            point = resumed.state['points']['K2U2']
            self.assertEqual(resumed_calls[0], 3)
            self.assertNotIn(1, resumed_calls)
            self.assertEqual([a['index'] for a in point['attempts']], list(range(1, 8)))
            self.assertEqual(point['status'], 'completed')
            self.assertEqual(point['search']['pass_ticks'], 132)

    def test_stop_kills_child_and_resume_keeps_cumulative_time(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)
            driver = self.driver(folder)
            record = {}
            command = [sys.executable, '-c', 'import time; time.sleep(10)']
            timer = threading.Timer(.15, driver.stop.set)
            timer.start()
            try:
                with self.assertRaises(scan.Interrupted):
                    driver.command(command, folder, 'child.log', record, timeout=.5)
            finally:
                timer.join()
            elapsed = record['elapsed_seconds']
            self.assertGreater(elapsed, .1)
            self.assertNotIn('process', record)
            time.sleep(.15)
            driver.stop.clear()
            code, timed_out = driver.command(command, folder, 'child.log', record, timeout=.5)
            self.assertTrue(timed_out)
            self.assertGreaterEqual(record['elapsed_seconds'], .5)
            self.assertLess(record['elapsed_seconds'], 1.2)
            self.assertNotIn('process', record)

    def test_detached_launcher_transfers_lock_and_completes(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)
            state = self.state()
            point = state['points']['K2U2']
            point.update(status='completed', simulation=dict(sign_cycles=10),
                         attempts=[dict(index=1, ticks=200, kind='coarse', status='passed',
                             frequency_mhz=50., area_time_product=1., latency_ms=.0002,
                             period_ns=20., elapsed_seconds=0.)])
            state['points'] = {f'K{k}U{u}': copy.deepcopy(point) for k, u in scan.POINTS}
            state['units'] = {str(u): dict(passed=True) for u in (1, 2, 3, 4)}
            state['config'].update(rtl_sha256=scan.identity(), runtime_sha256={}, source_sha256={})
            scan.atomic(folder / 'state.json', state)
            command = [sys.executable, str(Path(scan.__file__)), 'resume', '--run-dir', str(folder)]
            launched = subprocess.check_output(command, text=True)
            self.assertIn('pid', json.loads(launched))
            deadline = time.monotonic() + 5
            while not (folder / 'FINISHED.json').exists() and time.monotonic() < deadline:
                time.sleep(.05)
            self.assertTrue((folder / 'FINISHED.json').exists(), (folder / 'driver.log').read_text())
            self.assertEqual(scan.load(folder / 'FINISHED.json')['status'], 'finished_all_attempts_passed')
            self.assertIn('ALREADY_FINISHED', subprocess.check_output(command, text=True))


if __name__ == '__main__':
    unittest.main()
