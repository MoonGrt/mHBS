#!/usr/bin/env python3
"""Layout 3 external-input builds, traces and source-bound measurements."""
import argparse,concurrent.futures,hashlib,json,re,subprocess,sys,tarfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
BASE=ROOT/'manifests/experiments/unified_hbs_v4.2/external_job_message'
BUILD=ROOT/'build/v4.2/external_job_message'
NAMES=('slh_128f','slh_192f','slh_256f')
PARAMS=('secret_seed','secret_prf','public_seed','randomizer','public_root')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def rtl():return (ROOT/'manifests/v42_sources.txt').read_text().split()
def run(cmd,log,cwd=ROOT):
 log.parent.mkdir(parents=True,exist_ok=True)
 with log.open('w') as f:subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,check=True)
def identity():return {p:sha(ROOT/p) for p in rtl()}
def capture(tag):
 f=BUILD/tag;f.mkdir(parents=True,exist_ok=True)
 paths=set(rtl()+['Makefile','README.md','manifests/v42_sources.txt'])
 for directory in ('model','tests','scripts','tb','experiments/v4.2'):
  paths.update(str(p.relative_to(ROOT)) for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py','.sv','.svh','.tcl','.mem','.json'))
 paths.update(str(p.relative_to(ROOT)) for p in BASE.rglob('*') if p.is_file() and 'candidates' not in p.parts and p.suffix in ('.mem','.json'))
 source={p:sha(ROOT/p) for p in sorted(paths)}
 if (f/'inputs.json').exists():
  old=json.loads((f/'inputs.json').read_text());assert old['source_sha256']==source,'use a fresh tag after changes';return f
 with tarfile.open(f/'source_snapshot.tar.gz','w:gz') as t:
  for p in source:t.add(ROOT/p,arcname=p)
 write(f/'inputs.json',dict(version='v4.2',layout_revision=3,tag=tag,rtl_sha256=identity(),source_sha256=source,snapshot_sha256=sha(f/'source_snapshot.tar.gz'),software_gate_sha256=sha(BASE/'software_gate.json'),baseline_commit='366b614',tool_versions={x:subprocess.check_output(cmd,text=True,stderr=subprocess.DEVNULL).splitlines()[0] for x,cmd in [('verilator',['verilator','--version']),('iverilog',['iverilog','-V']),('vivado',['vivado','-version'])]}))
 return f

def build_binary(folder,cfg,swap=0):
 key=hashlib.sha256(json.dumps((cfg,swap,identity()),sort_keys=True).encode()).hexdigest()[:16]
 d=folder/'binaries'/key;binary=d/'obj/Vtb_uhbs_external'
 if not binary.exists():
  d.mkdir(parents=True,exist_ok=True)
  parameters=[f"-G{k.upper()}=256'h{int.from_bytes(bytes.fromhex(cfg[k]),'little'):064x}" for k in PARAMS]
  parameters += [f"-GOPERATION={cfg['operation']}",f"-GMESSAGE_BYTES={cfg['message_bytes']}",f'-GSWAP={swap}']
  run(['verilator','--binary','--timing','-O3','-j','8','-Wno-fatal','-Wno-WIDTH','-Wno-UNOPTFLAT','--top-module','tb_uhbs_external',*parameters,'--Mdir',str(binary.parent),*rtl(),'tb/integration/tb_uhbs_external.sv'],d/'compile.log')
 return binary

def simulate_case(folder,name,vector,swap=0,options=()):
 cfg=json.loads((vector/'job.json').read_text());binary=build_binary(folder,cfg,swap)
 log=folder/'logs'/(name+'.log');log.parent.mkdir(parents=True,exist_ok=True)
 dump=log.with_suffix('.actual.mem')
 cmd=[str(binary),'+IMAGE='+str(BASE/'images'/cfg['profile']),'+VECTOR='+str(vector),'+DUMP='+str(dump),*options]
 run(cmd,log)
 hits=re.findall(r'EXTERNAL_PASS boot=(\d+) keygen=(\d+) sign=(\d+) hashes=(\d+) permutations=(\d+) swap=(\d+) run=(\d+) wait=(\d+) total=(\d+)',log.read_text())
 assert len(hits)==(2 if '+REPLAYS=2' in options else 1),str(log)
 result=dict(zip(('boot_cycles','keygen_cycles','sign_cycles','hashes','permutations','swap','run','wait_cycles','total_cycles'),map(int,hits[-1])))
 result.update(passed=True,log_sha256=sha(log),binary_sha256=sha(binary),config=cfg,vector_sha256={p.name:sha(p) for p in vector.iterdir() if p.is_file()})
 write(log.with_suffix('.json'),result);print('EXTERNAL_SIM_PASS',name,result['keygen_cycles'],result['sign_cycles'],flush=True)
 return name,result

def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['capture','sim']);p.add_argument('--tag',required=True);a=p.parse_args()
 f=capture(a.tag)
 if a.action=='sim':
  def one(case):
   n,o=case;return simulate_case(f,n+'_'+o,BASE/'vectors'/n/o)
  with concurrent.futures.ThreadPoolExecutor(3) as pool:r=dict(pool.map(one,[(n,o) for n in NAMES for o in ('keygen','sign')]))
  write(f/'simulation.json',dict(passed=True,rtl_sha256=identity(),cases=r))
if __name__=='__main__':main()
