`timescale 1ns/1ps
`default_nettype none
// Common body: Job and ROM data remain generic inputs during synthesis.
module uhbs_processor #(
 parameter integer LANES=2,UNROLL=2,parameter bit SWAP_PHYSICAL_LANES=0
)(
 input wire clk,rst_n,output wire [4:0] program_address,output wire [3:0] template_address,
 input wire [63:0] program_data,template_data,output wire [9:0] descriptor_addresses,
 input wire [127:0] descriptor_data,
 input wire [255:0] job_secret_seed,job_secret_prf,job_public_seed,job_randomizer,job_public_root,
 input wire job_operation,input wire [6:0] job_message_length,
 input wire [63:0] message_data,input wire message_valid,output wire message_ready,
 output wire out_valid,output wire [63:0] out_data,output wire [7:0] out_keep,
 output wire out_last,result_kind,output logic busy,done,keygen_done,error,
 output logic [15:0] error_code,output logic [31:0] boot_cycles,keygen_cycles,sign_cycles,
 output wire [31:0] hash_count,permutation_count
);
 typedef enum logic [2:0] {HEADER,PROFILE,RELEASE,REQUEST,RUN,HALTED} phase_t;
 phase_t phase;
 logic [63:0] image_header,profile_descriptor;
 logic core_released;
 wire [9:0] core_descriptor_addresses;
 wire core_message_ready,core_job_ready,core_done,core_error;
 wire [15:0] core_error_code;
 wire [31:0] core_cycles;
 assign descriptor_addresses=!core_released ? {5'd0,(phase==HEADER ? 5'd0 : 5'd1)} : core_descriptor_addresses;
 assign result_kind=job_operation;
 assign message_ready=(phase==RUN) && core_message_ready;
 wire core_rst_n=rst_n && core_released;
 wire [4:0] entry=job_operation ? image_header[45:41] : image_header[40:36];
 uhbs_hbs #(.UNROLL(UNROLL),.LANES(LANES),.PROFILE_ENABLE(1),.SWAP_PHYSICAL_LANES(SWAP_PHYSICAL_LANES)) core (
  .clk,.rst_n(core_rst_n),.image_header,.profile_descriptor,.job_entry(entry),
  .program_address,.program_data,.template_address,.template_data,
  .descriptor_addresses(core_descriptor_addresses),.descriptor_data,
  .job_valid(phase==REQUEST),.job_ready(core_job_ready),.job_operation,
  .job_message_length,.job_secret_seed,.job_secret_prf,.job_public_seed,.job_randomizer,.job_public_root,
  .message_valid(message_valid && phase==RUN),.message_ready(core_message_ready),.message_data,
  .out_valid,.out_ready(1'b1),.out_data,.out_keep,.out_last,
  .busy(),.done(core_done),.error(core_error),.error_code(core_error_code),
  .hash_count,.permutation_count,.cycles(core_cycles)
 );
 always_ff @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   phase<=HEADER;core_released<=0;
   busy<=1;done<=0;keygen_done<=0;error<=0;error_code<=0;
   boot_cycles<=0;keygen_cycles<=0;sign_cycles<=0;
   image_header<=0;profile_descriptor<=0;
  end else begin
   keygen_done<=0;
   if(!core_released)boot_cycles<=boot_cycles+1;
   if(core_released && core_error)begin
    error<=1;error_code<=core_error_code;busy<=0;phase<=HALTED;
   end else case(phase)
    HEADER:begin image_header<=descriptor_data[63:0];phase<=PROFILE;end
    PROFILE:begin profile_descriptor<=descriptor_data[63:0];core_released<=1;phase<=RELEASE;end
    RELEASE:phase<=REQUEST;
    REQUEST:if(core_job_ready)phase<=RUN;
    RUN:if(core_done)begin
     if(job_operation)sign_cycles<=core_cycles;else begin keygen_cycles<=core_cycles;keygen_done<=1;end
     done<=1;busy<=0;phase<=HALTED;
    end
    HALTED:begin end
    default:phase<=HALTED;
   endcase
  end
 end
endmodule
`default_nettype wire
