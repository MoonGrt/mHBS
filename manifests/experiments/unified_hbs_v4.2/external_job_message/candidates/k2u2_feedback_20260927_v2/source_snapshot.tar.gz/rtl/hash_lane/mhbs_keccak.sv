`timescale 1ns/1ps
`default_nettype none

// Structurally explicit Keccak-f[1600] round used to compare Vivado mapping
// against the function-inlined implementation.
module mhbs_keccak_round (
    input  wire [1599:0] state_in,
    input  wire [63:0]   rc,
    output wire [1599:0] state_out
);
    wire [63:0] a [0:24];
    wire [63:0] c [0:4];
    wire [63:0] d [0:4];
    wire [63:0] theta [0:24];
    wire [63:0] b [0:24];
    genvar x, y;

    function automatic [63:0] rotl64;
        input [63:0] value;
        input integer amount;
        begin
            rotl64 = amount == 0 ? value
                : (value << amount) | (value >> (64-amount));
        end
    endfunction

    function automatic integer rho_offset;
        input integer lane;
        begin
            case (lane)
                 0: rho_offset=0;   1: rho_offset=1;   2: rho_offset=62;
                 3: rho_offset=28;  4: rho_offset=27;  5: rho_offset=36;
                 6: rho_offset=44;  7: rho_offset=6;   8: rho_offset=55;
                 9: rho_offset=20; 10: rho_offset=3;  11: rho_offset=10;
                12: rho_offset=43; 13: rho_offset=25; 14: rho_offset=39;
                15: rho_offset=41; 16: rho_offset=45; 17: rho_offset=15;
                18: rho_offset=21; 19: rho_offset=8;  20: rho_offset=18;
                21: rho_offset=2;  22: rho_offset=61; 23: rho_offset=56;
                24: rho_offset=14;
                default: rho_offset=0;
            endcase
        end
    endfunction

    generate
        for (y=0; y<5; y=y+1) begin : map_y
            for (x=0; x<5; x=x+1) begin : map_x
                localparam integer I = x + 5*y;
                localparam integer DEST = y + 5*((2*x + 3*y) % 5);
                assign a[I] = state_in[64*I +: 64];
                assign theta[I] = a[I] ^ d[x];
                assign b[DEST] = rotl64(theta[I], rho_offset(I));
                assign state_out[64*I +: 64] = b[I]
                    ^ ((~b[((x+1)%5)+5*y]) & b[((x+2)%5)+5*y])
                    ^ (I == 0 ? rc : 64'd0);
            end
        end
        for (x=0; x<5; x=x+1) begin : columns
            assign c[x] = a[x] ^ a[x+5] ^ a[x+10] ^ a[x+15] ^ a[x+20];
            assign d[x] = c[(x+4)%5] ^ rotl64(c[(x+1)%5], 1);
        end
    endgenerate
endmodule


module mhbs_keccak (
    input wire [1599:0] state_in,
    input wire [4:0] round_index,
    output wire [1599:0] state_out
);
    function automatic [63:0] round_constant;
        input [4:0] index;
        begin
            case (index)
                 0: round_constant=64'h0000000000000001;
                 1: round_constant=64'h0000000000008082;
                 2: round_constant=64'h800000000000808a;
                 3: round_constant=64'h8000000080008000;
                 4: round_constant=64'h000000000000808b;
                 5: round_constant=64'h0000000080000001;
                 6: round_constant=64'h8000000080008081;
                 7: round_constant=64'h8000000000008009;
                 8: round_constant=64'h000000000000008a;
                 9: round_constant=64'h0000000000000088;
                10: round_constant=64'h0000000080008009;
                11: round_constant=64'h000000008000000a;
                12: round_constant=64'h000000008000808b;
                13: round_constant=64'h800000000000008b;
                14: round_constant=64'h8000000000008089;
                15: round_constant=64'h8000000000008003;
                16: round_constant=64'h8000000000008002;
                17: round_constant=64'h8000000000000080;
                18: round_constant=64'h000000000000800a;
                19: round_constant=64'h800000008000000a;
                20: round_constant=64'h8000000080008081;
                21: round_constant=64'h8000000000008080;
                22: round_constant=64'h0000000080000001;
                23: round_constant=64'h8000000080008008;
                default: round_constant=0;
            endcase
        end
    endfunction

    mhbs_keccak_round round_logic(.state_in,.rc(round_constant(round_index)),.state_out);
endmodule

// Fixed U2 combinational datapath. Both rounds may be optimized together;
// there is no register or preserved hierarchy between them.
module mhbs_keccak_u2 (
    input wire [1599:0] state_in,
    input wire [3:0] pair_index,
    output wire [1599:0] state_out
);
    logic [127:0] constants;
    wire [1599:0] middle;
    always_comb begin
        case(pair_index)
            4'd0: constants=128'h00000000000080820000000000000001;
            4'd1: constants=128'h8000000080008000800000000000808a;
            4'd2: constants=128'h0000000080000001000000000000808b;
            4'd3: constants=128'h80000000000080098000000080008081;
            4'd4: constants=128'h0000000000000088000000000000008a;
            4'd5: constants=128'h000000008000000a0000000080008009;
            4'd6: constants=128'h800000000000008b000000008000808b;
            4'd7: constants=128'h80000000000080038000000000008089;
            4'd8: constants=128'h80000000000000808000000000008002;
            4'd9: constants=128'h800000008000000a000000000000800a;
            4'd10: constants=128'h80000000000080808000000080008081;
            4'd11: constants=128'h80000000800080080000000080000001;
            default: constants=128'd0;
        endcase
    end
    mhbs_keccak_round even_round(.state_in,.rc(constants[63:0]),.state_out(middle));
    mhbs_keccak_round odd_round(.state_in(middle),.rc(constants[127:64]),.state_out);
endmodule

`default_nettype wire
