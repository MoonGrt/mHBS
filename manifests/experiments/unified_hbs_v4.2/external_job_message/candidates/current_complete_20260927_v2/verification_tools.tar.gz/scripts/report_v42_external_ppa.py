#!/usr/bin/env python3
"""Report current measured area and routed OOC timing, bound to the measured RTL."""
import json
from v42_external_flow import BASE, ROOT, sha

final = json.loads((BASE / 'final.json').read_text())
candidate = BASE / 'candidates' / final['candidate']
synth = json.loads((candidate / 'result.json').read_text())
assert sha(candidate / 'result.json') == final['result_sha256']
fresh = all((ROOT/p).is_file() and sha(ROOT/p) == h for p, h in synth['rtl_sha256'].items())
lines = ['# 当前面积与频率实测', '', f'候选：`{final["candidate"]}`。生产 RTL 与测量快照哈希一致：**{"是" if fresh else "否"}**。', '',
         '器件：`xc7a200tffg1156-3`；Vivado 2025.2；U2、双 Hash lane。等效 Slice = LUT/4 + FF/8 + BRAM36×232.4 + DSP×102.4，并非物理占用 Slice 数。', '',
         '## 综合面积', '', '| 对象 | LUT | FF | LUTRAM | BRAM36 | DSP | 等效 Slice |', '|---|---:|---:|---:|---:|---:|---:|']
for name, row in [('共同核', synth['core']), *synth['tops'].items()]:
    lines.append(f'| {name} | {row["lut"]:,.0f} | {row["ff"]:,.0f} | {row["lutram"]:,.0f} | {row["bram36"]:g} | {row["dsp"]:g} | {row["equivalent_slice"]:,.3f} |')
routed_final = BASE / 'routed_final.json'
if routed_final.exists() and json.loads(routed_final.read_text())['candidate'] == final['candidate']:
    rf = json.loads(routed_final.read_text())
    assert sha(candidate / 'route/result.json') == rf['route_result_sha256']
    routed = json.loads((candidate / 'route/result.json').read_text())
    lines += ['', '## 布线面积与频率', '',
              '六个参数外壳分别实现并通过检查。时序范围为 OOC 顶层，所有数据输入/输出延迟设为 0 ns，同步复位纳入时序，不使用复位 false path。频率由最终布线网表重新进行静态时序分析得到，周期取 0.1 ns 网格并保留至少 0.1 ns setup 裕量；hold、脉宽、布线完整性和 ROM 内容也检查通过。这不是板级时钟或硅上实测频率。', '',
              f'六组均通过的共同频率：**{routed["common_frequency_mhz"]:.6f} MHz**。', '',
              '| 顶层 | LUT | FF | 等效 Slice | 周期 ns | 频率 MHz | WNS ns | WHS ns | 操作延迟 ms |',
              '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for name, row in routed['tops'].items():
        lines.append(f'| {name} | {row["lut"]:,.0f} | {row["ff"]:,.0f} | {row["equivalent_slice"]:,.3f} | {row["period_ns"]:.1f} | {row["frequency_mhz"]:.6f} | {row["wns_ns"]:.3f} | {row["whs_ns"]:.3f} | {row["latency_ms"]:.6f} |')
else:
    lines += ['', '尚无此候选的完整布线验收，不声明频率。']
lines += ['', '## 证据与复现', '',
          f'源码快照 SHA-256：`{synth["source_snapshot_sha256"]}`。', '',
          f'完整证据：`manifests/experiments/unified_hbs_v4.2/external_job_message/candidates/{final["candidate"]}/`。功能证据包含 6 组正常执行、33 项扩展验证和 6 组共同核等价仿真。', '',
          '```bash', 'python3 scripts/reproduce_v42_external.py', 'python3 scripts/reproduce_v42_external_route.py', 'make report-v42', '```', '']
(ROOT / 'docs/v4.2/Current_PPA.md').write_text('\n'.join(lines))
print('EXTERNAL_PPA_REPORT_PASS', final['candidate'], 'rtl_matches=', fresh)
