`timescale 1ns/1ps
module tb_mhbs_s_parameters;
 logic [63:0] profile_descriptor=0;
 reg [391:0] digest;
 reg [63:0] expected_tree;
 integer a,k,hp,tree_bits,fb,tb_bytes,lb,expected_leaf,expected_index;
 mhbs_hbs dut(.clk(1'b0),.rst(1'b0),.profile_descriptor);
 initial begin
  for(integer p=0;p<6;p=p+1)begin
   case(p)
    0:begin profile_descriptor=0;a=6;k=33;hp=3;tree_bits=63;end
    1:begin profile_descriptor=1;a=8;k=33;hp=3;tree_bits=63;end
    2:begin profile_descriptor=2;a=9;k=35;hp=4;tree_bits=64;end
    3:begin profile_descriptor=4;a=12;k=14;hp=9;tree_bits=54;end
    4:begin profile_descriptor=5;a=14;k=17;hp=9;tree_bits=54;end
    5:begin profile_descriptor=6;a=14;k=22;hp=8;tree_bits=56;end
   endcase
   fb=(a*k+7)/8;tb_bytes=(tree_bits+7)/8;lb=(hp+7)/8;
   for(integer t=0;t<12;t=t+1)begin
    for(integer j=0;j<49;j=j+1)
     digest[j*8 +:8]=t==0 ? 0 : t==1 ? 255 : $random;
    dut.value[1]=digest;
    #1;
    for(integer g=0;g<k;g=g+1)begin
     expected_index=0;
     for(integer j=0;j<a;j=j+1)
      expected_index=(expected_index<<1)|int'(digest[((g*a+j)/8)*8+7-((g*a+j)%8)]);
     if(dut.fors_target(g)!==14'(expected_index))$fatal(1,"FORS decode profile=%0d group=%0d",p,g);
    end
    expected_tree=0;
    for(integer j=0;j<tb_bytes;j=j+1)expected_tree=(expected_tree<<8)|64'(digest[(fb+j)*8 +:8]);
    expected_tree=expected_tree & (~64'd0>>(64-tree_bits));
    expected_leaf=0;
    for(integer j=0;j<lb;j=j+1)expected_leaf=(expected_leaf<<8)|int'(digest[(fb+tb_bytes+j)*8 +:8]);
    expected_leaf=expected_leaf & ((1<<hp)-1);
    if(dut.parsed_tree(digest)!==expected_tree)$fatal(1,"tree decode profile=%0d",p);
    if(dut.parsed_leaf(digest)!==10'(expected_leaf))$fatal(1,"leaf decode profile=%0d expected=%0d",p,expected_leaf);
   end
  end
  $display("S_PARAMETERS_PASS six_profiles all_FORS_groups zero_max_random tree_leaf_endianness");$finish;
 end
endmodule
